#pragma once
#include "Parametrization.h"
#include "BCD_Sphere_Optimization.h"
#include "BCD_Volume_Sphere_Optimization.h"
#include <queue>

struct EdgeInfo
{
//	int edge_id;
	MyMesh::HalfedgeHandle idx;
	double ecost;
	inline    friend bool      operator<(const EdgeInfo & lhs, const EdgeInfo & rhs) { return (lhs.ecost < rhs.ecost);}
	inline    friend bool      operator>(const EdgeInfo & lhs, const EdgeInfo & rhs) { return (lhs.ecost > rhs.ecost);}
};

struct EdgeQEM
{
	MyMesh::EdgeHandle idx;
	double qem;
	inline    friend bool      operator<(const EdgeQEM & lhs, const EdgeQEM & rhs) { return (lhs.qem > rhs.qem); }
	inline    friend bool      operator>(const EdgeQEM & lhs, const EdgeQEM & rhs) { return (lhs.qem < rhs.qem); }
};

class HierarchicalSphereParametrization
{
public:
	HierarchicalSphereParametrization(void);
	HierarchicalSphereParametrization(MyMesh &mesh);
	~HierarchicalSphereParametrization(void);
public:
/////////////////////////////////////////////////////////////////////////////////////////////// simplify the mesh to a tetrahedron
	vector<vector<int>> do_Simplify();
	bool Choose_Collapased_edge(MyMesh &m);
	bool Choose_Collapased_edge_qem(MyMesh &m,double err_threshhold);
	void Initial_Halfedge_Cost(MyMesh &m);
	void Initial_Edge_QEM_cost(MyMesh &m);
	void Update_Edge_QEM_cost(MyMesh &m, int i);
	void Update_Halfedge_Cost(MyMesh &m,int i);
	void QEM_Simplify(int tar_num_v,double err_threshhold);
	void LaplacianSmooth(MyMesh &m,int iter_num_); 
	void calc_vindex(MyMesh& m);
//	bool Is_exist_fliping(MyMesh &m);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////   project to a sphere , and then subdivide to original topology
	void Subdivision(int num_optimization_,vector<vector<int>> &idx_v_to_v);
	bool Restore_Last_mesh(MyMesh &m,vector<int> &reco_info);
	bool Add_One_Point(MyMesh &m,MyMesh::VertexHandle v_f,MyMesh::VertexHandle v_t,int c);
	bool local_check_negative_area(MyMesh::Point &p, vector<MyMesh::Point> &n_p);
	double local_isotropy_energy(MyMesh::Point &p,vector<MyMesh::Point> &np1,vector<MyMesh::Point> &np2,double area_);
	void Compute_idx_to_idx_corresponding(MyMesh &m);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// support function
	double ComputeSphereRadius(MyMesh &m);
	void calc_origin_position(MyMesh& m);
	MyMesh::VertexHandle ComputeBihedralAngles(MyMesh &m,MyMesh::VertexHandle &idx);
	bool OptimizeOneRing(MyMesh &m,MyMesh::VertexHandle &idx,MyMesh::VertexHandle v_t,int c);
	void PrintInfo(string fileName);
	void RefineModel(MyMesh &m, double thresh_hold, double r);
public: 
	MyMesh origin_mesh;
	MyMesh initial_mesh;
	MyMesh copy_origin_mesh;
	MyMesh copy_origin_mesh1;

private:
	vector<vector<int>> index_collapse_v_to_v;
	vector<MyMesh::Point> o_p;
	OpenMesh::VPropHandleT<int> vindex;
	OpenMesh::HPropHandleT<double> ecost;
	OpenMesh::HPropHandleT<bool> is_cal_he;
	OpenMesh::VPropHandleT<MyMesh::Point> origin_position;
	OpenMesh::VPropHandleT<Eigen::Matrix4d> QuaMat_v;
	OpenMesh::FPropHandleT<Eigen::Matrix4d> QuaMat_f;
	OpenMesh::FPropHandleT<double> area_f;
	OpenMesh::EPropHandleT<double> QuaMat_e;
	OpenMesh::EPropHandleT<OpenMesh::Vec3d> new_point;
	//OpenMesh::EPropHandleT<double> edge_l;
	OpenMesh::EPropHandleT<bool> is_cal_e;
	int current_num_v;
	int current_num_e;
	int current_num_f;
	bool first_sub;
	double maxmum;
	bool is_in_sphere;
	priority_queue<EdgeInfo> epq;
	priority_queue<EdgeQEM> qpq;
	vector<int> idx_to_idx_corresponding;
	
public:
	vector<int> nei_ps1,nei_ps2;
	BCD_Sphere_Optimization * bcd_optimization;
	BCD_Volume_Sphere_Optimization * bcd_v_optimization;
	double global_max_energy;
	vector<int> recore_add_v_nun;
	vector<double> record_max_dis;
	double radius;
	int n_vertices;
	int n_edges;
	int n_faces;

};

