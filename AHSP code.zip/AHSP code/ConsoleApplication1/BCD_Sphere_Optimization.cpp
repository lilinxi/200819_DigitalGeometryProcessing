#include "BCD_Sphere_Optimization.h"



BCD_Sphere_Optimization::BCD_Sphere_Optimization(void)
{
}

BCD_Sphere_Optimization::BCD_Sphere_Optimization(MyMesh* m, double radius_)
{
	mesh = m;
	radius_suv = radius_;
	dr_eps = 1e-10;
	overlap_eps = 1e-12;
	cot_angla = 1.0 / std::sqrt(3.0);
	fa_area = 4.0*3.14159*radius_suv*radius_suv; fa_area /= (double)(mesh->n_faces()); fa_area *= 2.0;
	thresh_hold = (sqrt(3.1415926 / 2.0) / (50.0*sqrt(sqrt(3.0))))*radius_;
}

BCD_Sphere_Optimization::BCD_Sphere_Optimization(MyMesh *m, MyMesh *m1, double radius_)
{
	mesh = m;
	origin_mesh = m1;
	radius_suv = ComputeNewRadius();
	for (auto v_it = mesh->vertices_begin(); v_it != mesh->vertices_end(); ++v_it)
	{
		MyMesh::Point p = mesh->point(v_it);
		p = radius_suv*p / p.norm();
		mesh->set_point(v_it, p);
	}
	//	printf("%e %e\n", radius_, radius_suv);
	//	cout<<radius_ <<"  "<<radius_suv<<endl;
	dr_eps = 1e-10;
	overlap_eps = 1e-12;
}

BCD_Sphere_Optimization::BCD_Sphere_Optimization(MyMesh* m, double radius_, OpenMesh::VPropHandleT<MyMesh::Point> &origin_position)
{
	mesh = m;
	radius_suv = radius_;
	dr_eps = 1e-8;
	overlap_eps = 1e-16;
	mesh->request_vertex_status();
	mesh->add_property(origin_position_);
	for (auto it = mesh->vertices_begin(); it != mesh->vertices_end(); ++it)
	{

		mesh->property(origin_position_, it) = m->property(origin_position, m->vertex_handle(it.handle().idx()));
		//		cout<<mesh->property(origin_position_,it)<<endl;
	}
}

BCD_Sphere_Optimization::~BCD_Sphere_Optimization(void)
{

}

void BCD_Sphere_Optimization::do_parameterizing(double energy_power, double angle_area_ratio, int iter)
{
	prepare_parameterization(mesh);
	int iter_count = 0;
	while (iter_count <iter)
	{
		MIPS_AREA_Reposition(mesh, 0, angle_area_ratio);
		//		MIPS_VOL_Reposition(mesh, 0,angle_area_ratio);
		iter_count++;
	}
	for (auto it = mesh->vertices_begin(); it != mesh->vertices_end(); ++it)
	{
		int i = it.handle().idx();
		MyMesh::Point p(new_p_x[i], new_p_y[i], new_p_z[i]);
		mesh->set_point(it, p);
	}
}

void BCD_Sphere_Optimization::do_EXP_parameterizing(double energy_power, double angle_area_ratio, int iter)
{
	//	prepare_parameterization(mesh);
	//	origin_prepare_parameterization(mesh);
	int iter_count = 0;
	while (iter_count <iter)
	{
		EXP_MIPS_AREA_Reposition(mesh, 0, energy_power, angle_area_ratio);
		//		Refine_EXP_MIPS_AREA_Reposition(mesh, 0,energy_power,angle_area_ratio);
		iter_count++;
	}
	for (auto it = mesh->vertices_begin(); it != mesh->vertices_end(); ++it)
	{
		int i = it.handle().idx();
		MyMesh::Point p(new_p_x[i], new_p_y[i], new_p_z[i]);
		mesh->set_point(it, p);
	}
}

void BCD_Sphere_Optimization::do_parallel_EXP_parameterizing(double energy_power, double angle_area_ratio, int iter)
{
	//	prepare_parameterization();
	high_d = ComputeMaxTriangleDistortion_Refer_Originmesh(mesh, origin_mesh, angle_area_ratio);
	//energy_power = std::log(10) / std::log(high_d);
	energy_power = std::log(30) / std::log(high_d);
	if (high_d > 10 && high_d < 50)
	{
		energy_power = std::log(30) / std::log(high_d);
	}
	f = new fmath::PowGenerator(energy_power);

	long start_t = clock();
	int n_color_ = vertex_diff_color.size();
	int max_num_t = omp_get_max_threads();
	std::vector<std::vector<double>> p1_vec_x(max_num_t); std::vector<std::vector<double>> p1_vec_y(max_num_t); std::vector<std::vector<double>> p1_vec_z(max_num_t);
	std::vector<std::vector<double>> p2_vec_x(max_num_t); std::vector<std::vector<double>> p2_vec_y(max_num_t); std::vector<std::vector<double>> p2_vec_z(max_num_t);
	std::vector<std::vector<double>> l0_n_vec(max_num_t);
	std::vector<std::vector<double>> p1_p2_cross_x(max_num_t); std::vector<std::vector<double>> p1_p2_cross_y(max_num_t); std::vector<std::vector<double>> p1_p2_cross_z(max_num_t);
	for (int i = 0; i < max_num_t; ++i)
	{
		p1_vec_x[i].resize(max_vv_size); p1_vec_y[i].resize(max_vv_size); p1_vec_z[i].resize(max_vv_size);
		p2_vec_x[i].resize(max_vv_size); p2_vec_y[i].resize(max_vv_size); p2_vec_z[i].resize(max_vv_size);
		l0_n_vec[i].resize(max_vv_size);
		p1_p2_cross_x[i].resize(max_vv_size); p1_p2_cross_y[i].resize(max_vv_size); p1_p2_cross_z[i].resize(max_vv_size);
	}
	for (int k = 0; k < iter; ++k)
	{
		for (unsigned i = 0; i < n_color_; ++i)
		{
			int one_color_size = vertex_diff_color[i].size();

#pragma omp parallel for schedule(dynamic)
			for (int j = 0; j < one_color_size; ++j)
			{
				int id = omp_get_thread_num();
				//cout <<id<< endl;
				EXP_MIPS_AREA_Reposition_one_V(vertex_diff_color[i][j], 0, energy_power, angle_area_ratio,
					l0_n_vec[id], p1_vec_x[id], p1_vec_y[id], p1_vec_z[id],
					p2_vec_x[id], p2_vec_y[id], p2_vec_z[id],
					p1_p2_cross_x[id], p1_p2_cross_y[id], p1_p2_cross_z[id]);
				/*MIPS_AREA_Reposition_one_V(vertex_diff_color[i][j], 0, angle_area_ratio,
				l0_n_vec[id], p1_vec_x[id], p1_vec_y[id], p1_vec_z[id],
				p2_vec_x[id], p2_vec_y[id], p2_vec_z[id],
				p1_p2_cross_x[id], p1_p2_cross_y[id], p1_p2_cross_z[id]);*/
			}
		}
	}

	long end_t = clock();
	long diff = end_t - start_t;
	double t = (double)(diff) / CLOCKS_PER_SEC;
	//	printf("=====================================\nOptimization Time: %f s\n", t);

	//convert positions
	int nv = mesh->n_vertices();
	for (int v_id = 0; v_id < nv; ++v_id)
	{
		MyMesh::Point p(new_p_x[v_id], new_p_y[v_id], new_p_z[v_id]);
		mesh->set_point(mesh->vertex_handle(v_id), p);
	}
}

void BCD_Sphere_Optimization::do_Refine_EXP_parameterizing(double energy_power, double angle_area_ratio, int iter)
{
	prepare_refine();
	int iter_count = 0;
	while (iter_count <iter)
	{
		Refine_EXP_MIPS_AREA_Reposition(mesh, 0, energy_power, angle_area_ratio);
		iter_count++;
	}
	for (auto it = mesh->vertices_begin(); it != mesh->vertices_end(); ++it)
	{
		int i = it.handle().idx();
		MyMesh::Point p(new_p_x[i], new_p_y[i], new_p_z[i]);
		mesh->set_point(it, p);
	}
}

void BCD_Sphere_Optimization::prepare_parameterization(MyMesh* mesh_)
{
	unsigned nv = mesh_->n_vertices(); new_p_x.resize(nv); new_p_y.resize(nv); new_p_z.resize(nv);
	vertex_v1.resize(nv); vertex_v2.resize(nv); face_area.resize(nv); inv_face_area.resize(nv);  face_vol.resize(nv); inv_face_vol.resize(nv);
	omega0.resize(nv); omega1.resize(nv); omega2.resize(nv);
	vertex_radius_ratio.resize(nv); std::vector<int> boundary_v;
	max_vv_size = 0;  double f_area = 4.0*3.14159*radius_suv*radius_suv; f_area /= (double)(mesh_->n_faces()); f_area *= 2.0;
	double f_vol = (4.0 / 3.0)*3.14159*radius_suv*radius_suv*radius_suv;   f_vol /= (double)(mesh_->n_faces());
	double omega = 1.0 / std::sqrt(3.0);
	for (MyMesh::VertexIter v_it = mesh_->vertices_begin(); v_it != mesh_->vertices_end(); ++v_it)
	{
		MyMesh::Point p = mesh_->point(v_it);
		OpenMesh::Vec3d p0;
		p0[0] = p[0]; p0[1] = p[1]; p0[2] = p[2];

		int v_id = v_it.handle().idx(); vertex_radius_ratio[v_id] = 1.0;
		new_p_x[v_id] = p0[0]; new_p_y[v_id] = p0[1]; new_p_z[v_id] = p0[2];

		int degree_v = mesh_->valence(v_it);

		vector<double> omega_vec(degree_v, omega);
		std::vector<double> f_area_vec(degree_v, f_area); std::vector<double> inv_f_area_vec(degree_v, 1.0 / f_area);
		std::vector<double> f_vol_vec(degree_v, f_vol); std::vector<double> inv_f_vol_vec(degree_v, 1.0 / f_vol);
		std::vector<int> v1_vec(degree_v); std::vector<int> v2_vec(degree_v);

		int counter = 0;
		for (MyMesh::VertexOHalfedgeIter voh_it = mesh_->voh_iter(v_it); voh_it; ++voh_it)
		{
			MyMesh::FaceHandle fh = mesh_->face_handle(voh_it);
			if (fh != MyMesh::InvalidFaceHandle)
			{
				OpenMesh::HalfedgeHandle heh0 = mesh_->next_halfedge_handle(voh_it);
				OpenMesh::HalfedgeHandle heh1 = mesh_->prev_halfedge_handle(voh_it);

				v1_vec[counter] = mesh_->to_vertex_handle(voh_it).idx();
				v2_vec[counter] = mesh_->to_vertex_handle(mesh_->next_halfedge_handle(voh_it)).idx();

				counter++;

			}
		}

		omega0[v_id] = omega_vec; omega1[v_id] = omega_vec; omega2[v_id] = omega_vec;
		vertex_v1[v_id] = v1_vec; vertex_v2[v_id] = v2_vec;
		face_area[v_id] = f_area_vec; inv_face_area[v_id] = inv_f_area_vec;
		face_vol[v_id] = f_vol_vec;  inv_face_vol[v_id] = inv_f_vol_vec;

		int vv_size = vertex_v1[v_id].size();
		if (vv_size > max_vv_size)
		{
			max_vv_size = vv_size;
		}
	}
}

void BCD_Sphere_Optimization::prepare_parameterization()
{
	unsigned nv = origin_mesh->n_vertices(); new_p_x.resize(nv); new_p_y.resize(nv); new_p_z.resize(nv);
	vertex_v1.resize(nv); vertex_v2.resize(nv); face_area.resize(nv); inv_face_area.resize(nv);
	omega0.resize(nv); omega1.resize(nv); omega2.resize(nv);
	vertex_radius_ratio.resize(nv); std::vector<int> boundary_v;
	max_vv_size = 0;
	for (MyMesh::VertexIter v_it = origin_mesh->vertices_begin(); v_it != origin_mesh->vertices_end(); ++v_it)
	{
		OpenMesh::Vec3d& p0 = origin_mesh->point(v_it);
		int v_id = v_it.handle().idx(); vertex_radius_ratio[v_id] = 1.0;

		OpenMesh::Vec3d& mid_p = mesh->point(mesh->vertex_handle(v_id));
		new_p_x[v_id] = mid_p[0]; new_p_y[v_id] = mid_p[1]; new_p_z[v_id] = mid_p[2];

		std::vector<double> f_area_vec; std::vector<double> inv_f_area_vec;
		std::vector<int> v1_vec; std::vector<int> v2_vec;
		std::vector<double> omega0_vec; std::vector<double> omega1_vec; std::vector<double> omega2_vec;
		for (MyMesh::VertexOHalfedgeIter voh_it = origin_mesh->voh_iter(v_it); voh_it; ++voh_it)
		{
			MyMesh::FaceHandle fh = origin_mesh->face_handle(voh_it);
			if (fh != MyMesh::InvalidFaceHandle)
			{
				OpenMesh::HalfedgeHandle heh0 = origin_mesh->next_halfedge_handle(voh_it);
				OpenMesh::HalfedgeHandle heh1 = origin_mesh->prev_halfedge_handle(voh_it);
				OpenMesh::HalfedgeHandle heh2 = voh_it.handle();
				OpenMesh::Vec3d& p1 = origin_mesh->point(origin_mesh->to_vertex_handle(heh2));
				OpenMesh::Vec3d& p2 = origin_mesh->point(origin_mesh->to_vertex_handle(heh0));
				double mid = ((p1 - p0) | (p2 - p0)) / ((p1 - p0).norm()*(p2 - p0).norm());
				double theta = acos(mid);
				double omega0_ = cos(theta) / sin(theta);
				mid = ((p0 - p1) | (p2 - p1)) / ((p0 - p1).norm()*(p2 - p1).norm());
				theta = acos(mid);
				double omega1_ = cos(theta) / sin(theta);
				mid = ((p1 - p2) | (p0 - p2)) / ((p1 - p2).norm()*(p0 - p2).norm());
				theta = acos(mid);
				double omega2_ = cos(theta) / sin(theta);
				omega0_vec.push_back(omega0_); omega1_vec.push_back(omega1_); omega2_vec.push_back(omega2_);
				v1_vec.push_back(origin_mesh->to_vertex_handle(voh_it).idx());
				v2_vec.push_back(origin_mesh->to_vertex_handle(origin_mesh->next_halfedge_handle(voh_it)).idx());
				f_area_vec.push_back(((p1 - p0) % (p2 - p0)).norm());
				inv_f_area_vec.push_back(1.0 / f_area_vec.back());
			}
		}

		omega0[v_id] = omega0_vec; omega1[v_id] = omega1_vec; omega2[v_id] = omega2_vec;
		vertex_v1[v_id] = v1_vec; vertex_v2[v_id] = v2_vec;
		face_area[v_id] = f_area_vec; inv_face_area[v_id] = inv_f_area_vec;

		int vv_size = vertex_v1[v_id].size();
		if (vv_size > max_vv_size)
		{
			max_vv_size = vv_size;
		}
	}
	std::vector<OpenMesh::Vec2i> edges(mesh->n_edges());
	for (MyMesh::EdgeIter e_it = mesh->edges_begin(); e_it != mesh->edges_end(); ++e_it)
	{
		MyMesh::HalfedgeHandle heh = mesh->halfedge_handle(e_it, 0);
		MyMesh::VertexHandle vh0 = mesh->to_vertex_handle(heh);
		MyMesh::VertexHandle vh1 = mesh->from_vertex_handle(heh);
		edges[e_it->idx()][0] = vh0.idx();
		edges[e_it->idx()][1] = vh1.idx();
	}
	vertex_diff_color.clear();
	graph_coloring(nv, edges, vertex_diff_color);
}

void BCD_Sphere_Optimization::origin_prepare_parameterization(MyMesh* mesh_, OpenMesh::VPropHandleT<MyMesh::Point> &origin_position_)
{
	unsigned nv = mesh_->n_vertices(); new_p_x.resize(nv); new_p_y.resize(nv); new_p_z.resize(nv);
	vertex_v1.resize(nv); vertex_v2.resize(nv); face_area.resize(nv); inv_face_area.resize(nv);  face_vol.resize(nv); inv_face_vol.resize(nv);
	omega0.resize(nv); omega1.resize(nv); omega2.resize(nv);
	vertex_radius_ratio.resize(nv); std::vector<int> boundary_v;
	max_vv_size = 0;  //double f_area = 4.0*3.14159*radius_suv*radius_suv; f_area /= (double)(mesh_->n_faces());
	//	double f_vol = (4.0/3.0)*3.14159*radius_suv*radius_suv*radius_suv;   f_vol /= (double)(mesh_->n_faces());
	for (MyMesh::VertexIter v_it = mesh_->vertices_begin(); v_it != mesh_->vertices_end(); ++v_it)
	{
		int v_id = v_it.handle().idx(); vertex_radius_ratio[v_id] = 1.0;
		MyMesh::Point p = mesh_->point(v_it);
		OpenMesh::Vec3d p0;
		p0[0] = p[0]; p0[1] = p[1]; p0[2] = p[2];
		new_p_x[v_id] = p0[0]; new_p_y[v_id] = p0[1]; new_p_z[v_id] = p0[2];
		p = mesh_->property(origin_position_, v_it);
		p0[0] = p[0]; p0[1] = p[1]; p0[2] = p[2];

		/*	if (number_of_color == 0)
		{
		mesh_->data(v_it).set_color(v_id + 1);
		}*/

		std::vector<double> f_area_vec; std::vector<double> inv_f_area_vec;
		//		std::vector<double> f_vol_vec; std::vector<double> inv_f_vol_vec;
		std::vector<int> v1_vec; std::vector<int> v2_vec;
		std::vector<double> omega0_vec; std::vector<double> omega1_vec; std::vector<double> omega2_vec;
		for (MyMesh::VertexOHalfedgeIter voh_it = mesh_->voh_iter(v_it); voh_it; ++voh_it)
		{
			MyMesh::FaceHandle fh = mesh_->face_handle(voh_it);
			if (fh != MyMesh::InvalidFaceHandle)
			{
				OpenMesh::HalfedgeHandle heh0 = mesh_->next_halfedge_handle(voh_it);
				OpenMesh::HalfedgeHandle heh1 = mesh_->prev_halfedge_handle(voh_it);
				OpenMesh::HalfedgeHandle heh2 = voh_it.handle();
				//				p = mesh_->point(mesh_->to_vertex_handle(heh2));
				p = mesh_->property(origin_position_, mesh_->to_vertex_handle(heh2));
				OpenMesh::Vec3d p1; p1[0] = p[0]; p1[1] = p[1]; p1[2] = p[2];
				//				p = mesh_->point(mesh_->to_vertex_handle(heh0));
				p = mesh_->property(origin_position_, mesh_->to_vertex_handle(heh0));
				OpenMesh::Vec3d p2; p2[0] = p[0]; p2[1] = p[1]; p2[2] = p[2];
				double mid = ((p1 - p0) | (p2 - p0)) / ((p1 - p0).norm()*(p2 - p0).norm());
				double theta = acos(mid);
				if (mid < -0.9999)
				{
					theta = 3.14159;
				}
				if (mid > 0.9999)
				{
					theta = 0.01;
				}
				double omega0_ = cos(theta) / sin(theta);
				mid = ((p0 - p1) | (p2 - p1)) / ((p0 - p1).norm()*(p2 - p1).norm());
				theta = acos(mid);
				if (mid < -0.9999)
				{
					theta = 3.14159;
				}
				if (mid > 0.9999)
				{
					theta = 0.01;
				}
				double omega1_ = cos(theta) / sin(theta);
				mid = ((p1 - p2) | (p0 - p2)) / ((p1 - p2).norm()*(p0 - p2).norm());
				theta = acos(mid);
				if (mid < -0.9999)
				{
					theta = 3.14159;
				}
				if (mid > 0.9999)
				{
					theta = 0.01;
				}
				double omega2_ = cos(theta) / sin(theta);
				omega0_vec.push_back(omega0_); omega1_vec.push_back(omega1_); omega2_vec.push_back(omega2_);
				v1_vec.push_back(mesh_->to_vertex_handle(voh_it).idx());
				v2_vec.push_back(mesh_->to_vertex_handle(mesh_->next_halfedge_handle(voh_it)).idx());
				f_area_vec.push_back(((p1 - p0) % (p2 - p0)).norm());
				//				f_vol_vec.push_back(f_vol);
				inv_f_area_vec.push_back(1.0 / f_area_vec.back());
				//				inv_f_vol_vec.push_back(1.0/f_vol);
			}
		}

		omega0[v_id] = omega0_vec; omega1[v_id] = omega1_vec; omega2[v_id] = omega2_vec;
		vertex_v1[v_id] = v1_vec; vertex_v2[v_id] = v2_vec;
		face_area[v_id] = f_area_vec; inv_face_area[v_id] = inv_f_area_vec;
		//		face_vol[v_id] = f_vol_vec;  inv_face_vol[v_id] = inv_f_vol_vec;
		if (mesh_->is_boundary(v_it))
		{
			boundary_v.push_back(v_id);
		}

		//		int c = mesh_->data(v_it).get_color() - 1;
		//		vertex_diff_color[c].push_back(v_id);

		int vv_size = vertex_v1[v_id].size();
		if (vv_size > max_vv_size)
		{
			max_vv_size = vv_size;
		}
	}
}

void BCD_Sphere_Optimization::MIPS_AREA_Reposition(MyMesh* mesh_, double step_length, double angle_area_ratio)
{
	int nv = new_p_x.size();
	std::vector<double> p1_vec_x(max_vv_size); std::vector<double> p1_vec_y(max_vv_size); std::vector<double> p1_vec_z(max_vv_size);
	std::vector<double> p2_vec_x(max_vv_size); std::vector<double> p2_vec_y(max_vv_size); std::vector<double> p2_vec_z(max_vv_size);
	std::vector<double> l0_n_vec(max_vv_size);
	std::vector<double> p1_p2_cross_x(max_vv_size); std::vector<double> p1_p2_cross_y(max_vv_size); std::vector<double> p1_p2_cross_z(max_vv_size);
	double alpha = angle_area_ratio; double beta = 1.0 - alpha;

	for (int i = 0; i < nv; ++i)
	{
		double p0_x = new_p_x[i]; double p0_y = new_p_y[i]; double p0_z = new_p_z[i];
		double gx = 0.0; double gy = 0.0; double gz = 0.0;
		double local_EXP_MIPS_e = 0.0; double min_r = 1e30;
		int vv_size = vertex_v1[i].size();

		std::vector<double>& fh_area_vec = face_area[i]; std::vector<double>& inv_face_area_vec = inv_face_area[i];
		std::vector<double>& omega0_vec = omega0[i]; std::vector<double>& omega1_vec = omega1[i]; std::vector<double>& omega2_vec = omega2[i];
		std::vector<int>& v_v1 = vertex_v1[i]; std::vector<int>& v_v2 = vertex_v2[i];

		for (int j = 0; j < vv_size; ++j)
		{
			int vv1 = v_v1[j]; int vv2 = v_v2[j];
			double p1_x = new_p_x[vv1]; double p1_y = new_p_y[vv1]; double p1_z = new_p_z[vv1];
			double p2_x = new_p_x[vv2]; double p2_y = new_p_y[vv2]; double p2_z = new_p_z[vv2];
			p1_vec_x[j] = p1_x; p1_vec_y[j] = p1_y; p1_vec_z[j] = p1_z;
			p2_vec_x[j] = p2_x; p2_vec_y[j] = p2_y; p2_vec_z[j] = p2_z;
			double omega0_ = omega0_vec[j]; double omega1_ = omega1_vec[j]; double omega2_ = omega2_vec[j];
			p1_p2_cross_x[j] = p1_y * p2_z - p1_z*p2_y;
			p1_p2_cross_y[j] = p1_z * p2_x - p1_x*p2_z;
			p1_p2_cross_z[j] = p1_x * p2_y - p1_y*p2_x;

			double l1x = p0_x - p2_x; double l1y = p0_y - p2_y; double l1z = p0_z - p2_z; double l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
			double l2x = p1_x - p0_x; double l2y = p1_y - p0_y; double l2z = p1_z - p0_z; double l2_n = l2x*l2x + l2y*l2y + l2z*l2z;
			double l0x = p2_x - p1_x; double l0y = p2_y - p1_y; double l0z = p2_z - p1_z; double l0_n = l0x*l0x + l0y*l0y + l0z*l0z;

			double nx = -l2y*l1z + l2z*l1y;
			double ny = -l2z*l1x + l2x*l1z;
			double nz = -l2x*l1y + l2y*l1x;

			double a = std::sqrt(nx*nx + ny*ny + nz*nz); double ia = 1.0 / a;
			nx *= ia; ny *= ia; nz *= ia;
			double l0_T_x = ny*l0z - nz *l0y;
			double l0_T_y = nz*l0x - nx *l0z;
			double l0_T_z = nx*l0y - ny *l0x;

			l0_n_vec[j] = omega0_*l0_n;
			double fa = fh_area_vec[j]; double ifa = inv_face_area_vec[j];
			double mips_e = (l0_n_vec[j] + omega1_*l1_n + omega2_*l2_n) * ia;
			double area_e = (fa * ia + a*ifa);

			double e = 0.5*(beta*mips_e + alpha * area_e);
			//double e = 0.5*(0.5*mips_e + 0.5 * area_e);
			local_EXP_MIPS_e += e;

			double mips_g_x = (2.0*(omega1_*l1x - omega2_*l2x) - mips_e*l0_T_x)*ia;
			double mips_g_y = (2.0*(omega1_*l1y - omega2_*l2y) - mips_e*l0_T_y)*ia;
			double mips_g_z = (2.0*(omega1_*l1z - omega2_*l2z) - mips_e*l0_T_z)*ia;
			double area_g_x = (a*a - fa*fa)*l0_T_x  * (ifa*ia*ia);
			double area_g_y = (a*a - fa*fa)*l0_T_y  * (ifa*ia*ia);
			double area_g_z = (a*a - fa*fa)*l0_T_z  * (ifa*ia*ia);
			gx += (beta * mips_g_x + alpha*area_g_x)*0.5;
			gy += (beta * mips_g_y + alpha*area_g_y)*0.5;
			gz += (beta * mips_g_z + alpha*area_g_z)*0.5;

			if (l2_n < min_r) { min_r = l2_n; }
		}
		min_r = std::sqrt(min_r) * vertex_radius_ratio[i];
		double xd = -gx;
		double yd = -gy;
		double zd = -gz;

		double d_r = std::sqrt(xd*xd + yd*yd + zd*zd);
		if (d_r > min_r)
		{
			xd = xd * min_r / d_r;
			yd = yd * min_r / d_r;
			zd = zd * min_r / d_r;
			d_r = min_r;
		}

		double npx = p0_x + xd; double npy = p0_y + yd; double npz = p0_z + zd;
		double np_r = std::sqrt(npx*npx + npy*npy + npz*npz); double c = radius_suv / np_r;
		npx *= c; npy *= c; npz *= c;
		while (!local_check_negative_area_SUV(vv_size, npx, npy, npz, p1_p2_cross_x, p1_p2_cross_y, p1_p2_cross_z))
		{
			xd *= 0.8; yd *= 0.8; zd *= 0.8; d_r *= 0.8;
			if (d_r < 1e-10)
			{
				npx = p0_x; npy = p0_y; npz = p0_z;
				break;
			}
			npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
			np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
			npx *= c; npy *= c; npz *= c;
		}

		double new_e = 0;
		//beta = alpha = 0.5;
		bool energy_d = compute_local_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);

		if (!energy_d)
		{
			while (!energy_d)
			{
				xd *= 0.2; yd *= 0.2; zd *= 0.2; d_r *= 0.2;
				if (d_r < 1e-10)
				{
					npx = p0_x; npy = p0_y; npz = p0_z;
					break;
				}
				npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
				np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
				npx *= c; npy *= c; npz *= c;
				energy_d = compute_local_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
			}

			if (energy_d)
			{
				energy_d = false;
				xd *= 5; yd *= 5; zd *= 5; d_r *= 5;
				while (!energy_d)
				{
					xd *= 0.5; yd *= 0.5; zd *= 0.5; d_r *= 0.5;
					if (d_r < 1e-10)
					{
						npx = p0_x; npy = p0_y; npz = p0_z;
						break;
					}
					npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
					np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
					npx *= c; npy *= c; npz *= c;
					energy_d = compute_local_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
				}

				if (energy_d)
				{
					energy_d = false;
					xd *= 2; yd *= 2; zd *= 2; d_r *= 2;
					while (!energy_d)
					{
						xd *= 0.75; yd *= 0.75; zd *= 0.75; d_r *= 0.75;
						if (d_r < 1e-10)
						{
							npx = p0_x; npy = p0_y; npz = p0_z;
							break;
						}
						npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
						np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
						npx *= c; npy *= c; npz *= c;
						energy_d = compute_local_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
					}

					if (energy_d)
					{
						energy_d = false;
						xd /= 0.75; yd /= 0.75; zd /= 0.75; d_r /= 0.75;
						while (!energy_d)
						{
							xd *= 0.945; yd *= 0.945; zd *= 0.945; d_r *= 0.945;
							if (d_r < 1e-10)
							{
								npx = p0_x; npy = p0_y; npz = p0_z;
								break;
							}
							npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
							np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
							npx *= c; npy *= c; npz *= c;
							energy_d = compute_local_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
						}
					}
				}
			}
		}

		new_p_x[i] = npx; new_p_y[i] = npy; new_p_z[i] = npz;
	}
}

void BCD_Sphere_Optimization::MIPS_VOL_Reposition(MyMesh* mesh_, double step_length, double angle_area_ratio)
{
	int nv = new_p_x.size();
	std::vector<double> p1_vec_x(max_vv_size); std::vector<double> p1_vec_y(max_vv_size); std::vector<double> p1_vec_z(max_vv_size);
	std::vector<double> p2_vec_x(max_vv_size); std::vector<double> p2_vec_y(max_vv_size); std::vector<double> p2_vec_z(max_vv_size);
	std::vector<double> l0_n_vec(max_vv_size);
	std::vector<double> p1_p2_cross_x(max_vv_size); std::vector<double> p1_p2_cross_y(max_vv_size); std::vector<double> p1_p2_cross_z(max_vv_size);
	double alpha = angle_area_ratio; double beta = 1.0 - alpha;

	for (int i = 0; i < nv; ++i)
	{
		double p0_x = new_p_x[i]; double p0_y = new_p_y[i]; double p0_z = new_p_z[i];
		double gx = 0.0; double gy = 0.0; double gz = 0.0;
		double local_EXP_MIPS_e = 0.0; double min_r = 1e30;
		int vv_size = vertex_v1[i].size();

		//		std::vector<double>& fh_area_vec = face_area[i]; std::vector<double>& inv_face_area_vec = inv_face_area[i];
		std::vector<double>& fh_vol_vec = face_vol[i]; std::vector<double>& inv_face_vol_vec = inv_face_vol[i];
		std::vector<double>& omega0_vec = omega0[i]; std::vector<double>& omega1_vec = omega1[i]; std::vector<double>& omega2_vec = omega2[i];
		std::vector<int>& v_v1 = vertex_v1[i]; std::vector<int>& v_v2 = vertex_v2[i];

		for (int j = 0; j < vv_size; ++j)
		{
			int vv1 = v_v1[j]; int vv2 = v_v2[j];
			double p1_x = new_p_x[vv1]; double p1_y = new_p_y[vv1]; double p1_z = new_p_z[vv1];
			double p2_x = new_p_x[vv2]; double p2_y = new_p_y[vv2]; double p2_z = new_p_z[vv2];
			p1_vec_x[j] = p1_x; p1_vec_y[j] = p1_y; p1_vec_z[j] = p1_z;
			p2_vec_x[j] = p2_x; p2_vec_y[j] = p2_y; p2_vec_z[j] = p2_z;
			double omega0_ = omega0_vec[j]; double omega1_ = omega1_vec[j]; double omega2_ = omega2_vec[j];
			p1_p2_cross_x[j] = p1_y * p2_z - p1_z*p2_y;
			p1_p2_cross_y[j] = p1_z * p2_x - p1_x*p2_z;
			p1_p2_cross_z[j] = p1_x * p2_y - p1_y*p2_x;

			double l1x = p0_x - p2_x; double l1y = p0_y - p2_y; double l1z = p0_z - p2_z; double l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
			double l2x = p1_x - p0_x; double l2y = p1_y - p0_y; double l2z = p1_z - p0_z; double l2_n = l2x*l2x + l2y*l2y + l2z*l2z;
			double l0x = p2_x - p1_x; double l0y = p2_y - p1_y; double l0z = p2_z - p1_z; double l0_n = l0x*l0x + l0y*l0y + l0z*l0z;

			double nx = -l2y*l1z + l2z*l1y;
			double ny = -l2z*l1x + l2x*l1z;
			double nz = -l2x*l1y + l2y*l1x;

			double a = std::sqrt(nx*nx + ny*ny + nz*nz); double ia = 1.0 / a;
			nx *= ia; ny *= ia; nz *= ia;
			double l0_T_x = ny*l0z - nz *l0y;
			double l0_T_y = nz*l0x - nx *l0z;
			double l0_T_z = nx*l0y - ny *l0x;

			double v = (p0_x*p1_p2_cross_x[j] + p0_y*p1_p2_cross_y[j] + p0_z*p1_p2_cross_z[j]) / 6.0; double iv = 1.0 / v;

			l0_n_vec[j] = omega0_*l0_n;
			//			double fa = fh_area_vec[j]; double ifa = inv_face_area_vec[j];
			double fv = fh_vol_vec[j]; double ifv = inv_face_vol_vec[j];
			double mips_e = (l0_n_vec[j] + omega1_*l1_n + omega2_*l2_n) * ia;
			double area_e = (fv * iv + v*ifv);

			double e = 0.5*(beta*mips_e + alpha * area_e);
			//double e = 0.5*(0.5*mips_e + 0.5 * area_e);
			local_EXP_MIPS_e += e;

			double mips_g_x = (2.0*(omega1_*l1x - omega2_*l2x) - mips_e*l0_T_x)*ia;
			double mips_g_y = (2.0*(omega1_*l1y - omega2_*l2y) - mips_e*l0_T_y)*ia;
			double mips_g_z = (2.0*(omega1_*l1z - omega2_*l2z) - mips_e*l0_T_z)*ia;
			//			double area_g_x = (a*a - fa*fa)*l0_T_x  * (ifa*ia*ia);
			//			double area_g_y = (a*a - fa*fa)*l0_T_y  * (ifa*ia*ia);
			//			double area_g_z = (a*a - fa*fa)*l0_T_z  * (ifa*ia*ia);
			double vol_g_x = (ifv - fv / (v*v))*p1_p2_cross_x[j] / 6.0;
			double vol_g_y = (ifv - fv / (v*v))*p1_p2_cross_y[j] / 6.0;
			double vol_g_z = (ifv - fv / (v*v))*p1_p2_cross_z[j] / 6.0;
			gx += (beta * mips_g_x + alpha*vol_g_x)*0.5;
			gy += (beta * mips_g_y + alpha*vol_g_y)*0.5;
			gz += (beta * mips_g_z + alpha*vol_g_z)*0.5;

			if (l2_n < min_r) { min_r = l2_n; }
		}
		min_r = std::sqrt(min_r) * vertex_radius_ratio[i];
		double xd = -gx;
		double yd = -gy;
		double zd = -gz;

		double d_r = std::sqrt(xd*xd + yd*yd + zd*zd);
		if (d_r > min_r)
		{
			xd = xd * min_r / d_r;
			yd = yd * min_r / d_r;
			zd = zd * min_r / d_r;
			d_r = min_r;
		}

		double npx = p0_x + xd; double npy = p0_y + yd; double npz = p0_z + zd;
		double np_r = std::sqrt(npx*npx + npy*npy + npz*npz); double c = radius_suv / np_r;
		npx *= c; npy *= c; npz *= c;
		while (!local_check_negative_area_SUV(vv_size, npx, npy, npz, p1_p2_cross_x, p1_p2_cross_y, p1_p2_cross_z))
		{
			xd *= 0.8; yd *= 0.8; zd *= 0.8; d_r *= 0.8;
			if (d_r < 1e-10)
			{
				npx = p0_x; npy = p0_y; npz = p0_z;
				break;
			}
			npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
			np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
			npx *= c; npy *= c; npz *= c;
		}

		double new_e = 0;
		//beta = alpha = 0.5;
		bool energy_d = compute_local_MIPS_VOL_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_vol_vec, inv_face_vol_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec, p1_p2_cross_x, p1_p2_cross_y, p1_p2_cross_z);

		if (!energy_d)
		{
			while (!energy_d)
			{
				xd *= 0.2; yd *= 0.2; zd *= 0.2; d_r *= 0.2;
				if (d_r < 1e-10)
				{
					npx = p0_x; npy = p0_y; npz = p0_z;
					break;
				}
				npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
				np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
				npx *= c; npy *= c; npz *= c;
				energy_d = compute_local_MIPS_VOL_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_vol_vec, inv_face_vol_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec, p1_p2_cross_x, p1_p2_cross_y, p1_p2_cross_z);
			}

			if (energy_d)
			{
				energy_d = false;
				xd *= 5; yd *= 5; zd *= 5; d_r *= 5;
				while (!energy_d)
				{
					xd *= 0.5; yd *= 0.5; zd *= 0.5; d_r *= 0.5;
					if (d_r < 1e-10)
					{
						npx = p0_x; npy = p0_y; npz = p0_z;
						break;
					}
					npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
					np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
					npx *= c; npy *= c; npz *= c;
					energy_d = compute_local_MIPS_VOL_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_vol_vec, inv_face_vol_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec, p1_p2_cross_x, p1_p2_cross_y, p1_p2_cross_z);
				}

				if (energy_d)
				{
					energy_d = false;
					xd *= 2; yd *= 2; zd *= 2; d_r *= 2;
					while (!energy_d)
					{
						xd *= 0.75; yd *= 0.75; zd *= 0.75; d_r *= 0.75;
						if (d_r < 1e-10)
						{
							npx = p0_x; npy = p0_y; npz = p0_z;
							break;
						}
						npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
						np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
						npx *= c; npy *= c; npz *= c;
						energy_d = compute_local_MIPS_VOL_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_vol_vec, inv_face_vol_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec, p1_p2_cross_x, p1_p2_cross_y, p1_p2_cross_z);
					}

					if (energy_d)
					{
						energy_d = false;
						xd /= 0.75; yd /= 0.75; zd /= 0.75; d_r /= 0.75;
						while (!energy_d)
						{
							xd *= 0.945; yd *= 0.945; zd *= 0.945; d_r *= 0.945;
							if (d_r < 1e-10)
							{
								npx = p0_x; npy = p0_y; npz = p0_z;
								break;
							}
							npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
							np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
							npx *= c; npy *= c; npz *= c;
							energy_d = compute_local_MIPS_VOL_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_vol_vec, inv_face_vol_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec, p1_p2_cross_x, p1_p2_cross_y, p1_p2_cross_z);
						}
					}
				}
			}
		}

		new_p_x[i] = npx; new_p_y[i] = npy; new_p_z[i] = npz;
	}
}

void BCD_Sphere_Optimization::EXP_MIPS_AREA_Reposition(MyMesh* mesh_, double step_length, double energy_power, double angle_area_ratio)
{
	int nv = new_p_x.size();
	std::vector<double> p1_vec_x(max_vv_size); std::vector<double> p1_vec_y(max_vv_size); std::vector<double> p1_vec_z(max_vv_size);
	std::vector<double> p2_vec_x(max_vv_size); std::vector<double> p2_vec_y(max_vv_size); std::vector<double> p2_vec_z(max_vv_size);
	std::vector<double> l0_n_vec(max_vv_size);
	std::vector<double> p1_p2_cross_x(max_vv_size); std::vector<double> p1_p2_cross_y(max_vv_size); std::vector<double> p1_p2_cross_z(max_vv_size);
	double alpha = angle_area_ratio*energy_power; double beta = energy_power - alpha;

	for (int i = 0; i < nv; ++i)
	{
		//cout<<i<<" iterations  "<<endl;
		double p0_x = new_p_x[i]; double p0_y = new_p_y[i]; double p0_z = new_p_z[i];
		double gx = 0.0; double gy = 0.0; double gz = 0.0;
		double local_EXP_MIPS_e = 0.0; double min_r = 1e30;
		int vv_size = vertex_v1[i].size();

		std::vector<double>& fh_area_vec = face_area[i]; std::vector<double>& inv_face_area_vec = inv_face_area[i];
		std::vector<double>& omega0_vec = omega0[i]; std::vector<double>& omega1_vec = omega1[i]; std::vector<double>& omega2_vec = omega2[i];
		std::vector<int>& v_v1 = vertex_v1[i]; std::vector<int>& v_v2 = vertex_v2[i];
		//#pragma omp parallel for schedule(dynamic)
		for (int j = 0; j < vv_size; ++j)
		{
			int vv1 = v_v1[j]; int vv2 = v_v2[j];
			double p1_x = new_p_x[vv1]; double p1_y = new_p_y[vv1]; double p1_z = new_p_z[vv1];
			double p2_x = new_p_x[vv2]; double p2_y = new_p_y[vv2]; double p2_z = new_p_z[vv2];
			p1_vec_x[j] = p1_x; p1_vec_y[j] = p1_y; p1_vec_z[j] = p1_z;
			p2_vec_x[j] = p2_x; p2_vec_y[j] = p2_y; p2_vec_z[j] = p2_z;
			double omega0_ = omega0_vec[j]; double omega1_ = omega1_vec[j]; double omega2_ = omega2_vec[j];
			p1_p2_cross_x[j] = p1_y * p2_z - p1_z*p2_y;
			p1_p2_cross_y[j] = p1_z * p2_x - p1_x*p2_z;
			p1_p2_cross_z[j] = p1_x * p2_y - p1_y*p2_x;

			double l1x = p0_x - p2_x; double l1y = p0_y - p2_y; double l1z = p0_z - p2_z; double l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
			double l2x = p1_x - p0_x; double l2y = p1_y - p0_y; double l2z = p1_z - p0_z; double l2_n = l2x*l2x + l2y*l2y + l2z*l2z;
			double l0x = p2_x - p1_x; double l0y = p2_y - p1_y; double l0z = p2_z - p1_z; double l0_n = l0x*l0x + l0y*l0y + l0z*l0z;

			double nx = -l2y*l1z + l2z*l1y;
			double ny = -l2z*l1x + l2x*l1z;
			double nz = -l2x*l1y + l2y*l1x;

			double a = std::sqrt(nx*nx + ny*ny + nz*nz); double ia = 1.0 / a;
			nx *= ia; ny *= ia; nz *= ia;
			double l0_T_x = ny*l0z - nz *l0y;
			double l0_T_y = nz*l0x - nx *l0z;
			double l0_T_z = nx*l0y - ny *l0x;

			l0_n_vec[j] = omega0_*l0_n;
			double fa = fh_area_vec[j]; double ifa = inv_face_area_vec[j];
			double mips_e = (l0_n_vec[j] + omega1_*l1_n + omega2_*l2_n) * ia;
			double area_e = (fa * ia + a*ifa);

			//			double k = 0.5*(0.5*mips_e + 0.5 * area_e);
			double k = 0.5*(beta*mips_e + alpha * area_e);
			if (k > 60)
			{
				k = 60;
			}
			double e = std::exp(k); local_EXP_MIPS_e += e;

			double mips_g_x = (2.0*(omega1_*l1x - omega2_*l2x) - mips_e*l0_T_x)*ia;
			double mips_g_y = (2.0*(omega1_*l1y - omega2_*l2y) - mips_e*l0_T_y)*ia;
			double mips_g_z = (2.0*(omega1_*l1z - omega2_*l2z) - mips_e*l0_T_z)*ia;
			double area_g_x = (a*a - fa*fa)*l0_T_x  * (ifa*ia*ia);
			double area_g_y = (a*a - fa*fa)*l0_T_y  * (ifa*ia*ia);
			double area_g_z = (a*a - fa*fa)*l0_T_z  * (ifa*ia*ia);
			gx += e *(beta * mips_g_x + alpha*area_g_x)*0.5;
			gy += e *(beta * mips_g_y + alpha*area_g_y)*0.5;
			gz += e *(beta * mips_g_z + alpha*area_g_z)*0.5;

			if (l2_n < min_r) { min_r = l2_n; }
		}
		min_r = std::sqrt(min_r) * vertex_radius_ratio[i];
		double xd = -gx;
		double yd = -gy;
		double zd = -gz;

		double d_r = std::sqrt(xd*xd + yd*yd + zd*zd);

		if (d_r > min_r)
		{
			xd = xd * min_r / d_r;
			yd = yd * min_r / d_r;
			zd = zd * min_r / d_r;
			d_r = min_r;
		}

		double npx = p0_x + xd; double npy = p0_y + yd; double npz = p0_z + zd;
		double np_r = std::sqrt(npx*npx + npy*npy + npz*npz); double c = radius_suv / np_r; //������radius_suv
		npx *= c; npy *= c; npz *= c;
		while (!local_check_negative_area_SUV(vv_size, npx, npy, npz, p1_p2_cross_x, p1_p2_cross_y, p1_p2_cross_z))
		{
			xd *= 0.8; yd *= 0.8; zd *= 0.8; d_r *= 0.8;
			if (d_r < dr_eps)
			{
				npx = p0_x; npy = p0_y; npz = p0_z;
				break;
			}
			npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
			np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
			npx *= c; npy *= c; npz *= c;
		}

		double new_e = 0;

		//////////////////////////////////////////////////////////////////
		//		local_EXP_MIPS_e = ComputeRefineAmipsEreaEnergy(i,angle_area_ratio,new_p_x[i],new_p_y[i],new_p_z[i],v_v1,v_v2);
		////////////////////////////////////////////////////////////////////

		bool energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
		/*	while (!energy_d)
		{
		xd *= 0.9; yd *= 0.9; zd *= 0.9; d_r *= 0.9;
		if (d_r < 1e-8)
		{
		npx = p0_x; npy = p0_y; npz = p0_z;
		break;
		}
		npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
		np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
		npx *= c; npy *= c; npz *= c;
		energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
		}*/

		if (!energy_d)
		{
			while (!energy_d)
			{
				xd *= 0.2; yd *= 0.2; zd *= 0.2; d_r *= 0.2;
				if (d_r < dr_eps)
				{
					npx = p0_x; npy = p0_y; npz = p0_z;
					break;
				}
				npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
				np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
				npx *= c; npy *= c; npz *= c;
				energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
			}

			if (energy_d)
			{
				energy_d = false;
				xd *= 5; yd *= 5; zd *= 5; d_r *= 5;
				while (!energy_d)
				{
					xd *= 0.5; yd *= 0.5; zd *= 0.5; d_r *= 0.5;
					if (d_r < dr_eps)
					{
						npx = p0_x; npy = p0_y; npz = p0_z;
						break;
					}
					npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
					np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
					npx *= c; npy *= c; npz *= c;
					energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
				}

				if (energy_d)
				{
					energy_d = false;
					xd *= 2; yd *= 2; zd *= 2; d_r *= 2;
					while (!energy_d)
					{
						xd *= 0.75; yd *= 0.75; zd *= 0.75; d_r *= 0.75;
						if (d_r < dr_eps)
						{
							npx = p0_x; npy = p0_y; npz = p0_z;
							break;
						}
						npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
						np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
						npx *= c; npy *= c; npz *= c;
						energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
					}

					if (energy_d)
					{
						energy_d = false;
						xd /= 0.75; yd /= 0.75; zd /= 0.75; d_r /= 0.75;
						while (!energy_d)
						{
							xd *= 0.945; yd *= 0.945; zd *= 0.945; d_r *= 0.945;
							if (d_r < dr_eps)
							{
								npx = p0_x; npy = p0_y; npz = p0_z;
								break;
							}
							npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
							np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
							npx *= c; npy *= c; npz *= c;
							energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
						}
					}
				}
			}
		}
		new_p_x[i] = npx; new_p_y[i] = npy; new_p_z[i] = npz;

	}
	//scale_by_isometric();
}

bool  BCD_Sphere_Optimization::local_check_negative_area_SUV(const int& vv_size, const double& npx, const double& npy, const double& npz,
	const std::vector<double>& p1_p2_cross_x, const std::vector<double>& p1_p2_cross_y, const std::vector<double>& p1_p2_cross_z)
{
	for (int i = 0; i < vv_size; ++i)
	{
		double v = npx*p1_p2_cross_x[i] + npy*p1_p2_cross_y[i] + npz*p1_p2_cross_z[i];
		if (v < overlap_eps)
		{
			return false;
		}
	}
	return true;
}

void BCD_Sphere_Optimization::MIPS_AREA_Reposition_one_V(int i, double step_length, double angle_area_ratio,
	std::vector<double>& l0_n_vec,
	std::vector<double>& p1_vec_x, std::vector<double>& p1_vec_y, std::vector<double>& p1_vec_z,
	std::vector<double>& p2_vec_x, std::vector<double>& p2_vec_y, std::vector<double>& p2_vec_z,
	std::vector<double>& p1_p2_cross_x, std::vector<double>& p1_p2_cross_y, std::vector<double>& p1_p2_cross_z)
{
	double alpha = angle_area_ratio; double beta = 1 - alpha;
	double p0_x = new_p_x[i]; double p0_y = new_p_y[i]; double p0_z = new_p_z[i];
	double gx = 0.0; double gy = 0.0; double gz = 0.0;
	double local_EXP_MIPS_e = 0.0; double min_r = 1e30;
	int vv_size = vertex_v1[i].size();

	std::vector<double>& fh_area_vec = face_area[i]; std::vector<double>& inv_face_area_vec = inv_face_area[i];
	std::vector<double>& omega0_vec = omega0[i]; std::vector<double>& omega1_vec = omega1[i]; std::vector<double>& omega2_vec = omega2[i];
	std::vector<int>& v_v1 = vertex_v1[i]; std::vector<int>& v_v2 = vertex_v2[i];

	for (int j = 0; j < vv_size; ++j)
	{
		int vv1 = v_v1[j]; int vv2 = v_v2[j];
		double p1_x = new_p_x[vv1]; double p1_y = new_p_y[vv1]; double p1_z = new_p_z[vv1];
		double p2_x = new_p_x[vv2]; double p2_y = new_p_y[vv2]; double p2_z = new_p_z[vv2];

		p1_vec_x[j] = p1_x; p1_vec_y[j] = p1_y; p1_vec_z[j] = p1_z;
		p2_vec_x[j] = p2_x; p2_vec_y[j] = p2_y; p2_vec_z[j] = p2_z;
		double omega0_ = omega0_vec[j]; double omega1_ = omega1_vec[j]; double omega2_ = omega2_vec[j];
		p1_p2_cross_x[j] = p1_y * p2_z - p1_z*p2_y;
		p1_p2_cross_y[j] = p1_z * p2_x - p1_x*p2_z;
		p1_p2_cross_z[j] = p1_x * p2_y - p1_y*p2_x;

		double l1x = p0_x - p2_x; double l1y = p0_y - p2_y; double l1z = p0_z - p2_z; double l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
		double l2x = p1_x - p0_x; double l2y = p1_y - p0_y; double l2z = p1_z - p0_z; double l2_n = l2x*l2x + l2y*l2y + l2z*l2z;
		double l0x = p2_x - p1_x; double l0y = p2_y - p1_y; double l0z = p2_z - p1_z; double l0_n = l0x*l0x + l0y*l0y + l0z*l0z;

		double nx = -l2y*l1z + l2z*l1y;
		double ny = -l2z*l1x + l2x*l1z;
		double nz = -l2x*l1y + l2y*l1x;

		double a = std::sqrt(nx*nx + ny*ny + nz*nz); double ia = 1.0 / a;
		nx *= ia; ny *= ia; nz *= ia;
		double l0_T_x = ny*l0z - nz *l0y;
		double l0_T_y = nz*l0x - nx *l0z;
		double l0_T_z = nx*l0y - ny *l0x;

		l0_n_vec[j] = omega0_*l0_n;
		double fa = fh_area_vec[j]; double ifa = inv_face_area_vec[j];
		double mips_e = (l0_n_vec[j] + omega1_*l1_n + omega2_*l2_n) * ia;
		double area_e = (fa * ia + a*ifa);

		double e = 0.5*(beta*mips_e + alpha * area_e);
		//		double e = 0.5*(0.5*mips_e + 0.5 * area_e);
		local_EXP_MIPS_e += e;

		double mips_g_x = (2.0*(omega1_*l1x - omega2_*l2x) - mips_e*l0_T_x)*ia;
		double mips_g_y = (2.0*(omega1_*l1y - omega2_*l2y) - mips_e*l0_T_y)*ia;
		double mips_g_z = (2.0*(omega1_*l1z - omega2_*l2z) - mips_e*l0_T_z)*ia;
		double area_g_x = (a*a - fa*fa)*l0_T_x  * (ifa*ia*ia);
		double area_g_y = (a*a - fa*fa)*l0_T_y  * (ifa*ia*ia);
		double area_g_z = (a*a - fa*fa)*l0_T_z  * (ifa*ia*ia);
		gx += (beta * mips_g_x + alpha*area_g_x)*0.5;
		gy += (beta * mips_g_y + alpha*area_g_y)*0.5;
		gz += (beta * mips_g_z + alpha*area_g_z)*0.5;

		if (l2_n < min_r) { min_r = l2_n; }
	}
	min_r = std::sqrt(min_r) * vertex_radius_ratio[i];
	double xd = -gx;
	double yd = -gy;
	double zd = -gz;

	double d_r = std::sqrt(xd*xd + yd*yd + zd*zd);
	if (d_r > min_r)
	{
		xd = xd * min_r / d_r;
		yd = yd * min_r / d_r;
		zd = zd * min_r / d_r;
		d_r = min_r;
	}

	double npx = p0_x + xd; double npy = p0_y + yd; double npz = p0_z + zd;
	double np_r = std::sqrt(npx*npx + npy*npy + npz*npz); double c = radius_suv / np_r;
	npx *= c; npy *= c; npz *= c;

	while (!local_check_negative_area_SUV(vv_size, npx, npy, npz, p1_p2_cross_x, p1_p2_cross_y, p1_p2_cross_z))
	{
		xd *= 0.8; yd *= 0.8; zd *= 0.8; d_r *= 0.8;
		if (d_r < dr_eps)
		{
			npx = p0_x; npy = p0_y; npz = p0_z;
			break;
		}
		npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
		np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
		npx *= c; npy *= c; npz *= c;
	}

	double new_e = 0;
	bool energy_d = compute_local_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);

	if (!energy_d)
	{
		while (!energy_d)
		{
			xd *= 0.2; yd *= 0.2; zd *= 0.2; d_r *= 0.2;
			if (d_r < dr_eps)
			{
				npx = p0_x; npy = p0_y; npz = p0_z;
				break;
			}
			npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
			np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
			npx *= c; npy *= c; npz *= c;
			energy_d = compute_local_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
		}

		if (energy_d)
		{
			energy_d = false;
			xd *= 5; yd *= 5; zd *= 5; d_r *= 5;
			while (!energy_d)
			{
				xd *= 0.5; yd *= 0.5; zd *= 0.5; d_r *= 0.5;
				if (d_r < dr_eps)
				{
					npx = p0_x; npy = p0_y; npz = p0_z;
					break;
				}
				npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
				np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
				npx *= c; npy *= c; npz *= c;
				energy_d = compute_local_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
			}

			if (energy_d)
			{
				energy_d = false;
				xd *= 2; yd *= 2; zd *= 2; d_r *= 2;
				while (!energy_d)
				{
					xd *= 0.75; yd *= 0.75; zd *= 0.75; d_r *= 0.75;
					if (d_r < dr_eps)
					{
						npx = p0_x; npy = p0_y; npz = p0_z;
						break;
					}
					npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
					np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
					npx *= c; npy *= c; npz *= c;
					energy_d = compute_local_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
				}

				if (energy_d)
				{
					energy_d = false;
					xd /= 0.75; yd /= 0.75; zd /= 0.75; d_r /= 0.75;
					while (!energy_d)
					{
						xd *= 0.945; yd *= 0.945; zd *= 0.945; d_r *= 0.945;
						if (d_r < dr_eps)
						{
							npx = p0_x; npy = p0_y; npz = p0_z;
							break;
						}
						npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
						np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
						npx *= c; npy *= c; npz *= c;
						energy_d = compute_local_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
					}
				}
			}
		}
	}

	new_p_x[i] = npx; new_p_y[i] = npy; new_p_z[i] = npz;
}
void BCD_Sphere_Optimization::EXP_MIPS_AREA_Reposition_one_V(int i, double step_length, double energy_power, double angle_area_ratio,
	std::vector<double>& l0_n_vec,
	std::vector<double>& p1_vec_x, std::vector<double>& p1_vec_y, std::vector<double>& p1_vec_z,
	std::vector<double>& p2_vec_x, std::vector<double>& p2_vec_y, std::vector<double>& p2_vec_z,
	std::vector<double>& p1_p2_cross_x, std::vector<double>& p1_p2_cross_y, std::vector<double>& p1_p2_cross_z)
{
	double alpha = angle_area_ratio; double beta = 1.0 - alpha;
	double p0_x = new_p_x[i]; double p0_y = new_p_y[i]; double p0_z = new_p_z[i];
	double gx = 0.0; double gy = 0.0; double gz = 0.0;
	double local_EXP_MIPS_e = 0.0; double min_r = 1e30;
	int vv_size = vertex_v1[i].size();

	std::vector<double>& fh_area_vec = face_area[i]; std::vector<double>& inv_face_area_vec = inv_face_area[i];
	std::vector<double>& omega0_vec = omega0[i]; std::vector<double>& omega1_vec = omega1[i]; std::vector<double>& omega2_vec = omega2[i];
	std::vector<int>& v_v1 = vertex_v1[i]; std::vector<int>& v_v2 = vertex_v2[i];

	for (int j = 0; j < vv_size; ++j)
	{
		int vv1 = v_v1[j]; int vv2 = v_v2[j];
		double p1_x = new_p_x[vv1]; double p1_y = new_p_y[vv1]; double p1_z = new_p_z[vv1];
		double p2_x = new_p_x[vv2]; double p2_y = new_p_y[vv2]; double p2_z = new_p_z[vv2];

		p1_vec_x[j] = p1_x; p1_vec_y[j] = p1_y; p1_vec_z[j] = p1_z;
		p2_vec_x[j] = p2_x; p2_vec_y[j] = p2_y; p2_vec_z[j] = p2_z;
		double omega0_ = omega0_vec[j]; double omega1_ = omega1_vec[j]; double omega2_ = omega2_vec[j];
		p1_p2_cross_x[j] = p1_y * p2_z - p1_z*p2_y;
		p1_p2_cross_y[j] = p1_z * p2_x - p1_x*p2_z;
		p1_p2_cross_z[j] = p1_x * p2_y - p1_y*p2_x;

		double l1x = p0_x - p2_x; double l1y = p0_y - p2_y; double l1z = p0_z - p2_z; double l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
		double l2x = p1_x - p0_x; double l2y = p1_y - p0_y; double l2z = p1_z - p0_z; double l2_n = l2x*l2x + l2y*l2y + l2z*l2z;
		double l0x = p2_x - p1_x; double l0y = p2_y - p1_y; double l0z = p2_z - p1_z; double l0_n = l0x*l0x + l0y*l0y + l0z*l0z;

		double nx = -l2y*l1z + l2z*l1y;
		double ny = -l2z*l1x + l2x*l1z;
		double nz = -l2x*l1y + l2y*l1x;

		double a = std::sqrt(nx*nx + ny*ny + nz*nz); double ia = 1.0 / a;
		nx *= ia; ny *= ia; nz *= ia;
		double l0_T_x = ny*l0z - nz *l0y;
		double l0_T_y = nz*l0x - nx *l0z;
		double l0_T_z = nx*l0y - ny *l0x;

		l0_n_vec[j] = omega0_*l0_n;
		double fa = fh_area_vec[j]; double ifa = inv_face_area_vec[j];
		double mips_e = (l0_n_vec[j] + omega1_*l1_n + omega2_*l2_n) * ia;
		double area_e = (fa * ia + a*ifa);

		double mips_area = 0.5*(beta*mips_e + alpha * area_e);
		double k = f->get(mips_area);
		if (k > 60)
		{
			k = 60;
		}
		double e = fmath::expd(k); local_EXP_MIPS_e += e;
		double mips_g_x = (2.0*(omega1_*l1x - omega2_*l2x) - mips_e*l0_T_x)*ia;
		double mips_g_y = (2.0*(omega1_*l1y - omega2_*l2y) - mips_e*l0_T_y)*ia;
		double mips_g_z = (2.0*(omega1_*l1z - omega2_*l2z) - mips_e*l0_T_z)*ia;
		double area_g_x = (a*a - fa*fa)*l0_T_x  * (ifa*ia*ia);
		double area_g_y = (a*a - fa*fa)*l0_T_y  * (ifa*ia*ia);
		double area_g_z = (a*a - fa*fa)*l0_T_z  * (ifa*ia*ia);
		gx += e *(beta * mips_g_x + alpha*area_g_x)*k / mips_area*0.5*energy_power;
		gy += e *(beta * mips_g_y + alpha*area_g_y)*k / mips_area*0.5*energy_power;
		gz += e *(beta * mips_g_z + alpha*area_g_z)*k / mips_area*0.5*energy_power;

		if (l2_n < min_r) { min_r = l2_n; }
	}
	min_r = std::sqrt(min_r) * vertex_radius_ratio[i];
	double xd = -gx;
	double yd = -gy;
	double zd = -gz;

	double d_r = std::sqrt(xd*xd + yd*yd + zd*zd);
	if (d_r > min_r)
	{
		xd = xd * min_r / d_r;
		yd = yd * min_r / d_r;
		zd = zd * min_r / d_r;
		d_r = min_r;
	}

	double npx = p0_x + xd; double npy = p0_y + yd; double npz = p0_z + zd;
	double np_r = std::sqrt(npx*npx + npy*npy + npz*npz); double c = radius_suv / np_r;
	npx *= c; npy *= c; npz *= c;

	while (!local_check_negative_area_SUV(vv_size, npx, npy, npz, p1_p2_cross_x, p1_p2_cross_y, p1_p2_cross_z))
	{
		xd *= 0.8; yd *= 0.8; zd *= 0.8; d_r *= 0.8;
		if (d_r < dr_eps)
		{
			npx = p0_x; npy = p0_y; npz = p0_z;
			break;
		}
		npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
		np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
		npx *= c; npy *= c; npz *= c;
	}
	double new_e = 0;
	bool energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);

	if (!energy_d)
	{
		while (!energy_d)
		{
			xd *= 0.2; yd *= 0.2; zd *= 0.2; d_r *= 0.2;
			if (d_r <dr_eps)
			{
				npx = p0_x; npy = p0_y; npz = p0_z;
				break;
			}
			npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
			np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
			npx *= c; npy *= c; npz *= c;
			energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
		}

		if (energy_d)
		{
			energy_d = false;
			xd *= 5; yd *= 5; zd *= 5; d_r *= 5;
			while (!energy_d)
			{
				xd *= 0.5; yd *= 0.5; zd *= 0.5; d_r *= 0.5;
				if (d_r < dr_eps)
				{
					npx = p0_x; npy = p0_y; npz = p0_z;
					break;
				}
				npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
				np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
				npx *= c; npy *= c; npz *= c;
				energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
			}

			if (energy_d)
			{
				energy_d = false;
				xd *= 2; yd *= 2; zd *= 2; d_r *= 2;
				while (!energy_d)
				{
					xd *= 0.75; yd *= 0.75; zd *= 0.75; d_r *= 0.75;
					if (d_r < dr_eps)
					{
						npx = p0_x; npy = p0_y; npz = p0_z;
						break;
					}
					npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
					np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
					npx *= c; npy *= c; npz *= c;
					energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
				}

				if (energy_d)
				{
					energy_d = false;
					xd /= 0.75; yd /= 0.75; zd /= 0.75; d_r /= 0.75;
					while (!energy_d)
					{
						xd *= 0.945; yd *= 0.945; zd *= 0.945; d_r *= 0.945;
						if (d_r < dr_eps)
						{
							npx = p0_x; npy = p0_y; npz = p0_z;
							break;
						}
						npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
						np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
						npx *= c; npy *= c; npz *= c;
						energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
					}
				}
			}
		}
	}
	new_p_x[i] = npx; new_p_y[i] = npy; new_p_z[i] = npz;
}

bool  BCD_Sphere_Optimization::compute_local_MIPS_AREA_energy(double& new_e, const double& old_e, const int& vv_size,
	const double& npx, const double& npy, const double& npz,
	const double& beta, const double& alpha,
	const std::vector<double>& fh_area_vec, const std::vector<double>& inv_fh_area_vec,
	const std::vector<double>& l0_n_vec,
	const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
	const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
	const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec)
{
	new_e = 0.0; double l1x, l1y, l1z, l1_n, l2x, l2y, l2z, l2_n;
	double nx, ny, nz, a, ia; double mips_e, area_e, k;

	for (int i = 0; i < vv_size; ++i)
	{
		l1x = npx - p2_vec_x[i];  l1y = npy - p2_vec_y[i];  l1z = npz - p2_vec_z[i];  l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
		l2x = p1_vec_x[i] - npx;  l2y = p1_vec_y[i] - npy;  l2z = p1_vec_z[i] - npz;  l2_n = l2x*l2x + l2y*l2y + l2z*l2z;

		nx = -l2y*l1z + l2z*l1y;
		ny = -l2z*l1x + l2x*l1z;
		nz = -l2x*l1y + l2y*l1x;

		a = std::sqrt(nx*nx + ny*ny + nz*nz); ia = 1.0 / a;

		mips_e = (l0_n_vec[i] + omega1_vec[i] * l1_n + omega2_vec[i] * l2_n) *ia;
		area_e = (fh_area_vec[i] / a + a / fh_area_vec[i]);
		new_e += 0.5*(beta*mips_e + alpha * area_e);
		//		new_e += 0.5*(0.5*mips_e + 0.5 * area_e);
		if (new_e > old_e) return false;
	}
	return true;
}

bool BCD_Sphere_Optimization::compute_local_MIPS_VOL_energy(double& new_e, const double& old_e, const int& vv_size,
	const double& npx, const double& npy, const double& npz,
	const double& beta, const double& alpha,
	const std::vector<double>& fh_vol_vec, const std::vector<double>& inv_fh_vol_vec,
	const std::vector<double>& l0_n_vec,
	const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
	const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
	const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec,
	const std::vector<double>& p1_p2_cross_x, const std::vector<double>& p1_p2_cross_y, const std::vector<double>& p1_p2_cross_z)
{
	new_e = 0.0; double l1x, l1y, l1z, l1_n, l2x, l2y, l2z, l2_n;
	double nx, ny, nz, v, iv, a, ia; double mips_e, vol_e, k;

	for (int i = 0; i < vv_size; ++i)
	{
		l1x = npx - p2_vec_x[i];  l1y = npy - p2_vec_y[i];  l1z = npz - p2_vec_z[i];  l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
		l2x = p1_vec_x[i] - npx;  l2y = p1_vec_y[i] - npy;  l2z = p1_vec_z[i] - npz;  l2_n = l2x*l2x + l2y*l2y + l2z*l2z;

		nx = -l2y*l1z + l2z*l1y;
		ny = -l2z*l1x + l2x*l1z;
		nz = -l2x*l1y + l2y*l1x;

		a = std::sqrt(nx*nx + ny*ny + nz*nz); ia = 1.0 / a;
		v = (npx*p1_p2_cross_x[i] + npy*p1_p2_cross_y[i] + npz*p1_p2_cross_z[i]) / 6.0;
		iv = 1.0 / v;
		mips_e = (l0_n_vec[i] + omega1_vec[i] * l1_n + omega2_vec[i] * l2_n) *ia;
		vol_e = (fh_vol_vec[i] / a + a / fh_vol_vec[i]);
		new_e += 0.5*(beta*mips_e + alpha * vol_e);
		//		new_e += 0.5*(0.5*mips_e + 0.5 * area_e);
		if (new_e > old_e) return false;
	}
	return true;
}

bool BCD_Sphere_Optimization::compute_local_EXP_MIPS_AREA_energy(double& new_e, const double& old_e, const int& vv_size, const double& npx, const double& npy, const double& npz,
	const double& beta, const double& alpha,
	const std::vector<double>& fh_area_vec, const std::vector<double>& inv_fh_area_vec,
	const std::vector<double>& l0_n_vec,
	const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
	const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
	const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec)
{
	new_e = 0.0; double l1x, l1y, l1z, l1_n, l2x, l2y, l2z, l2_n;
	double nx, ny, nz, a, ia; double mips_e, area_e, k;
	for (int i = 0; i < vv_size; ++i)
	{
		l1x = npx - p2_vec_x[i];  l1y = npy - p2_vec_y[i];  l1z = npz - p2_vec_z[i];  l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
		l2x = p1_vec_x[i] - npx;  l2y = p1_vec_y[i] - npy;  l2z = p1_vec_z[i] - npz;  l2_n = l2x*l2x + l2y*l2y + l2z*l2z;

		nx = -l2y*l1z + l2z*l1y;
		ny = -l2z*l1x + l2x*l1z;
		nz = -l2x*l1y + l2y*l1x;;

		a = std::sqrt(nx*nx + ny*ny + nz*nz); ia = 1.0 / a;

		mips_e = (l0_n_vec[i] + omega1_vec[i] * l1_n + omega2_vec[i] * l2_n) *ia;
		area_e = (fh_area_vec[i] / a + a / fh_area_vec[i]);
		double mips_area = 0.5*(beta*mips_e + alpha * area_e);
		double k = f->get(mips_area);
		if (k > 60) { k = 60; }
		//new_e += std::exp(k);
		new_e += fmath::expd(k);
		if (old_e < new_e) return false;
	}
	return true;
}

void BCD_Sphere_Optimization::PrintObj(string fileName, MyMesh *m)
{
	FILE *out;
	string str_1 = ".obj";
	string fn = fileName + str_1;
	if ((out = fopen(fn.c_str(), "wt+")) == NULL)
		//if( (out = fopen("AMIPS_NOS.obj","wt+")) == NULL)
	{
		return;
	}

	fprintf(out, "\n");
	fprintf(out, "# Wavefront OBJ\n");
	fprintf(out, "#\n");
	fprintf(out, "\n");
	fprintf(out, "# %d vertices,%d triangles, 1 groups\n", m->n_vertices(), m->n_faces());
	fprintf(out, "\n");
	fprintf(out, "\n");

	for (auto it = m->vertices_begin(); it != m->vertices_end(); ++it)
	{
		MyMesh::Point p = m->point(it);
		//fprintf(out,"v %lf %lf %lf\n",tmp.x,tmp.y,tmp.z);
		fprintf(out, "v %.14lf %.14lf %.14lf\n", p[0], p[1], p[2]);
	}
	fprintf(out, "\n");
	for (auto f_it = m->faces_begin(); f_it != m->faces_end(); ++f_it)
	{
		vector<int> vs;
		for (auto fv_it = m->fv_begin(f_it); fv_it != m->fv_end(f_it); ++fv_it)
		{
			vs.push_back(fv_it.handle().idx());
		}
		assert(vs.size() == 3 && "The mesh isn't triangular mesh!");

		int v1_idx = vs[0];
		int v2_idx = vs[1];
		int v3_idx = vs[2];
		{
			fprintf(out, "f %d %d %d\n", v1_idx + 1, v2_idx + 1, v3_idx + 1);
		}
	}
	fclose(out);
}

double BCD_Sphere_Optimization::ComputeAngle(Eigen::Vector3d v1, Eigen::Vector3d v2)
{
	double t = v1.dot(v2) / (v1.norm()*v2.norm());
	double theta = acos(t);
	return theta;
}

void BCD_Sphere_Optimization::save_graph(const char* filename)
{
	FILE* f_g = fopen(filename, "w");

	int nv = mesh->n_vertices();
	fprintf(f_g, "%d", nv);
	//	vector<vector<int>> vv;
	//	for (int i = 0; i < Scene->m_vVerIterList.size(); ++i)
	//	{
	//		vector<int> vec = Scene->FindVertexNeighbours(i);
	//		for (int j = 0;j < vec.size();j++)
	//		{
	//			cout<<nv<<"       "<<i<<"        "<<vec[j]<<endl;
	//		}
	////		vv.push_back(vec);
	//	}
	for (auto v_it = mesh->vertices_begin(); v_it != mesh->vertices_end(); ++v_it)
	{
		vector<int> vec;
		for (auto vv_it = mesh->vv_begin(v_it); vv_it != mesh->vv_end(v_it); ++vv_it)
		{
			vec.push_back(vv_it.handle().idx());
		}

		fprintf(f_g, "\n%d", vec.size());
		for (int j = 0; j < vec.size(); ++j)
		{
			fprintf(f_g, " %d", vec[j]);
		}
	}

	fclose(f_g);
}

void BCD_Sphere_Optimization::load_vertex_color(const char* filename)
{
	ifstream fp_1;
	fp_1.open(filename);
	int nv = mesh->n_vertices();

	int v_id_, c_;
	max_vertex_color = 0;
	int v_count = 0;
	vector<int> mycolor;
	mycolor.resize(nv);
	for (int i = 0; i<nv; i++)
	{
		fp_1 >> v_id_ >> c_;
		mycolor[v_id_] = c_;
		if (c_ > max_vertex_color) max_vertex_color = c_;
	}
	fp_1.close();

	number_of_color = max_vertex_color;
	//printf("Number Of Colors: %d\n", max_vertex_color);
	vertex_diff_color.clear();
	if (number_of_color == 0)
	{
		vertex_diff_color.resize(nv);
	}
	else
	{
		vertex_diff_color.resize(number_of_color);

	}

	for (int i = 0; i <nv; ++i)
	{
		//cout<<i<<"   mycolor   "<<mycolor[i] <<endl;
		vertex_diff_color[mycolor[i] - 1].push_back(i);

	}

	for (auto v_it = mesh->vertices_begin(); v_it != mesh->vertices_end(); ++v_it)
	{
		vector<int> nei;
		for (auto vv_it = mesh->vv_begin(v_it); vv_it != mesh->vv_end(v_it); ++vv_it)
		{
			nei.push_back(vv_it.handle().idx());
		}
		for (int j = 0; j < nei.size(); ++j)
		{
			int a = mycolor[v_it.handle().idx()] - mycolor[nei[j]];
			if (abs(a) <= 0)
			{
				cout << "There is error!!" << endl;
			}
		}
	}
}

void BCD_Sphere_Optimization::scale_by_isometric()
{
	////ComputeNewTriangleArea();
	//double scale = 0.0;
	//double mid1 = 0;
	//double mid2 = 0;
	//for (int i = 0;i<Scene->m_nTriangles;i++)
	//{
	//	mid1 = mid1 + origin_triangle_area[i]/new_triangle_area[i];
	//	mid2 = mid2 + new_triangle_area[i]/origin_triangle_area[i];
	//}
	//scale = sqrt(sqrt(mid1/mid2));
	//for (int i = 0;i<new_p_x.size();i++)
	//{
	////	sphere_coor[0][i] *= scale; 
	//	new_p_x[i] *= scale;
	//	new_p_y[i] *= scale;
	//	new_p_z[i] *= scale;
	//}
	//radius_suv *= scale;
	//cout<<"scale: "<<scale<<endl;
}


bool BCD_Sphere_Optimization::compute_local_ISOMETRIC_energy(double& new_e, const double& old_e, const int& vv_size,
	const double& npx, const double& npy, const double& npz,
	const double& beta, const double& alpha,
	const std::vector<double>& fh_area_vec, const std::vector<double>& inv_fh_area_vec,
	const std::vector<double>& l0_n_vec,
	const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
	const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
	const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec)
{
	new_e = 0.0; double l1x, l1y, l1z, l1_n, l2x, l2y, l2z, l2_n;
	double nx, ny, nz, a, ia; double mips_e, area_e, k;
	for (int i = 0; i < vv_size; ++i)
	{
		l1x = npx - p2_vec_x[i];  l1y = npy - p2_vec_y[i];  l1z = npz - p2_vec_z[i];  l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
		l2x = p1_vec_x[i] - npx;  l2y = p1_vec_y[i] - npy;  l2z = p1_vec_z[i] - npz;  l2_n = l2x*l2x + l2y*l2y + l2z*l2z;

		nx = -l2y*l1z + l2z*l1y;
		ny = -l2z*l1x + l2x*l1z;
		nz = -l2x*l1y + l2y*l1x;;

		a = std::sqrt(nx*nx + ny*ny + nz*nz); ia = 1.0 / a;

		mips_e = (l0_n_vec[i] + omega1_vec[i] * l1_n + omega2_vec[i] * l2_n) *ia;
		area_e = (fh_area_vec[i] / a + a / fh_area_vec[i]);
		new_e += 0.5*(beta*mips_e + alpha * area_e);
		if (new_e > old_e) return false;
	}
	return true;

}

bool BCD_Sphere_Optimization::compute_local_MIPS_energy(double& new_e, const double& old_e, const int& vv_size,
	const double& npx, const double& npy, const double& npz,
	const double& beta, const double& alpha,
	const std::vector<double>& fh_area_vec, const std::vector<double>& inv_fh_area_vec,
	const std::vector<double>& l0_n_vec,
	const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
	const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
	const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec)
{
	new_e = 0.0; double l1x, l1y, l1z, l1_n, l2x, l2y, l2z, l2_n;
	double nx, ny, nz, a, ia; double mips_e, area_e, k;
	for (int i = 0; i < vv_size; ++i)
	{
		l1x = npx - p2_vec_x[i];  l1y = npy - p2_vec_y[i];  l1z = npz - p2_vec_z[i];  l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
		l2x = p1_vec_x[i] - npx;  l2y = p1_vec_y[i] - npy;  l2z = p1_vec_z[i] - npz;  l2_n = l2x*l2x + l2y*l2y + l2z*l2z;

		nx = -l2y*l1z + l2z*l1y;
		ny = -l2z*l1x + l2x*l1z;
		nz = -l2x*l1y + l2y*l1x;;

		a = std::sqrt(nx*nx + ny*ny + nz*nz); ia = 1.0 / a;

		mips_e = (l0_n_vec[i] + omega1_vec[i] * l1_n + omega2_vec[i] * l2_n) *ia;
		area_e = (fh_area_vec[i] / a + a / fh_area_vec[i]);
		//new_e += 0.5*(beta*mips_e + alpha * area_e);
		new_e += mips_e;
		if (new_e > old_e) return false;
	}
	return true;
}

double BCD_Sphere_Optimization::ComputeNewRadius()
{
	double S = 0;
	double s = 0.0;
	for (auto f_it = origin_mesh->faces_begin(); f_it != origin_mesh->faces_end(); ++f_it)
	{
		vector<int> v;
		for (auto fv = origin_mesh->fv_begin(f_it); fv != origin_mesh->fv_end(f_it); ++fv)
		{
			v.push_back(fv.handle().idx());
		}
		assert(v.size() == 3 && "The mesh isn't triangular mesh!");

		Eigen::Vector3d v0(origin_mesh->point(origin_mesh->vertex_handle(v[0]))[0], origin_mesh->point(origin_mesh->vertex_handle(v[0]))[1], origin_mesh->point(origin_mesh->vertex_handle(v[0]))[2]);
		Eigen::Vector3d v1(origin_mesh->point(origin_mesh->vertex_handle(v[1]))[0], origin_mesh->point(origin_mesh->vertex_handle(v[1]))[1], origin_mesh->point(origin_mesh->vertex_handle(v[1]))[2]);
		Eigen::Vector3d v2(origin_mesh->point(origin_mesh->vertex_handle(v[2]))[0], origin_mesh->point(origin_mesh->vertex_handle(v[2]))[1], origin_mesh->point(origin_mesh->vertex_handle(v[2]))[2]);
		Eigen::Vector3d s_ = (v1 - v0).cross(v2 - v1);
		s = 0.5*s_.norm();
		S += s;
	}
	double r = sqrt(S / 4 / 3.1415926);
	return r;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool BCD_Sphere_Optimization::Judge_local_distortion_v(MyMesh::VertexHandle &v, int threshold)
{
	double new_e = 0;
	//	cot_angla = 1.0/std::sqrt(3.0);
	//	fa_area = 4.0*3.14159*radius_suv*radius_suv; fa_area /= (double)(mesh->n_faces());fa_area *= 2.0;
	size_nei = mesh->valence(v);
	p1_nei_x.resize(size_nei);
	p1_nei_y.resize(size_nei);
	p1_nei_z.resize(size_nei);
	p2_nei_x.resize(size_nei);
	p2_nei_y.resize(size_nei);
	p2_nei_z.resize(size_nei);
	int counter = 0;
	for (MyMesh::VertexOHalfedgeIter voh_it = mesh->voh_iter(v); voh_it; ++voh_it)
	{
		MyMesh::FaceHandle fh = mesh->face_handle(voh_it);
		if (fh != MyMesh::InvalidFaceHandle)
		{
			OpenMesh::HalfedgeHandle heh0 = mesh->next_halfedge_handle(voh_it);
			OpenMesh::HalfedgeHandle heh1 = mesh->prev_halfedge_handle(voh_it);

			MyMesh::Point p1 = mesh->point(mesh->to_vertex_handle(voh_it));
			MyMesh::Point p2 = mesh->point(mesh->to_vertex_handle(mesh->next_halfedge_handle(voh_it)));
			p1_nei_x[counter] = p1[0]; p1_nei_y[counter] = p1[1]; p1_nei_z[counter] = p1[2];
			p2_nei_x[counter] = p2[0]; p2_nei_y[counter] = p2[1]; p2_nei_z[counter] = p2[2];
			counter++;
		}
	}
	MyMesh::Point p = mesh->point(v);
	current_x = p[0]; current_y = p[1]; current_z = p[2];
	double l1x, l1y, l1z, l1_n, l2x, l2y, l2z, l2_n, l0x, l0y, l0z, l0_n;
	double nx, ny, nz, a, ia; double mips_e, area_e, k;

	for (int i = 0; i < size_nei; ++i)
	{
		l1x = current_x - p2_nei_x[i];  l1y = current_y - p2_nei_y[i];  l1z = current_z - p2_nei_z[i];  l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
		l2x = p1_nei_x[i] - current_x;  l2y = p1_nei_y[i] - current_y;  l2z = p1_nei_z[i] - current_z;  l2_n = l2x*l2x + l2y*l2y + l2z*l2z;
		l0x = p2_nei_x[i] - p1_nei_x[i]; l0y = p2_nei_y[i] - p1_nei_y[i]; l0z = p2_nei_z[i] - p1_nei_z[i]; l0_n = l0x*l0x + l0y*l0y + l0z*l0z;

		nx = -l2y*l1z + l2z*l1y;
		ny = -l2z*l1x + l2x*l1z;
		nz = -l2x*l1y + l2y*l1x;

		a = std::sqrt(nx*nx + ny*ny + nz*nz); ia = 1.0 / a;

		mips_e = cot_angla*(l0_n + l1_n + l2_n) *ia;
		area_e = (fa_area / a + a / fa_area);
		new_e += 0.5*(0.5 * mips_e + 0.5 * area_e);
	}
	if (new_e > (threshold*size_nei))
	{
		return true;
	}
	return false;
}

void BCD_Sphere_Optimization::Local_EXP_MIPS_AREA_Reposition_v(MyMesh::VertexHandle &v, double energy_power, double angle_area_ratio)
{
	size_nei = mesh->valence(v);
	std::vector<double> p1_vec_x(size_nei); std::vector<double> p1_vec_y(size_nei); std::vector<double> p1_vec_z(size_nei);
	std::vector<double> p2_vec_x(size_nei); std::vector<double> p2_vec_y(size_nei); std::vector<double> p2_vec_z(size_nei);
	std::vector<double> l0_n_vec(size_nei);
	std::vector<double> p1_p2_cross_x(size_nei); std::vector<double> p1_p2_cross_y(size_nei); std::vector<double> p1_p2_cross_z(size_nei);
	double alpha = angle_area_ratio*energy_power; double beta = energy_power - alpha;
	double p0_x = mesh->point(v)[0]; double p0_y = mesh->point(v)[1]; double p0_z = mesh->point(v)[2];
	double gx = 0.0; double gy = 0.0; double gz = 0.0;
	double local_EXP_MIPS_e = 0.0; double min_r = 1e30;
	int vv_size = size_nei;

	std::vector<double> fh_area_vec(size_nei, fa_area); std::vector<double> inv_face_area_vec(size_nei, 1.0 / fa_area);
	std::vector<double> omega0_vec(size_nei, cot_angla); std::vector<double> omega1_vec(size_nei, cot_angla); std::vector<double> omega2_vec(size_nei, cot_angla);

	int counter = 0;
	for (MyMesh::VertexOHalfedgeIter voh_it = mesh->voh_iter(v); voh_it; ++voh_it)
	{
		MyMesh::FaceHandle fh = mesh->face_handle(voh_it);
		if (fh != MyMesh::InvalidFaceHandle)
		{
			OpenMesh::HalfedgeHandle heh0 = mesh->next_halfedge_handle(voh_it);
			OpenMesh::HalfedgeHandle heh1 = mesh->prev_halfedge_handle(voh_it);

			MyMesh::Point p1 = mesh->point(mesh->to_vertex_handle(voh_it));
			MyMesh::Point p2 = mesh->point(mesh->to_vertex_handle(mesh->next_halfedge_handle(voh_it)));
			p1_vec_x[counter] = p1[0]; p1_vec_y[counter] = p1[1]; p1_vec_z[counter] = p1[2];
			p2_vec_x[counter] = p2[0]; p2_vec_y[counter] = p2[1]; p2_vec_z[counter] = p2[2];
			counter++;
		}
	}

	for (int j = 0; j < vv_size; ++j)
	{
		double p1_x = p1_vec_x[j]; double p1_y = p1_vec_y[j]; double p1_z = p1_vec_z[j];
		double p2_x = p2_vec_x[j]; double p2_y = p2_vec_y[j]; double p2_z = p2_vec_z[j];

		//		p1_vec_x[j] = p1_x; p1_vec_y[j] = p1_y; p1_vec_z[j] = p1_z;
		//		p2_vec_x[j] = p2_x; p2_vec_y[j] = p2_y; p2_vec_z[j] = p2_z;
		double omega0_ = omega0_vec[j]; double omega1_ = omega1_vec[j]; double omega2_ = omega2_vec[j];
		p1_p2_cross_x[j] = p1_y * p2_z - p1_z*p2_y;
		p1_p2_cross_y[j] = p1_z * p2_x - p1_x*p2_z;
		p1_p2_cross_z[j] = p1_x * p2_y - p1_y*p2_x;

		double l1x = p0_x - p2_x; double l1y = p0_y - p2_y; double l1z = p0_z - p2_z; double l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
		double l2x = p1_x - p0_x; double l2y = p1_y - p0_y; double l2z = p1_z - p0_z; double l2_n = l2x*l2x + l2y*l2y + l2z*l2z;
		double l0x = p2_x - p1_x; double l0y = p2_y - p1_y; double l0z = p2_z - p1_z; double l0_n = l0x*l0x + l0y*l0y + l0z*l0z;

		double nx = -l2y*l1z + l2z*l1y;
		double ny = -l2z*l1x + l2x*l1z;
		double nz = -l2x*l1y + l2y*l1x;

		double a = std::sqrt(nx*nx + ny*ny + nz*nz); double ia = 1.0 / a;
		nx *= ia; ny *= ia; nz *= ia;
		double l0_T_x = ny*l0z - nz *l0y;
		double l0_T_y = nz*l0x - nx *l0z;
		double l0_T_z = nx*l0y - ny *l0x;

		l0_n_vec[j] = omega0_*l0_n;
		double fa = fh_area_vec[j]; double ifa = inv_face_area_vec[j];
		double mips_e = (l0_n_vec[j] + omega1_*l1_n + omega2_*l2_n) * ia;
		double area_e = (fa * ia + a*ifa);

		double k = 0.5*(beta*mips_e + alpha * area_e);

		if (k > 60)
		{
			k = 60;
		}
		double e = std::exp(k); local_EXP_MIPS_e += e;

		double mips_g_x = (2.0*(omega1_*l1x - omega2_*l2x) - mips_e*l0_T_x)*ia;
		double mips_g_y = (2.0*(omega1_*l1y - omega2_*l2y) - mips_e*l0_T_y)*ia;
		double mips_g_z = (2.0*(omega1_*l1z - omega2_*l2z) - mips_e*l0_T_z)*ia;
		double area_g_x = (a*a - fa*fa)*l0_T_x  * (ifa*ia*ia);
		double area_g_y = (a*a - fa*fa)*l0_T_y  * (ifa*ia*ia);
		double area_g_z = (a*a - fa*fa)*l0_T_z  * (ifa*ia*ia);
		gx += e *(beta * mips_g_x + alpha*area_g_x)*0.5;
		gy += e *(beta * mips_g_y + alpha*area_g_y)*0.5;
		gz += e *(beta * mips_g_z + alpha*area_g_z)*0.5;

		if (l2_n < min_r) { min_r = l2_n; }
	}
	min_r = std::sqrt(min_r);
	double xd = -gx;
	double yd = -gy;
	double zd = -gz;

	double d_r = std::sqrt(xd*xd + yd*yd + zd*zd);
	if (d_r > min_r)
	{
		xd = xd * min_r / d_r;
		yd = yd * min_r / d_r;
		zd = zd * min_r / d_r;
		d_r = min_r;
	}

	double npx = p0_x + xd; double npy = p0_y + yd; double npz = p0_z + zd;
	double np_r = std::sqrt(npx*npx + npy*npy + npz*npz); double c = radius_suv / np_r;
	npx *= c; npy *= c; npz *= c;

	while (!local_check_negative_area_SUV(vv_size, npx, npy, npz, p1_p2_cross_x, p1_p2_cross_y, p1_p2_cross_z))
	{
		xd *= 0.8; yd *= 0.8; zd *= 0.8; d_r *= 0.8;
		if (d_r < dr_eps)
		{
			npx = p0_x; npy = p0_y; npz = p0_z;
			break;
		}
		npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
		np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
		npx *= c; npy *= c; npz *= c;
	}
	double new_e = 0;
	bool energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);

	if (!energy_d)
	{
		while (!energy_d)
		{
			xd *= 0.2; yd *= 0.2; zd *= 0.2; d_r *= 0.2;
			if (d_r <dr_eps)
			{
				npx = p0_x; npy = p0_y; npz = p0_z;
				break;
			}
			npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
			np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
			npx *= c; npy *= c; npz *= c;
			energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
		}

		if (energy_d)
		{
			energy_d = false;
			xd *= 5; yd *= 5; zd *= 5; d_r *= 5;
			while (!energy_d)
			{
				xd *= 0.5; yd *= 0.5; zd *= 0.5; d_r *= 0.5;
				if (d_r < dr_eps)
				{
					npx = p0_x; npy = p0_y; npz = p0_z;
					break;
				}
				npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
				np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
				npx *= c; npy *= c; npz *= c;
				energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
			}

			if (energy_d)
			{
				energy_d = false;
				xd *= 2; yd *= 2; zd *= 2; d_r *= 2;
				while (!energy_d)
				{
					xd *= 0.75; yd *= 0.75; zd *= 0.75; d_r *= 0.75;
					if (d_r < dr_eps)
					{
						npx = p0_x; npy = p0_y; npz = p0_z;
						break;
					}
					npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
					np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
					npx *= c; npy *= c; npz *= c;
					energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
				}

				if (energy_d)
				{
					energy_d = false;
					xd /= 0.75; yd /= 0.75; zd /= 0.75; d_r /= 0.75;
					while (!energy_d)
					{
						xd *= 0.945; yd *= 0.945; zd *= 0.945; d_r *= 0.945;
						if (d_r < dr_eps)
						{
							npx = p0_x; npy = p0_y; npz = p0_z;
							break;
						}
						npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
						np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
						npx *= c; npy *= c; npz *= c;
						energy_d = compute_local_EXP_MIPS_AREA_energy(new_e, local_EXP_MIPS_e, vv_size, npx, npy, npz, beta, alpha, fh_area_vec, inv_face_area_vec, l0_n_vec, p1_vec_x, p1_vec_y, p1_vec_z, p2_vec_x, p2_vec_y, p2_vec_z, omega1_vec, omega2_vec);
					}
				}
			}
		}
	}
	MyMesh::Point np(npx, npy, npz);
	mesh->set_point(v, np);
}

vector<Eigen::VectorXf> BCD_Sphere_Optimization::ComputeTriangleDistortion(MyMesh* mesh_, double angle_area_ratio)
{
	double alpha = angle_area_ratio; double beta = 1.0 - alpha;
	//	cot_angla = 1.0/std::sqrt(3.0);
	//	fa_area = 4.0*3.14159*radius_suv*radius_suv; fa_area /= (double)(mesh->n_faces());fa_area *= 2.0;
	int nf = mesh_->n_faces();
	vector<double> face_energy(nf);
	int counter = 0;
	double max_e = -1; double min_e = 100000000;
	for (auto f_it = mesh_->faces_begin(); f_it != mesh_->faces_end(); ++f_it)
	{
		vector<MyMesh::VertexHandle> v;
		for (auto fv = mesh_->fv_begin(f_it); fv != mesh_->fv_end(f_it); ++fv)
		{
			v.push_back(fv.handle());
		}
		Eigen::Vector3d v0(mesh_->point(v[0])[0], mesh_->point(v[0])[1], mesh_->point(v[0])[2]);
		Eigen::Vector3d v1(mesh_->point(v[1])[0], mesh_->point(v[1])[1], mesh_->point(v[1])[2]);
		Eigen::Vector3d v2(mesh_->point(v[2])[0], mesh_->point(v[2])[1], mesh_->point(v[2])[2]);
		double l0 = (v1 - v0).norm();
		double l1 = (v2 - v1).norm();
		double l2 = (v0 - v2).norm();
		Eigen::Vector3d s = (v1 - v0).cross(v2 - v1);
		double area_para = s.norm();
		double e = (beta*(cot_angla*(l0*l0 + l1*l1 + l2*l2) / area_para) + alpha*(area_para / fa_area + fa_area / area_para))*0.5;
		face_energy[counter] = e;
		if (max_e < e)
		{
			max_e = e;
		}
		if (min_e > e)
		{
			min_e = e;
		}
		counter++;
	}
	cout << "max_mips+area_e: " << max_e << " " << "min_mips+area_e: " << min_e << endl;
	Eigen::Vector3f c1(1.0, 0.0, 0.0);
	Eigen::Vector3f c2(0.9, 0.9, 0.9);
	vector<Eigen::VectorXf> color(nf);
	Eigen::VectorXf c(3);
	for (int i = 0; i <counter; i++)
	{
		face_energy[i] = (face_energy[i] - min_e) / (max_e - min_e);
		c = face_energy[i] * c1 + (1.0 - face_energy[i])*c2;
		color[i] = c;
		//		cout<<face_energy[i]<<" "<<c(0)<<" "<<c(1)<<" "<<c(2)<<endl;
	}

	return color;
}

vector<Eigen::VectorXf> BCD_Sphere_Optimization::ComputeTriangleDistortion_Refer_Originmesh(MyMesh* mesh_, MyMesh* m1, double angle_area_ratio)
{
	double alpha = angle_area_ratio; double beta = 1.0 - alpha;
	int nf = mesh_->n_faces();
	vector<double> face_energy(nf);
	int counter = 0;
	double max_e = -1; double min_e = 100000000;
	for (auto f_it = mesh_->faces_begin(); f_it != mesh_->faces_end(); ++f_it)
	{
		vector<int> v;
		for (auto fv = mesh_->fv_begin(f_it); fv != mesh_->fv_end(f_it); ++fv)
		{
			v.push_back(fv.handle().idx());
		}
		Eigen::Vector3d v0(mesh_->point(mesh_->vertex_handle(v[0]))[0], mesh_->point(mesh_->vertex_handle(v[0]))[1], mesh_->point(mesh_->vertex_handle(v[0]))[2]);
		Eigen::Vector3d v1(mesh_->point(mesh_->vertex_handle(v[1]))[0], mesh_->point(mesh_->vertex_handle(v[1]))[1], mesh_->point(mesh_->vertex_handle(v[1]))[2]);
		Eigen::Vector3d v2(mesh_->point(mesh_->vertex_handle(v[2]))[0], mesh_->point(mesh_->vertex_handle(v[2]))[1], mesh_->point(mesh_->vertex_handle(v[2]))[2]);
		double l0 = (v1 - v0).norm();
		double l1 = (v2 - v1).norm();
		double l2 = (v0 - v2).norm();
		Eigen::Vector3d s = (v1 - v0).cross(v2 - v1);
		double area_para = s.norm();

		Eigen::Vector3d o0(m1->point(m1->vertex_handle(v[0]))[0], m1->point(m1->vertex_handle(v[0]))[1], m1->point(m1->vertex_handle(v[0]))[2]);
		Eigen::Vector3d o1(m1->point(m1->vertex_handle(v[1]))[0], m1->point(m1->vertex_handle(v[1]))[1], m1->point(m1->vertex_handle(v[1]))[2]);
		Eigen::Vector3d o2(m1->point(m1->vertex_handle(v[2]))[0], m1->point(m1->vertex_handle(v[2]))[1], m1->point(m1->vertex_handle(v[2]))[2]);
		Eigen::Vector3d o_0 = o1 - o0;
		Eigen::Vector3d o_1 = o2 - o1;
		Eigen::Vector3d o_2 = o0 - o2;
		double area_ori = (o_0.cross(o_1)).norm();
		double a0 = acos((o2 - o0).dot(o_1) / (o_2.norm()) / (o_1.norm()));
		double a1 = acos((o0 - o1).dot(o_2) / (o_0.norm()) / (o_2.norm()));
		double a2 = acos((o0 - o1).dot(o_1) / (o_0.norm()) / (o_1.norm()));
		double  omega0_ = cos(a0) / sin(a0);
		double  omega1_ = cos(a1) / sin(a1);
		double  omega2_ = cos(a2) / sin(a2);
		//cout << a0+a1+a2<< endl;

		double e = (beta*((omega0_*l0*l0 + omega1_*l1*l1 + omega2_*l2*l2) / area_para) + alpha*(area_para / area_ori + area_ori / area_para))*0.5;
		face_energy[counter] = e;
		if (max_e < e)
		{
			max_e = e;
		}
		if (min_e > e)
		{
			min_e = e;
		}
		counter++;
	}
	cout << "max_mips+area_e: " << max_e << " " << "min_mips+area_e: " << min_e << endl;
	Eigen::Vector3f c1(1.0, 0.0, 0.0);
	Eigen::Vector3f c2(0.9, 0.9, 0.9);
	vector<Eigen::VectorXf> color(nf);
	Eigen::VectorXf c(3);
	for (int i = 0; i < counter; i++)
	{
		face_energy[i] = (face_energy[i] - min_e) / (max_e - min_e);
		c = face_energy[i] * c1 + (1.0 - face_energy[i])*c2;
		color[i] = c;
	}

	return color;
}

double BCD_Sphere_Optimization::ComputeLocalMaxTriangleDistortion_Refer_Originmesh(MyMesh* mesh_, MyMesh* m1, double angle_area_ratio, MyMesh::VertexHandle &v)
{
	double alpha = angle_area_ratio; double beta = 1.0 - alpha;
	double max_e = -1.0;
	int counter = 0;
	size_nei = mesh_->valence(v);
	MyMesh::Point p0 = mesh->point(v);
	int idx = v.idx();
	for (MyMesh::VertexOHalfedgeIter voh_it = mesh->voh_iter(v); voh_it; ++voh_it)
	{
		OpenMesh::HalfedgeHandle heh0 = mesh->next_halfedge_handle(voh_it);
		OpenMesh::HalfedgeHandle heh1 = mesh->prev_halfedge_handle(voh_it);

		MyMesh::Point p1 = mesh->point(mesh->to_vertex_handle(voh_it));
		int idx1 = mesh->to_vertex_handle(voh_it).idx();
		MyMesh::Point p2 = mesh->point(mesh->to_vertex_handle(mesh->next_halfedge_handle(voh_it)));
		int idx2 = mesh->to_vertex_handle(mesh->next_halfedge_handle(voh_it)).idx();
		double l0 = (p1 - p0).norm();
		double l1 = (p2 - p1).norm();
		double l2 = (p0 - p2).norm();
		OpenMesh::Vec3d& s = (p1 - p0) % (p2 - p1);
		double area_para = s.norm();

		MyMesh::Point o0(m1->point(m1->vertex_handle(idx))[0], m1->point(m1->vertex_handle(idx))[1], m1->point(m1->vertex_handle(idx))[2]);
		MyMesh::Point o1(m1->point(m1->vertex_handle(idx1))[0], m1->point(m1->vertex_handle(idx1))[1], m1->point(m1->vertex_handle(idx1))[2]);
		MyMesh::Point o2(m1->point(m1->vertex_handle(idx2))[0], m1->point(m1->vertex_handle(idx2))[1], m1->point(m1->vertex_handle(idx2))[2]);
		MyMesh::Point o_0 = o1 - o0;
		MyMesh::Point o_1 = o2 - o1;
		MyMesh::Point o_2 = o0 - o2;
		double area_ori = (o_0%o_1).norm();
		double a0 = acos((o2 - o0) | o_1 / (o_2.norm()) / (o_1.norm()));
		double a1 = acos((o0 - o1) | o_2 / (o_0.norm()) / (o_2.norm()));
		double a2 = acos((o0 - o1) | o_1 / (o_0.norm()) / (o_1.norm()));
		double  omega0_ = cos(a0) / sin(a0);
		double  omega1_ = cos(a1) / sin(a1);
		double  omega2_ = cos(a2) / sin(a2);

		double e = (beta*((omega0_*l0*l0 + omega1_*l1*l1 + omega2_*l2*l2) / area_para) + alpha*(area_para / area_ori + area_ori / area_para))*0.5;
		if (max_e < e)
		{
			max_e = e;
		}
	}
	return max_e;
}

double BCD_Sphere_Optimization::ComputeMaxTriangleDistortion_Refer_Originmesh(MyMesh* mesh_, MyMesh* m1, double angle_area_ratio)
{
	double alpha = angle_area_ratio; double beta = 1.0 - alpha;
	int nf = mesh_->n_faces();
	vector<double> face_energy(nf);
	int counter = 0;
	double max_e = -1; double min_e = 100000000;
	for (auto f_it = mesh_->faces_begin(); f_it != mesh_->faces_end(); ++f_it)
	{
		vector<int> v;
		for (auto fv = mesh_->fv_begin(f_it); fv != mesh_->fv_end(f_it); ++fv)
		{
			v.push_back(fv.handle().idx());
		}
		Eigen::Vector3d v0(mesh_->point(mesh_->vertex_handle(v[0]))[0], mesh_->point(mesh_->vertex_handle(v[0]))[1], mesh_->point(mesh_->vertex_handle(v[0]))[2]);
		Eigen::Vector3d v1(mesh_->point(mesh_->vertex_handle(v[1]))[0], mesh_->point(mesh_->vertex_handle(v[1]))[1], mesh_->point(mesh_->vertex_handle(v[1]))[2]);
		Eigen::Vector3d v2(mesh_->point(mesh_->vertex_handle(v[2]))[0], mesh_->point(mesh_->vertex_handle(v[2]))[1], mesh_->point(mesh_->vertex_handle(v[2]))[2]);
		double l0 = (v1 - v0).norm();
		double l1 = (v2 - v1).norm();
		double l2 = (v0 - v2).norm();
		Eigen::Vector3d s = (v1 - v0).cross(v2 - v1);
		double area_para = s.norm();

		Eigen::Vector3d o0(m1->point(m1->vertex_handle(v[0]))[0], m1->point(m1->vertex_handle(v[0]))[1], m1->point(m1->vertex_handle(v[0]))[2]);
		Eigen::Vector3d o1(m1->point(m1->vertex_handle(v[1]))[0], m1->point(m1->vertex_handle(v[1]))[1], m1->point(m1->vertex_handle(v[1]))[2]);
		Eigen::Vector3d o2(m1->point(m1->vertex_handle(v[2]))[0], m1->point(m1->vertex_handle(v[2]))[1], m1->point(m1->vertex_handle(v[2]))[2]);
		Eigen::Vector3d o_0 = o1 - o0;
		Eigen::Vector3d o_1 = o2 - o1;
		Eigen::Vector3d o_2 = o0 - o2;
		double area_ori = (o_0.cross(o_1)).norm();
		double a0 = acos((o2 - o0).dot(o_1) / (o_2.norm()) / (o_1.norm()));
		double a1 = acos((o0 - o1).dot(o_2) / (o_0.norm()) / (o_2.norm()));
		double a2 = acos((o0 - o1).dot(o_1) / (o_0.norm()) / (o_1.norm()));
		double  omega0_ = cos(a0) / sin(a0);
		double  omega1_ = cos(a1) / sin(a1);
		double  omega2_ = cos(a2) / sin(a2);
		//cout << a0+a1+a2<< endl;

		double e = (beta*((omega0_*l0*l0 + omega1_*l1*l1 + omega2_*l2*l2) / area_para) + alpha*(area_para / area_ori + area_ori / area_para))*0.5;
		face_energy[counter] = e;
		if (max_e < e)
		{
			max_e = e;
		}
		if (min_e > e)
		{
			min_e = e;
		}
		counter++;
	}
	//	energy_power = std::log(50) / std::log(max_e);
	//	high_d = max_e;
	cout << "max_mips+area_e: " << max_e << endl;
	return max_e;
}

double BCD_Sphere_Optimization::ComputeGlobalMaxTriangleDistortion(MyMesh* mesh_, double angle_area_ratio)
{
	double alpha = angle_area_ratio; double beta = 1.0 - alpha;
	//	cot_angla = 1.0/std::sqrt(3.0);
	//	fa_area = 4.0*3.14159*radius_suv*radius_suv; fa_area /= (double)(mesh->n_faces());fa_area *= 2.0;
	int nf = mesh_->n_faces();
	int counter = 0;
	double max_e = -1;
	for (auto f_it = mesh_->faces_begin(); f_it != mesh_->faces_end(); ++f_it)
	{
		vector<MyMesh::Point> v;
		for (auto fv = mesh_->fv_begin(f_it); fv != mesh_->fv_end(f_it); ++fv)
		{
			v.push_back(mesh_->point(fv));
		}
		double l0 = (v[1] - v[0]).norm();
		double l1 = (v[2] - v[1]).norm();
		double l2 = (v[0] - v[2]).norm();
		MyMesh::Point s = (v[1] - v[0]) % (v[2] - v[1]);
		double area_para = s.norm();
		double e = (beta*(cot_angla*(l0*l0 + l1*l1 + l2*l2) / area_para) + alpha*(area_para / fa_area + fa_area / area_para))*0.5;
		if (max_e < e)
		{
			max_e = e;
		}
		counter++;
	}
	//	cout<<"max_e: "<<max_e<<endl;
	return max_e;
}

double BCD_Sphere_Optimization::ComputeLocalMaxTriangleDistortion(MyMesh* mesh_, double angle_area_ratio, MyMesh::VertexHandle &v)
{
	double alpha = angle_area_ratio; double beta = 1.0 - alpha;
	double new_e = 0;
	double max_e = -1.0;
	size_nei = mesh_->valence(v);
	p1_nei_x.resize(size_nei);
	p1_nei_y.resize(size_nei);
	p1_nei_z.resize(size_nei);
	p2_nei_x.resize(size_nei);
	p2_nei_y.resize(size_nei);
	p2_nei_z.resize(size_nei);
	int counter = 0;
	for (MyMesh::VertexOHalfedgeIter voh_it = mesh->voh_iter(v); voh_it; ++voh_it)
	{
		MyMesh::FaceHandle fh = mesh->face_handle(voh_it);
		if (fh != MyMesh::InvalidFaceHandle)
		{
			OpenMesh::HalfedgeHandle heh0 = mesh->next_halfedge_handle(voh_it);
			OpenMesh::HalfedgeHandle heh1 = mesh->prev_halfedge_handle(voh_it);

			MyMesh::Point p1 = mesh->point(mesh->to_vertex_handle(voh_it));
			MyMesh::Point p2 = mesh->point(mesh->to_vertex_handle(mesh->next_halfedge_handle(voh_it)));
			p1_nei_x[counter] = p1[0]; p1_nei_y[counter] = p1[1]; p1_nei_z[counter] = p1[2];
			p2_nei_x[counter] = p2[0]; p2_nei_y[counter] = p2[1]; p2_nei_z[counter] = p2[2];
			counter++;
		}
	}
	MyMesh::Point p = mesh->point(v);
	current_x = p[0]; current_y = p[1]; current_z = p[2];
	double l1x, l1y, l1z, l1_n, l2x, l2y, l2z, l2_n, l0x, l0y, l0z, l0_n;
	double nx, ny, nz, a, ia; double mips_e, area_e, k;

	for (int i = 0; i < size_nei; ++i)
	{
		l1x = current_x - p2_nei_x[i];  l1y = current_y - p2_nei_y[i];  l1z = current_z - p2_nei_z[i];  l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
		l2x = p1_nei_x[i] - current_x;  l2y = p1_nei_y[i] - current_y;  l2z = p1_nei_z[i] - current_z;  l2_n = l2x*l2x + l2y*l2y + l2z*l2z;
		l0x = p2_nei_x[i] - p1_nei_x[i]; l0y = p2_nei_y[i] - p1_nei_y[i]; l0z = p2_nei_z[i] - p1_nei_z[i]; l0_n = l0x*l0x + l0y*l0y + l0z*l0z;

		nx = -l2y*l1z + l2z*l1y;
		ny = -l2z*l1x + l2x*l1z;
		nz = -l2x*l1y + l2y*l1x;

		a = std::sqrt(nx*nx + ny*ny + nz*nz); ia = 1.0 / a;

		mips_e = cot_angla*(l0_n + l1_n + l2_n) *ia;
		area_e = (fa_area / a + a / fa_area);
		new_e = 0.5*(beta * mips_e + alpha * area_e);
		if (max_e < new_e)
		{
			max_e = new_e;
		}
	}
	return max_e;
}

double BCD_Sphere_Optimization::ComputeRefineAmipsEreaEnergy(int &k, double &angle_area_ratio, double &px, double &py, double &pz, vector<int> &vv1, vector<int> &vv2)
{
	num_sun_nei.resize(vv1.size());
	double Local_exp_energy = 0.0;
	MyMesh::Point p(px, py, pz);
	for (int i = 0; i< vv1.size(); i++)
	{
		MyMesh::Point p1(new_p_x[vv1[i]], new_p_y[vv1[i]], new_p_z[vv1[i]]);
		MyMesh::Point p2(new_p_x[vv2[i]], new_p_y[vv2[i]], new_p_z[vv2[i]]);
		double l1 = (p - p1).norm(); double l2 = (p - p2).norm(); double l3 = (p1 - p2).norm();
		double longest_e = max(max(l1, l2), l3);
		int n = ceil(longest_e / thresh_hold);
		if (n > 3)
		{
			n = 3;
		}
		num_sun_nei[i] = n;
		for (int t = 0; t< all_sub_triangle[n - 1].size(); t++)
		{
			MyMesh::Point p_0 = all_sub_triangle[n - 1][t][0][0] * p + all_sub_triangle[n - 1][t][0][1] * p1 + all_sub_triangle[n - 1][t][0][2] * p2;
			p_0 = radius_suv*p_0 / p_0.norm();
			MyMesh::Point p_1 = all_sub_triangle[n - 1][t][1][0] * p + all_sub_triangle[n - 1][t][1][1] * p1 + all_sub_triangle[n - 1][t][1][2] * p2;
			p_1 = radius_suv*p_1 / p_1.norm();
			MyMesh::Point p_2 = all_sub_triangle[n - 1][t][2][0] * p + all_sub_triangle[n - 1][t][2][1] * p1 + all_sub_triangle[n - 1][t][2][2] * p2;
			p_2 = radius_suv*p_2 / p_2.norm();
			double e = ComputeSubTriangleEnergy(n, angle_area_ratio, p_0, p_1, p_2);
			e /= (n*n);
			Local_exp_energy += e;
		}
	}
	return Local_exp_energy;
}

bool BCD_Sphere_Optimization::JudgeRefineAmipsEreaEnergy(double old_e, int &k, double &angle_area_ratio, double &px, double &py, double &pz, vector<int> &vv1, vector<int> &vv2)
{
	double Local_exp_energy = 0.0;
	MyMesh::Point p(px, py, pz);
	for (int i = 0; i< vv1.size(); i++)
	{
		MyMesh::Point p1(new_p_x[vv1[i]], new_p_y[vv1[i]], new_p_z[vv1[i]]);
		MyMesh::Point p2(new_p_x[vv2[i]], new_p_y[vv2[i]], new_p_z[vv2[i]]);

		int idx = num_sun_nei[i];
		for (int t = 0; t < all_sub_triangle[idx - 1].size(); t++)
		{
			MyMesh::Point p_0 = all_sub_triangle[idx - 1][t][0][0] * p + all_sub_triangle[idx - 1][t][0][1] * p1 + all_sub_triangle[idx - 1][t][0][2] * p2;
			p_0 = radius_suv*p_0 / p_0.norm();
			MyMesh::Point p_1 = all_sub_triangle[idx - 1][t][1][0] * p + all_sub_triangle[idx - 1][t][1][1] * p1 + all_sub_triangle[idx - 1][t][1][2] * p2;
			p_1 = radius_suv*p_1 / p_1.norm();
			MyMesh::Point p_2 = all_sub_triangle[idx - 1][t][2][0] * p + all_sub_triangle[idx - 1][t][2][1] * p1 + all_sub_triangle[idx - 1][t][2][2] * p2;
			p_2 = radius_suv*p_2 / p_2.norm();
			double e = ComputeSubTriangleEnergy(idx, angle_area_ratio, p_0, p_1, p_2);
			e /= (idx*idx);
			Local_exp_energy += e;
			if (Local_exp_energy > old_e)
			{
				return false;
			}
		}
	}
	return true;
}

void BCD_Sphere_Optimization::FindAllSubTriangles(double t1, double t2, double t3)
{
	if (t1 == 0)
	{
		return;
	}
	vector<vector<double>> tri(3);
	vector<double> ver(3);
	ver[0] = t1; ver[1] = t2; ver[2] = t3;   tri[0] = ver;
	ver[0] = t1 - 1; ver[1] = t2 + 1; ver[2] = t3; tri[1] = ver;
	ver[0] = t1 - 1; ver[1] = t2;  ver[2] = t3 + 1; tri[2] = ver;
	sub_triangles.push_back(tri);
	if (t1 > 1)
	{
		ver[0] = t1 - 1; ver[1] = t2 + 1; ver[2] = t3; tri[0] = ver;
		ver[0] = t1 - 2; ver[1] = t2 + 1; ver[2] = t3 + 1; tri[1] = ver;
		ver[0] = t1 - 1; ver[1] = t2;  ver[2] = t3 + 1; tri[2] = ver;
		sub_triangles.push_back(tri);
	}
	bool sig = true;
	for (int p = 0; p < record_start_point.size(); p++)
	{
		if ((record_start_point[p][0] == (t1 - 1)) && (record_start_point[p][1] == (t2 + 1)) && (record_start_point[p][2] == t3))
		{
			sig = false;
			break;
		}
	}
	if (sig)
	{
		FindAllSubTriangles(t1 - 1, t2 + 1, t3);
		ver[0] = t1 - 1; ver[1] = t2 + 1; ver[2] = t3;
		record_start_point.push_back(ver);
	}

	sig = true;
	for (int p = 0; p < record_start_point.size(); p++)
	{
		if ((record_start_point[p][0] == (t1 - 1)) && (record_start_point[p][1] == t2) && (record_start_point[p][2] == (t3 + 1)))
		{
			sig = false;
			break;
		}
	}
	if (sig)
	{
		FindAllSubTriangles(t1 - 1, t2, t3 + 1);
		ver[0] = t1 - 1; ver[1] = t2; ver[2] = t3 + 1;
		record_start_point.push_back(ver);
	}
}

double BCD_Sphere_Optimization::ComputeSubTriangleEnergy(int &n, double &angle_area_ratio, MyMesh::Point &p_0, MyMesh::Point &p_1, MyMesh::Point &p_2)
{
	double alpha = angle_area_ratio; double beta = 1.0 - alpha;
	double l_1 = (p_0 - p_1).norm(); double l_2 = (p_0 - p_2).norm(); double l_3 = (p_2 - p_1).norm();
	double a = ((p_0 - p_1) % (p_0 - p_2)).norm();
	double mips = cot_angla*(l_1*l_1 + l_2*l_2 + l_3*l_3) / a;
	double area = fa_area / n / n / a + a / (fa_area / n / n);
	double e = (beta*mips + alpha*area)*0.5;
	if (e > 60)
	{
		e = 60;
	}
	return exp(e);
}

void BCD_Sphere_Optimization::Refine_EXP_MIPS_AREA_Reposition(MyMesh* mesh_, double step_length, double energy_power, double angle_area_ratio)
{
	int nv = new_p_x.size();
	std::vector<double> p1_vec_x(max_vv_size); std::vector<double> p1_vec_y(max_vv_size); std::vector<double> p1_vec_z(max_vv_size);
	std::vector<double> p2_vec_x(max_vv_size); std::vector<double> p2_vec_y(max_vv_size); std::vector<double> p2_vec_z(max_vv_size);
	std::vector<double> l0_n_vec(max_vv_size);
	std::vector<double> p1_p2_cross_x(max_vv_size); std::vector<double> p1_p2_cross_y(max_vv_size); std::vector<double> p1_p2_cross_z(max_vv_size);
	double alpha = angle_area_ratio*energy_power; double beta = energy_power - alpha;

	for (int i = 0; i < nv; ++i)
	{
		//cout<<i<<" iterations  "<<endl;
		double p0_x = new_p_x[i]; double p0_y = new_p_y[i]; double p0_z = new_p_z[i];
		double gx = 0.0; double gy = 0.0; double gz = 0.0;
		double local_EXP_MIPS_e = 0.0; double min_r = 1e30;
		int vv_size = vertex_v1[i].size();

		std::vector<double>& fh_area_vec = face_area[i]; std::vector<double>& inv_face_area_vec = inv_face_area[i];
		std::vector<double>& omega0_vec = omega0[i]; std::vector<double>& omega1_vec = omega1[i]; std::vector<double>& omega2_vec = omega2[i];
		std::vector<int>& v_v1 = vertex_v1[i]; std::vector<int>& v_v2 = vertex_v2[i];
		//#pragma omp parallel for schedule(dynamic)
		for (int j = 0; j < vv_size; ++j)
		{
			int vv1 = v_v1[j]; int vv2 = v_v2[j];
			double p1_x = new_p_x[vv1]; double p1_y = new_p_y[vv1]; double p1_z = new_p_z[vv1];
			double p2_x = new_p_x[vv2]; double p2_y = new_p_y[vv2]; double p2_z = new_p_z[vv2];
			p1_vec_x[j] = p1_x; p1_vec_y[j] = p1_y; p1_vec_z[j] = p1_z;
			p2_vec_x[j] = p2_x; p2_vec_y[j] = p2_y; p2_vec_z[j] = p2_z;
			double omega0_ = omega0_vec[j]; double omega1_ = omega1_vec[j]; double omega2_ = omega2_vec[j];
			p1_p2_cross_x[j] = p1_y * p2_z - p1_z*p2_y;
			p1_p2_cross_y[j] = p1_z * p2_x - p1_x*p2_z;
			p1_p2_cross_z[j] = p1_x * p2_y - p1_y*p2_x;

			double l1x = p0_x - p2_x; double l1y = p0_y - p2_y; double l1z = p0_z - p2_z; double l1_n = l1x*l1x + l1y*l1y + l1z*l1z;
			double l2x = p1_x - p0_x; double l2y = p1_y - p0_y; double l2z = p1_z - p0_z; double l2_n = l2x*l2x + l2y*l2y + l2z*l2z;
			double l0x = p2_x - p1_x; double l0y = p2_y - p1_y; double l0z = p2_z - p1_z; double l0_n = l0x*l0x + l0y*l0y + l0z*l0z;

			double nx = -l2y*l1z + l2z*l1y;
			double ny = -l2z*l1x + l2x*l1z;
			double nz = -l2x*l1y + l2y*l1x;

			double a = std::sqrt(nx*nx + ny*ny + nz*nz); double ia = 1.0 / a;
			nx *= ia; ny *= ia; nz *= ia;
			double l0_T_x = ny*l0z - nz *l0y;
			double l0_T_y = nz*l0x - nx *l0z;
			double l0_T_z = nx*l0y - ny *l0x;

			l0_n_vec[j] = omega0_*l0_n;
			double fa = fh_area_vec[j]; double ifa = inv_face_area_vec[j];
			double mips_e = (l0_n_vec[j] + omega1_*l1_n + omega2_*l2_n) * ia;
			double area_e = (fa * ia + a*ifa);

			//			double k = 0.5*(0.5*mips_e + 0.5 * area_e);
			double k = 0.5*(beta*mips_e + alpha * area_e);
			if (k > 60)
			{
				k = 60;
			}
			double e = std::exp(k); local_EXP_MIPS_e += e;

			double mips_g_x = (2.0*(omega1_*l1x - omega2_*l2x) - mips_e*l0_T_x)*ia;
			double mips_g_y = (2.0*(omega1_*l1y - omega2_*l2y) - mips_e*l0_T_y)*ia;
			double mips_g_z = (2.0*(omega1_*l1z - omega2_*l2z) - mips_e*l0_T_z)*ia;
			double area_g_x = (a*a - fa*fa)*l0_T_x  * (ifa*ia*ia);
			double area_g_y = (a*a - fa*fa)*l0_T_y  * (ifa*ia*ia);
			double area_g_z = (a*a - fa*fa)*l0_T_z  * (ifa*ia*ia);
			gx += e *(beta * mips_g_x + alpha*area_g_x)*0.5;
			gy += e *(beta * mips_g_y + alpha*area_g_y)*0.5;
			gz += e *(beta * mips_g_z + alpha*area_g_z)*0.5;

			if (l2_n < min_r) { min_r = l2_n; }
		}

		//////////////////////////////////////////////////////////////////
		local_EXP_MIPS_e = ComputeRefineAmipsEreaEnergy(i, angle_area_ratio, new_p_x[i], new_p_y[i], new_p_z[i], v_v1, v_v2);
		////////////////////////////////////////////////////////////////////

		min_r = std::sqrt(min_r) * vertex_radius_ratio[i];
		double xd = -gx;
		double yd = -gy;
		double zd = -gz;

		double d_r = std::sqrt(xd*xd + yd*yd + zd*zd);

		if (d_r > min_r)
		{
			xd = xd * min_r / d_r;
			yd = yd * min_r / d_r;
			zd = zd * min_r / d_r;
			d_r = min_r;
		}

		double npx = p0_x + xd; double npy = p0_y + yd; double npz = p0_z + zd;
		double np_r = std::sqrt(npx*npx + npy*npy + npz*npz); double c = radius_suv / np_r; //������radius_suv
		npx *= c; npy *= c; npz *= c;
		while (!local_check_negative_area_SUV(vv_size, npx, npy, npz, p1_p2_cross_x, p1_p2_cross_y, p1_p2_cross_z))
		{
			xd *= 0.8; yd *= 0.8; zd *= 0.8; d_r *= 0.8;
			if (d_r < dr_eps)
			{
				npx = p0_x; npy = p0_y; npz = p0_z;
				break;
			}
			npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
			np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
			npx *= c; npy *= c; npz *= c;
		}

		double new_e = 0;

		bool energy_d = JudgeRefineAmipsEreaEnergy(local_EXP_MIPS_e, i, angle_area_ratio, npx, npy, npz, v_v1, v_v2);


		if (!energy_d)
		{
			while (!energy_d)
			{
				xd *= 0.2; yd *= 0.2; zd *= 0.2; d_r *= 0.2;
				if (d_r < dr_eps)
				{
					npx = p0_x; npy = p0_y; npz = p0_z;
					break;
				}
				npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
				np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
				npx *= c; npy *= c; npz *= c;
				energy_d = JudgeRefineAmipsEreaEnergy(local_EXP_MIPS_e, i, angle_area_ratio, npx, npy, npz, v_v1, v_v2);
			}

			if (energy_d)
			{
				energy_d = false;
				xd *= 5; yd *= 5; zd *= 5; d_r *= 5;
				while (!energy_d)
				{
					xd *= 0.5; yd *= 0.5; zd *= 0.5; d_r *= 0.5;
					if (d_r < dr_eps)
					{
						npx = p0_x; npy = p0_y; npz = p0_z;
						break;
					}
					npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
					np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
					npx *= c; npy *= c; npz *= c;
					energy_d = JudgeRefineAmipsEreaEnergy(local_EXP_MIPS_e, i, angle_area_ratio, npx, npy, npz, v_v1, v_v2);
				}

				if (energy_d)
				{
					energy_d = false;
					xd *= 2; yd *= 2; zd *= 2; d_r *= 2;
					while (!energy_d)
					{
						xd *= 0.75; yd *= 0.75; zd *= 0.75; d_r *= 0.75;
						if (d_r < dr_eps)
						{
							npx = p0_x; npy = p0_y; npz = p0_z;
							break;
						}
						npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
						np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
						npx *= c; npy *= c; npz *= c;
						energy_d = JudgeRefineAmipsEreaEnergy(local_EXP_MIPS_e, i, angle_area_ratio, npx, npy, npz, v_v1, v_v2);
					}

					if (energy_d)
					{
						energy_d = false;
						xd /= 0.75; yd /= 0.75; zd /= 0.75; d_r /= 0.75;
						while (!energy_d)
						{
							xd *= 0.945; yd *= 0.945; zd *= 0.945; d_r *= 0.945;
							if (d_r < dr_eps)
							{
								npx = p0_x; npy = p0_y; npz = p0_z;
								break;
							}
							npx = p0_x + xd; npy = p0_y + yd; npz = p0_z + zd;
							np_r = std::sqrt(npx*npx + npy*npy + npz*npz); c = radius_suv / np_r;
							npx *= c; npy *= c; npz *= c;
							energy_d = JudgeRefineAmipsEreaEnergy(local_EXP_MIPS_e, i, angle_area_ratio, npx, npy, npz, v_v1, v_v2);
						}
					}
				}
			}
		}
		new_p_x[i] = npx; new_p_y[i] = npy; new_p_z[i] = npz;

	}
	//scale_by_isometric();
}

void BCD_Sphere_Optimization::prepare_refine()
{
	all_sub_triangle.resize(6);
	for (int i = 1; i < 4; i++)
	{
		sub_triangles.clear();
		FindAllSubTriangles(i, 0, 0);
		for (int j = 0; j < sub_triangles.size(); j++)
		{
			for (int j1 = 0; j1 < 3; j1++)
			{
				for (int j2 = 0; j2 < 3; j2++)
				{
					sub_triangles[j][j1][j2] /= i;
				}
			}
		}
		all_sub_triangle[i - 1] = sub_triangles;
	}
}

bool BCD_Sphere_Optimization::checklap(MyMesh* mesh_, double threh)
{
	int nf = mesh_->n_faces();
	int counter = 0;
	for (auto f_it = mesh_->faces_begin(); f_it != mesh_->faces_end(); ++f_it)
	{
		vector<MyMesh::Point> v;
		for (auto fv = mesh_->fv_begin(f_it); fv != mesh_->fv_end(f_it); ++fv)
		{
			v.push_back(mesh_->point(fv));
		}
		double vol = (v[1] % v[2]) | v[0];
		if (vol < threh)
		{
			return true;
		}
		counter++;
	}
	return false;
}

vector<Eigen::VectorXf> BCD_Sphere_Optimization::triangle_distortion(MyMesh * mesh_, MyMesh * m1)
{
	double max_iso_dis;
	vector<double> conformal_distortion, isometric_distortion, lscm_distortion;
	vector<int> flipped_tri, cd_above_1000_tri;
	OpenMesh::Vec3d face_nor; double face_area;
	MyMesh::FaceHalfedgeIter fhe_it;
	MyMesh::HalfedgeHandle heh; MyMesh::VertexHandle vh;
	OpenMesh::Vec3d e_v; OpenMesh::Vec3d p_v;
	std::vector<OpenMesh::Vec3d> v_p_on_plane(3); v_p_on_plane[0] = OpenMesh::Vec3d(0, 0, 0);
	std::vector<OpenMesh::Vec3d> v_q_on_plane(3); v_q_on_plane[0] = OpenMesh::Vec3d(0, 0, 0);
	double len; int face_count = 0; int face_id;
	double max_error = 0; int max_face = 0; double singular_value[2]; double ave_dis = 0;
	double doumax_iso_dis = 0; int max_iso_face = 0; double singular_iso_value[2]; double ave_iso_dis = 0;
	double max_conformal_error = 0; int max_conformal_face = 0; double singular_conformal_value[2]; double ave_conformal_dis = 0;
	double min_conformal_error = 1e30; double min_iso_error = 1e30;
	conformal_distortion.clear(); conformal_distortion.resize(mesh_->n_faces());
	isometric_distortion.clear(); isometric_distortion.resize(mesh_->n_faces());
	lscm_distortion.clear(); lscm_distortion.resize(mesh_->n_faces());
	double max_area_d = 0.0; double min_area_d = 1e30; std::vector<double> area_d(mesh_->n_faces()); double avg_area_d = 0;
	int flip_tri_count = 0; flipped_tri.clear(); cd_above_1000_tri.clear();
	double D_area = 0.0; double D_angle = 0.0; double D_rigid = 0.0; double all_a = 0.0;
	double sum_mips = 0.0; double min_rigid_error = 1e30; double max_rigid_error = 0.0;
	double min_rigid_error2 = 1e30; double max_rigid_error2 = 0.0; double D_rigid2 = 0.0;
	double min_lscm_error = 1e30; double max_lscm_error = 0.0; int big_AMIPS_energy_count = 0;
	for (MyMesh::FaceIter f_it = mesh_->faces_begin(); f_it != mesh_->faces_end(); ++f_it)
	{
		fhe_it = mesh_->fh_iter(f_it); face_id = f_it.handle().idx();
		OpenMesh::Vec3d p0 = m1->point(m1->vertex_handle(mesh_->from_vertex_handle(fhe_it).idx()));
		OpenMesh::Vec3d p1 = m1->point(m1->vertex_handle(mesh_->to_vertex_handle(fhe_it).idx()));
		OpenMesh::Vec3d p2 = m1->point(m1->vertex_handle(mesh_->to_vertex_handle(mesh_->next_halfedge_handle(fhe_it)).idx()));
		face_nor = OpenMesh::cross(p1 - p0, p2 - p0); face_area = face_nor.norm()*0.5; face_nor.normalize();
		len = (p1 - p0).norm();
		v_p_on_plane[1] = OpenMesh::Vec3d(len, 0.0, 0.0);

		OpenMesh::Vec3d e1 = p1 - p0;
		e1 /= e1.norm();
		OpenMesh::Vec3d e2 = OpenMesh::cross(face_nor, e1);
		e2 /= e2.norm();
		heh = mesh_->prev_halfedge_handle(fhe_it);
		OpenMesh::Vec3d temp_v2 = p2 - p0;
		v_p_on_plane[2][0] = OpenMesh::dot(temp_v2, e1);
		v_p_on_plane[2][1] = OpenMesh::dot(temp_v2, e2);
		v_p_on_plane[2][2] = 0.0;

		p0 = mesh_->point(mesh_->from_vertex_handle(fhe_it));
		p1 = mesh_->point(mesh_->to_vertex_handle(fhe_it));
		p2 = mesh_->point(mesh_->to_vertex_handle(mesh_->next_halfedge_handle(fhe_it)));
		double v_ = OpenMesh::dot(p0, OpenMesh::cross(p1, p2));
		face_nor = OpenMesh::cross(p1 - p0, p2 - p0); face_nor.normalize();
		//face_nor = OpenMesh::Vec3d(0, 0, 1);
		//face_nor = (p0+p1+p2).normalize();
		len = (p1 - p0).norm();
		v_q_on_plane[1] = OpenMesh::Vec3d(len, 0.0, 0.0);

		e1 = p1 - p0; e1 /= e1.norm();
		e2 = OpenMesh::cross(face_nor, e1); e2 /= e2.norm();
		heh = mesh_->prev_halfedge_handle(fhe_it);
		temp_v2 = p2 - p0;
		v_q_on_plane[2][0] = OpenMesh::dot(temp_v2, e1);
		v_q_on_plane[2][1] = OpenMesh::dot(temp_v2, e2);
		v_q_on_plane[2][2] = 0.0;

		OpenMesh::Vec3d d_U(0, 0, 0); OpenMesh::Vec3d d_V(0, 0, 0);
		for (int i = 0; i < 3; ++i)
		{
			p_v = v_q_on_plane[(i + 2) % 3];
			e_v = v_p_on_plane[(i + 1) % 3] - v_p_on_plane[i];

			d_U += p_v[0] * e_v;
			d_V += p_v[1] * e_v;
		}
		d_U /= (2.0 * face_area);
		d_V /= (2.0 * face_area);

		Eigen::Matrix2d J;
		J(0, 0) = d_U[0]; J(1, 0) = d_U[1]; J(0, 1) = d_V[0]; J(1, 1) = d_V[1];
		double det_J = J.determinant();
		if (det_J > 0 && v_ >= 0)
		{
			//double temp_error = s_v(0) > 1.0/s_v(1) ? s_v(0) : 1.0/s_v(1);
			/*double temp_error = (s_v(0) / s_v(1) + s_v(1) / s_v(0))*0.5;
			if(temp_error > max_error)
			{
			max_error = temp_error; max_face = face_id;
			singular_value[0] = s_v(0); singular_value[1] = s_v(1);
			}
			ave_dis += temp_error;*/
			Eigen::JacobiSVD<Eigen::Matrix2d> svd(J, Eigen::ComputeFullU | Eigen::ComputeFullV);
			Eigen::Vector2d s_v = svd.singularValues();
			double temp_error = s_v(0) > 1.0 / s_v(1) ? s_v(0) : 1.0 / s_v(1);
			isometric_distortion[face_id] = temp_error;
			if (temp_error > max_iso_dis)
			{
				max_iso_dis = temp_error; max_iso_face = face_id;
				singular_iso_value[0] = s_v(0); singular_iso_value[1] = s_v(1);
			}
			if (temp_error < min_iso_error)
			{
				min_iso_error = temp_error;
				//singular_iso_value[0] = s_v(0); singular_iso_value[1] = s_v(1);
			}
			ave_iso_dis += temp_error;

			temp_error = s_v(0) / s_v(1);
			conformal_distortion[face_id] = temp_error;
			if (temp_error > max_conformal_error)
			{
				max_conformal_error = temp_error; max_conformal_face = face_id;
				singular_conformal_value[0] = s_v(0); singular_conformal_value[1] = s_v(1);
			}
			if (temp_error < min_conformal_error)
			{
				min_conformal_error = temp_error;
			}
			ave_conformal_dis += temp_error;

			if (temp_error > 2.5) cd_above_1000_tri.push_back(face_id);
			//sum_mips += 0.5*(temp_error + 1.0 / temp_error);
			//sum_mips += temp_error;

			if (5 * 0.5*(s_v(0) / s_v(1) + s_v(1) / s_v(0) + 1.0 / (s_v(0)*s_v(1)) + s_v(0)*s_v(1)) > 120)
			{
				++big_AMIPS_energy_count;
			}

			double dJ = s_v(0)*s_v(1);
			temp_error = dJ > 1.0 / dJ ? dJ : 1.0 / dJ;
			if (temp_error > max_area_d)
			{
				max_area_d = temp_error;
			}
			if (temp_error < min_area_d)
			{
				min_area_d = temp_error;
			}
			avg_area_d += temp_error;
			area_d[face_id] = temp_error;

			all_a += face_area;
			//D_area += face_area * (s_v(0)*s_v(1) + 1.0 / ( s_v(0)*s_v(1) ) ) ;
			//D_angle += face_area * (s_v(0) / s_v(1) + s_v(1) / s_v(0) );
			//D_rigid += face_area * ((s_v(0) - 1.0)*(s_v(0) - 1.0) + (s_v(1) - 1.0)*(s_v(1) - 1.0) );
			//double d_r = ((s_v(0) - 1.0)*(s_v(0) - 1.0) + (s_v(1) - 1.0)*(s_v(1) - 1.0));
			//D_rigid += d_r;
			double d_r = (J.transpose()*J - Eigen::Matrix2d::Identity()).squaredNorm();
			D_rigid += d_r;
			if (d_r < min_rigid_error)
			{
				min_rigid_error = d_r;
			}
			if (d_r > max_rigid_error)
			{
				max_rigid_error = d_r;
			}

			d_r *= face_area;
			D_rigid2 += d_r;
			if (d_r < min_rigid_error2)
			{
				min_rigid_error2 = d_r;
			}

			if (d_r > max_rigid_error2)
			{
				max_rigid_error2 = d_r;
			}

			//double d_lscm = (s_v(0) - s_v(1))*(s_v(0) - s_v(1));
			double d_lscm = (J(0, 0) - J(1, 1))*(J(0, 0) - J(1, 1)) + (J(0, 1) - J(1, 0))*(J(0, 1) - J(1, 0));
			D_angle += d_lscm * face_area;
			if (d_lscm < min_lscm_error)
			{
				min_lscm_error = d_lscm;
			}
			if (d_lscm > max_lscm_error)
			{
				max_lscm_error = d_lscm;
			}
			lscm_distortion[face_id] = d_lscm;
		}
		else
		{
			++flip_tri_count;
			flipped_tri.push_back(face_id);
			cd_above_1000_tri.push_back(face_id);
			//using a <0 number to represent the flipped triangle
			isometric_distortion[face_id] = -1;
			conformal_distortion[face_id] = -1;
			area_d[face_id] = -1;

			//Eigen::Vector2d s_v = J.selfadjointView<Eigen::Lower>().eigenvalues();
			//Eigen::JacobiSVD<Eigen::Matrix2d> svd(J, Eigen::ComputeFullU | Eigen::ComputeFullV);
			//Eigen::Vector2d s_v = svd.singularValues();
			//double d_lscm = (s_v(0) + s_v(1))*(s_v(0) + s_v(1));
			double d_lscm = (J(0, 0) - J(1, 1))*(J(0, 0) - J(1, 1)) + (J(0, 1) - J(1, 0))*(J(0, 1) - J(1, 0));
			D_angle += d_lscm * face_area;
			if (d_lscm < min_lscm_error)
			{
				min_lscm_error = d_lscm;
			}
			if (d_lscm > max_lscm_error)
			{
				max_lscm_error = d_lscm;
			}
			lscm_distortion[face_id] = d_lscm;
			//printf("%f %f %f\n", s_v(0), s_v(1), d_lscm);

			double d_r = (J.transpose()*J - Eigen::Matrix2d::Identity()).squaredNorm();
			D_rigid += d_r;
		}
	}

	ave_iso_dis /= mesh_->n_faces();
	ave_conformal_dis /= mesh_->n_faces();
	avg_area_d /= mesh_->n_faces();

	double std_iso = 0.0; double std_con = 0.0; double std_area = 0.0; int nf_count = 0;
	for (int i = 0; i < isometric_distortion.size(); ++i)
	{
		if (isometric_distortion[i] > 0)
		{
			std_iso += (isometric_distortion[i] - ave_iso_dis)*(isometric_distortion[i] - ave_iso_dis);
			++nf_count;
		}

		if (conformal_distortion[i] > 0)
		{
			std_con += (conformal_distortion[i] - ave_conformal_dis)*(conformal_distortion[i] - ave_conformal_dis);
		}

		if (area_d[i] > 0)
		{
			std_area += (area_d[i] - avg_area_d)*(area_d[i] - avg_area_d);
		}
	}
	std_iso = std::sqrt(std_iso / (nf_count - 1));
	std_con = std::sqrt(std_con / (nf_count - 1));
	std_area = std::sqrt(std_area / (nf_count - 1));

	//D_rigid /= mesh_->n_faces(); 
	D_rigid2 /= mesh_->n_faces();

	//D_angle /= mesh_->n_faces();

	printf("-----------------------------------------------------------\n");
	printf("Flip Count : %d; CD>1000 : %d; AMIPS > 500 : %d\n", flip_tri_count, cd_above_1000_tri.size(), big_AMIPS_energy_count);
	//printf("Con D(MIPS): Max : %f On %d (%f %f); Avg : %f\n", max_error, max_face, singular_value[0], singular_value[1], ave_dis/mesh_->n_faces());
	printf("Iso_D: %f/%f/%f/%f\n", max_iso_dis, min_iso_error, ave_iso_dis, std_iso);
	printf("Con_D: %f/%f/%f/%f\n", max_conformal_error, min_conformal_error, ave_conformal_dis, std_con);
	printf("AREAD: %f/%f/%f/%f\n", max_area_d, min_area_d, avg_area_d, std_area);
	//printf("RIGID: %f/%f/%f (NO Area)\n", max_rigid_error, min_rigid_error, D_rigid);
	//printf("RIGID: %f/%f/%f (With Area)\n", max_rigid_error2, min_rigid_error2, D_rigid2);
	printf("-----------------------------------------------------------\n");
	printf("LSCM: %f/%f/%f (With Area)\n", min_lscm_error, max_lscm_error, D_angle);
	printf("RIGID: %f/%f/%f (NO Area)\n", max_rigid_error, min_rigid_error, D_rigid);
	printf("-----------------------------------------------------------\n");

	max_iso = max_iso_dis; min_iso = min_iso_error; avg_iso = ave_iso_dis; std_iso_ = std_iso;
	max_con = max_conformal_error; min_con = min_conformal_error; avg_con = ave_conformal_dis;
	max_area = max_area_d; min_area = min_area_d; avg_area = avg_area_d;
	//write_conformal_distortion();
	//write_isometric_distortion();

	Eigen::Vector3f c1(0.9, 0.0, 0.0);
	Eigen::Vector3f c2(0.9, 0.9, 0.9);
	vector<Eigen::VectorXf> color(mesh_->n_faces());
	return color;
}
