#include "BCD_Volume_Sphere_Optimization.h"

BCD_Volume_Sphere_Optimization::BCD_Volume_Sphere_Optimization()
{
	mesh_ = NULL;
	reset_all_State();
}

BCD_Volume_Sphere_Optimization::~BCD_Volume_Sphere_Optimization()
{

}

void BCD_Volume_Sphere_Optimization::reset_all_State()
{
	prepare_OK = false; v_same_color.clear(); is_current_max_iso = false;
}

void BCD_Volume_Sphere_Optimization::prepare_data()
{
	if (prepare_OK && v_same_color.size() == mesh_->n_vertices()) return;
	//radius
	radius = 0; unsigned nv = mesh_->n_vertices();
	vertex_radius_ratio.resize(nv);
	v_pos.clear(); v_pos.resize(nv); v_fv_id.clear(); v_fv_id.resize(nv);
	for (MyMesh::VertexIter v_it = mesh_->vertices_begin(); v_it != mesh_->vertices_end(); ++v_it)
	{
		OpenMesh::Vec3d& p = mesh_->point(v_it);
		int v_id = v_it->idx(); //vertex_radius_ratio[v_id] = 1.0;
		v_pos[v_id] = p;
		radius += p.norm(); v_fv_id[v_id].reserve(16);
		for (MyMesh::VertexOHalfedgeIter voh_it = mesh_->voh_iter(v_it); voh_it; ++voh_it)
		{
			MyMesh::VertexHandle vh1 = mesh_->to_vertex_handle(voh_it);
			MyMesh::VertexHandle vh2 = mesh_->to_vertex_handle(mesh_->next_halfedge_handle(voh_it));
			v_fv_id[v_id].push_back(vh1.idx()); v_fv_id[v_id].push_back(vh2.idx());
		}
	}
	
	radius /= nv;
	
	unsigned nf = mesh_->n_faces();
	double A = 4 * M_PI*radius*radius / nf;
	double a = std::sqrt(4 * A / std::sqrt(3.0));

	//desired tetrahedron
	double x0 = 0; double y0 = 0; double z0 = radius;
	double z1 = radius - a*a / radius*0.5; double x1 = std::sqrt(radius*radius - z1*z1); double y1 = 0;
	double z2 = z1;
	double x2 = (-(radius - z2)*(radius - z2) + x1*x1) / x1*0.5;
	double y2 = std::sqrt(radius*radius - x2*x2 - z2*z2);
	Eigen::Matrix3d S;
	S(0, 0) = x0; S(1, 0) = y0; S(2, 0) = z0;
	S(0, 1) = x1; S(1, 1) = y1; S(2, 1) = z1;
	S(0, 2) = x2; S(1, 2) = y2; S(2, 2) = z2;
	SI = S.inverse();
	C00 = SI(0, 0); C01 = SI(0, 1); C02 = SI(0, 2);
	C10 = SI(1, 0); C11 = SI(1, 1); C12 = SI(1, 2);
	C20 = SI(2, 0); C21 = SI(2, 1); C22 = SI(2, 2);
//	compute_distortion();

	//graph coloring
	std::vector<OpenMesh::Vec2i> edges(mesh_->n_edges());
	for (MyMesh::EdgeIter e_it = mesh_->edges_begin(); e_it != mesh_->edges_end(); ++e_it)
	{
		MyMesh::HalfedgeHandle heh = mesh_->halfedge_handle(e_it, 0);
		MyMesh::VertexHandle vh0 = mesh_->to_vertex_handle(heh);
		MyMesh::VertexHandle vh1 = mesh_->from_vertex_handle(heh);
		edges[e_it->idx()][0] = vh0.idx();
		edges[e_it->idx()][1] = vh1.idx();
	}
	v_same_color.clear();
	graph_coloring(nv, edges, v_same_color);

	prepare_OK = true;
}

void BCD_Volume_Sphere_Optimization::optimize_sphere_volume(double ep, int max_iter)
{
	prepare_data();
	/*vertex_radius_ratio.resize(mesh_->n_vertices());
	for (MyMesh::VertexIter v_it = mesh_->vertices_begin(); v_it != mesh_->vertices_end(); ++v_it)
	{
		int v_id = v_it->idx(); vertex_radius_ratio[v_id] = 1.0;
	}*/
	for (int v_id = 0; v_id < vertex_radius_ratio.size(); ++v_id)
	{
		vertex_radius_ratio[v_id] = 1.0;
	}
	long start_t = clock();
	energy_power = ep; int n_color_ = v_same_color.size();
	if (!is_current_max_iso)
	{
		max_iso_distortion();
	}
	is_current_max_iso = false;
	for (int k = 0; k < max_iter; ++k)
	{
		for (unsigned i = 0; i < n_color_; ++i)
		{
			int one_color_size = v_same_color[i].size();
		
#pragma omp parallel for schedule(dynamic)
			for (int j = 0; j < one_color_size; ++j)
			{
				int id = omp_get_thread_num();
				//cout <<id<< endl;
				optimize_sphere_volume_one_V(v_same_color[i][j], id);
			}
		}
	}

	long end_t = clock();
	long diff = end_t - start_t;
	double t = (double)(diff) / CLOCKS_PER_SEC;
//	printf("=====================================\nOptimization Time: %f s\n", t);

	//convert positions
	int nv = v_pos.size();
	for (int v_id = 0; v_id < nv; ++v_id)
	{
		mesh_->set_point(mesh_->vertex_handle(v_id), v_pos[v_id]);
	}
	
//	compute_distortion();
}

void BCD_Volume_Sphere_Optimization::optimize_sphere_volume_one_V(int v_id, int omp_id)
{
	OpenMesh::Vec3d& p0 = v_pos[v_id];
	double gx = 0.0; double gy = 0.0; double gz = 0.0;
	double local_src_energy = 0.0; double min_radius = 1e30;
	std::vector<int>& one_v_fv_id = v_fv_id[v_id];
	int size_vfv = one_v_fv_id.size();
	//local_mips_energy = 0;
	for (int i = 0; i < size_vfv; i += 2)
	{
		OpenMesh::Vec3d& p1 = v_pos[one_v_fv_id[i]];
		OpenMesh::Vec3d& p2 = v_pos[one_v_fv_id[i + 1]];

		double len = (p1 - p0).norm(); if (len < min_radius) min_radius = len;
		len = (p2 - p0).norm(); if (len < min_radius) min_radius = len;

		double D00 = p0[0]; double D10 = p0[1]; double D20 = p0[2];
		double D01 = p1[0]; double D11 = p1[1]; double D21 = p1[2];
		double D02 = p2[0]; double D12 = p2[1]; double D22 = p2[2];

		double A00 = C00*D00 + C10*D01 + C20*D02; double d_A00_x = C00;
		double A10 = C00*D10 + C10*D11 + C20*D12; double d_A10_y = C00;
		double A20 = C00*D20 + C10*D21 + C20*D22; double d_A20_z = C00;
		double A01 = C01*D00 + C11*D01 + C21*D02; double d_A01_x = C01;
		double A11 = C01*D10 + C11*D11 + C21*D12; double d_A11_y = C01;
		double A21 = C01*D20 + C11*D21 + C21*D22; double d_A21_z = C01;
		double A02 = C02*D00 + C12*D01 + C22*D02; double d_A02_x = C02;
		double A12 = C02*D10 + C12*D11 + C22*D12; double d_A12_y = C02;
		double A22 = C02*D20 + C12*D21 + C22*D22; double d_A22_z = C02;

		double A2_00 = A00 *A00 + A10*A10 + A20 *A20;
		double A2_01 = A00*A01 + A10*A11 + A20*A21;
		double A2_02 = A00*A02 + A10*A12 + A20*A22;
		double A2_11 = A01 *A01 + A11*A11 + A21 *A21;
		double A2_12 = A01*A02 + A11*A12 + A21*A22;
		double A2_22 = A02 *A02 + A12*A12 + A22 *A22;

		double AF = A2_00 + A2_11 + A2_22; double AF_05 = std::sqrt(AF); double I_AF_05 = 0.5 / AF_05;
		double AF2 = A2_00*A2_00 + A2_01*A2_01 * 2 + A2_02*A2_02 * 2 + A2_11*A2_11 + A2_12*A2_12 * 2 + A2_22*A2_22;
		double AF_I = (AF*AF - AF2)*0.5; double AF_I_05 = std::sqrt(AF_I); double I_AF_I_05 = 0.5 / AF_I_05;
		double det_A = A00 * A11 * A22 + A01 * A12 * A20 + A02 * A10 * A21 - A02 * A11 * A20 - A01 * A10 * A22 - A00 * A12 * A21;
		double i_det_A = 1.0 / det_A;

		double e = AF_05*AF_I_05 * i_det_A;
		double mips_e = (e*e - 1.0)*0.125;

		double D_AF_x = (2.0*A00*d_A00_x + 2.0*A01*d_A01_x + 2.0*A02*d_A02_x);
		double D_AF_y = (2.0*A10*d_A10_y + 2.0*A11*d_A11_y + 2.0*A12*d_A12_y);
		double D_AF_z = (2.0*A20*d_A20_z + 2.0*A21*d_A21_z + 2.0*A22*d_A22_z);

		double D_AF2_x = (2.0*A2_00*2.0*A00*d_A00_x + 4.0*A2_01*(A01*d_A00_x + A00*d_A01_x) + 4.0*A2_02*(A02*d_A00_x + A00*d_A02_x)
			+ 2.0*A2_11*2.0*A01*d_A01_x + 2.0*A2_22*2.0*A02*d_A02_x + 4.0*A2_12*(A01*d_A02_x + A02*d_A01_x));

		double D_AF2_y = (2.0*A2_00*2.0*A10*d_A10_y + 4.0*A2_01*(A11*d_A10_y + A10*d_A11_y) + 4.0*A2_02*(A12*d_A10_y + A10*d_A12_y)
			+ 2.0*A2_11*2.0*A11*d_A11_y + 2.0*A2_22*2.0*A12*d_A12_y + 4.0*A2_12*(A11*d_A12_y + A12*d_A11_y));

		double D_AF2_z = (2.0*A2_00*2.0*A20*d_A20_z + 4.0*A2_01*(A21*d_A20_z + A20*d_A21_z) + 4.0*A2_02*(A22*d_A20_z + A20*d_A22_z)
			+ 2.0*A2_11*2.0*A21*d_A21_z + 2.0*A2_22*2.0*A22*d_A22_z + 4.0*A2_12*(A21*d_A22_z + A22*d_A21_z));

		double D_AF_I_x = (AF*D_AF_x - 0.5*D_AF2_x)*I_AF_I_05; double D_AF_I_y = (AF*D_AF_y - 0.5*D_AF2_y)*I_AF_I_05; double D_AF_I_z = (AF*D_AF_z - 0.5*D_AF2_z)*I_AF_I_05;
		D_AF_x *= I_AF_05; D_AF_y *= I_AF_05; D_AF_z *= I_AF_05;

		double D_det_A_x = d_A00_x * A11 * A22 + d_A01_x * A12 * A20 + d_A02_x * A10 * A21 - d_A02_x * A11 * A20 - d_A01_x * A10 * A22 - d_A00_x * A12 * A21;
		double D_det_A_y = A00 * d_A11_y * A22 + A01 * d_A12_y * A20 + A02 * d_A10_y * A21 - A02 * d_A11_y * A20 - A01 * d_A10_y * A22 - A00 * d_A12_y * A21;
		double D_det_A_z = A00 * A11 * d_A22_z + A01 * A12 * d_A20_z + A02 * A10 * d_A21_z - A02 * A11 * d_A20_z - A01 * A10 * d_A22_z - A00 * A12 * d_A21_z;

		double g = AF_05 * AF_I_05;
		double dgx = D_AF_x * AF_I_05 + AF_05*D_AF_I_x;
		double dgy = D_AF_y * AF_I_05 + AF_05*D_AF_I_y;
		double dgz = D_AF_z * AF_I_05 + AF_05*D_AF_I_z;

		double dex = (dgx * i_det_A - g * D_det_A_x / (det_A*det_A));
		double dey = (dgy * i_det_A - g * D_det_A_y / (det_A*det_A));
		double dez = (dgz * i_det_A - g * D_det_A_z / (det_A*det_A));

		double d_mips_e_x = e * 0.25 * dex;
		double d_mips_e_y = e * 0.25 * dey;
		double d_mips_e_z = e * 0.25 * dez;
		/*double vol_e = 0.5*(det_A + i_det_A);
		double inv_det_A_2_05 = 0.5 *(1.0 - i_det_A*i_det_A);
		double dvex = D_det_A_x*inv_det_A_2_05;
		double dvey = D_det_A_y*inv_det_A_2_05;
		double dvez = D_det_A_z*inv_det_A_2_05;*/

		/*double k = (mips_e + vol_e) * energy_power;
		if (k > 60) k = 60; double exp_e = std::exp(k);
		local_src_energy += exp_e;*/

		/*dex = (d_mips_e_x + dvex)*energy_power * exp_e;
		dey = (d_mips_e_y + dvey)*energy_power * exp_e;
		dez = (d_mips_e_z + dvez)*energy_power * exp_e;*/
		//double mid_e = f->get(mips_e);
		//double exp_e = fmath::expd(mid_e);
		double mid_e = std::pow(mips_e, energy_power);
		double exp_e = std::exp(mid_e);
		local_src_energy += exp_e;
		//fmath::PowGenerator f1(energy_power - 1.0);
		//double mid_ = f1.get(mips_e);
		dex = d_mips_e_x* energy_power * mid_e/mips_e * exp_e;
		dey = d_mips_e_y* energy_power * mid_e/mips_e * exp_e;
		dez = d_mips_e_z* energy_power * mid_e/mips_e * exp_e;

		//double exp_e = std::exp(std::pow(mips_e, energy_power));
		//local_src_energy += exp_e; //local_mips_energy += mips_e;
		//dex = d_mips_e_x* energy_power * std::pow(mips_e, energy_power - 1.0) * exp_e;
		//dey = d_mips_e_y* energy_power * std::pow(mips_e, energy_power - 1.0) * exp_e;
		//dez = d_mips_e_z* energy_power * std::pow(mips_e, energy_power - 1.0) * exp_e;

		gx += dex; gy += dey; gz += dez;
	}
	/*if (local_mips_energy < 3*size_vfv)
	{
		return;
	}*/
	OpenMesh::Vec3d d(gx, gy, gz);
	double move_d = d.norm();
	if (move_d > 1e40 )
	{
		d[0] = 0; d[1] = 0; d[2] = 0;
		move_d = 0;
	}
	if (move_d > min_radius)
	{
		d = min_radius*d / move_d;
		move_d = min_radius;
	}
	d *= vertex_radius_ratio[v_id];
	move_d *= vertex_radius_ratio[v_id];
	OpenMesh::Vec3d np = p0 - d; np = np*radius / np.norm();
	while (!locally_check_negative_volume(np, size_vfv, one_v_fv_id))
	{
		d *= 0.8;
		//move_d = d.norm();
		move_d *= 0.8;
		if (move_d < 1e-8)
		{
			np = p0; move_d = 0.0; break;
		}
		else
		{
			np = p0 - d; np = np*radius / np.norm();
		}
	}

	double new_e = compute_local_exp_mips_energy(np, size_vfv, one_v_fv_id);
	if (new_e > local_src_energy)
	{
		while (new_e > local_src_energy)
		{
			d *= 0.2; move_d *= 0.2;
			//move_d = d.norm();
			if (move_d < m_l)
			{
				np = p0; move_d = 0.0; break;
			}
			else
			{
				np = p0 - d; np = np*radius / np.norm();
			}
			new_e = compute_local_exp_mips_energy(np, size_vfv, one_v_fv_id);
		}
		if (new_e < local_src_energy)
		{
			new_e = local_src_energy + 1; d *= 5; move_d *= 5;
			while (new_e > local_src_energy)
			{
				d *= 0.5; move_d *= 0.5;
				//move_d = d.norm();
				if (move_d < m_l)
				{
					np = p0; move_d = 0.0; break;
				}
				else
				{
					np = p0 - d; np = np*radius / np.norm();
				}
				new_e = compute_local_exp_mips_energy(np, size_vfv, one_v_fv_id);
			}
			if (new_e < local_src_energy)
			{
				new_e = local_src_energy + 1; d *= 2; move_d *= 2;
				while (new_e > local_src_energy)
				{
					d *= 0.75; move_d *= 0.75;
					//move_d = d.norm();
					if (move_d < m_l)
					{
						np = p0; move_d = 0.0; break;
					}
					else
					{
						np = p0 - d; np = np*radius / np.norm();
					}
					new_e = compute_local_exp_mips_energy(np, size_vfv, one_v_fv_id);
				}
				if (new_e < local_src_energy)
				{
					new_e = local_src_energy + 1; d /= 0.75; move_d /= 0.75;
					while (new_e > local_src_energy)
					{
						d *= 0.945; move_d *= 0.945;
						//move_d = d.norm();
						if (move_d < m_l)
						{
							np = p0; move_d = 0.0; break;
						}
						else
						{
							np = p0 - d; np = np*radius / np.norm();
						}
						new_e = compute_local_exp_mips_energy(np, size_vfv, one_v_fv_id);
					}
				}
			}
		}
	}

	if (move_d > 1e-8)
	{
		if (vertex_radius_ratio[v_id] > 0.07)
		{
			if (std::abs(local_src_energy - new_e) < 1e-2 * local_src_energy)
			{
				vertex_radius_ratio[v_id] = 0.5;
			}
			if (std::abs(local_src_energy - new_e) < 1e-4 * local_src_energy)
			{
				vertex_radius_ratio[v_id] = 0.2;
			}
			if (std::abs(local_src_energy - new_e) < 1e-5 * local_src_energy)
			{
				vertex_radius_ratio[v_id] = 0.1;
			}
			if (std::abs(local_src_energy - new_e) < 1e-6 * local_src_energy)
			{
				vertex_radius_ratio[v_id] = 0.06;
			}
		}
	}
	p0 = np;
}

bool BCD_Volume_Sphere_Optimization::locally_check_negative_volume(MyMesh::VertexHandle& vh, OpenMesh::Vec3d& np)
{
	for (MyMesh::VertexOHalfedgeIter voh_it = mesh_->voh_iter(vh); voh_it; ++voh_it)
	{
		OpenMesh::Vec3d& p1 = mesh_->point(mesh_->to_vertex_handle(voh_it));
		OpenMesh::Vec3d& p2 = mesh_->point(mesh_->to_vertex_handle(mesh_->next_halfedge_handle(voh_it)));

		double v = OpenMesh::dot(np, OpenMesh::cross(p1, p2));
		if (v < 1e-8) return false;
	}
	return true;
}

bool BCD_Volume_Sphere_Optimization::locally_check_negative_volume(OpenMesh::Vec3d& np, int size_vfv, std::vector<int>& one_v_fv_id)
{
	for (int i = 0; i < size_vfv; i += 2)
	{
		OpenMesh::Vec3d& p1 = v_pos[one_v_fv_id[i]];
		OpenMesh::Vec3d& p2 = v_pos[one_v_fv_id[i + 1]];

		double v = OpenMesh::dot(np, OpenMesh::cross(p1, p2));
		if (v < m_v) return false;
	}
	return true;
}

double BCD_Volume_Sphere_Optimization::compute_local_exp_mips_energy(MyMesh::VertexHandle& vh, OpenMesh::Vec3d& np)
{
	double all_e = 0.0;
	for (MyMesh::VertexOHalfedgeIter voh_it = mesh_->voh_iter(vh); voh_it; ++voh_it)
	{
		OpenMesh::Vec3d& p1 = mesh_->point(mesh_->to_vertex_handle(voh_it));
		OpenMesh::Vec3d& p2 = mesh_->point(mesh_->to_vertex_handle(mesh_->next_halfedge_handle(voh_it)));
	
		double D00 = np[0]; double D10 = np[1]; double D20 = np[2];
		double D01 = p1[0]; double D11 = p1[1]; double D21 = p1[2];
		double D02 = p2[0]; double D12 = p2[1]; double D22 = p2[2];

		double A00 = C00*D00 + C10*D01 + C20*D02;
		double A10 = C00*D10 + C10*D11 + C20*D12;
		double A20 = C00*D20 + C10*D21 + C20*D22;
		double A01 = C01*D00 + C11*D01 + C21*D02;
		double A11 = C01*D10 + C11*D11 + C21*D12;
		double A21 = C01*D20 + C11*D21 + C21*D22;
		double A02 = C02*D00 + C12*D01 + C22*D02;
		double A12 = C02*D10 + C12*D11 + C22*D12;
		double A22 = C02*D20 + C12*D21 + C22*D22;

		double A2_00 = A00 *A00 + A10*A10 + A20 *A20;
		double A2_01 = A00*A01 + A10*A11 + A20*A21;
		double A2_02 = A00*A02 + A10*A12 + A20*A22;
		double A2_11 = A01 *A01 + A11*A11 + A21 *A21;
		double A2_12 = A01*A02 + A11*A12 + A21*A22;
		double A2_22 = A02 *A02 + A12*A12 + A22 *A22;

		double AF = A2_00 + A2_11 + A2_22; double AF_05 = std::sqrt(AF); double I_AF_05 = 0.5 / AF_05;
		double AF2 = A2_00*A2_00 + A2_01*A2_01 * 2 + A2_02*A2_02 * 2 + A2_11*A2_11 + A2_12*A2_12 * 2 + A2_22*A2_22;
		double AF_I = (AF*AF - AF2)*0.5; double AF_I_05 = std::sqrt(AF_I); double I_AF_I_05 = 0.5 / AF_I_05;
		double det_A = A00 * A11 * A22 + A01 * A12 * A20 + A02 * A10 * A21 - A02 * A11 * A20 - A01 * A10 * A22 - A00 * A12 * A21;
		double i_det_A = 1.0 / det_A;

		double e = AF_05*AF_I_05 * i_det_A;
		double mips_e = (e*e - 1.0)*0.125;
		double vol_e = 0.5*(det_A + 1.0 / det_A);

		double k = (mips_e + vol_e) * energy_power;
		if (k > 60) k = 60; double exp_e = std::exp(k);
		all_e += exp_e;
	}
	return all_e;
}

double BCD_Volume_Sphere_Optimization::compute_local_exp_mips_energy(OpenMesh::Vec3d& np, int size_vfv, std::vector<int>& one_v_fv_id)
{
	double all_e = 0.0;
	double D00 = np[0]; double D10 = np[1]; double D20 = np[2];
	//double e[50];
	//int counter = 0;
	//cout <<"vvsize: "<<size_vfv << endl;
	for (int i = 0; i < size_vfv; i += 2)
	{
		OpenMesh::Vec3d& p1 = v_pos[one_v_fv_id[i]];
		OpenMesh::Vec3d& p2 = v_pos[one_v_fv_id[i + 1]];
		
		double D01 = p1[0]; double D11 = p1[1]; double D21 = p1[2];
		double D02 = p2[0]; double D12 = p2[1]; double D22 = p2[2];

		double A00 = C00*D00 + C10*D01 + C20*D02;
		double A10 = C00*D10 + C10*D11 + C20*D12;
		double A20 = C00*D20 + C10*D21 + C20*D22;
		double A01 = C01*D00 + C11*D01 + C21*D02;
		double A11 = C01*D10 + C11*D11 + C21*D12;
		double A21 = C01*D20 + C11*D21 + C21*D22;
		double A02 = C02*D00 + C12*D01 + C22*D02;
		double A12 = C02*D10 + C12*D11 + C22*D12;
		double A22 = C02*D20 + C12*D21 + C22*D22;

		double A2_00 = A00 *A00 + A10*A10 + A20 *A20;
		double A2_01 = A00*A01 + A10*A11 + A20*A21;
		double A2_02 = A00*A02 + A10*A12 + A20*A22;
		double A2_11 = A01 *A01 + A11*A11 + A21 *A21;
		double A2_12 = A01*A02 + A11*A12 + A21*A22;
		double A2_22 = A02 *A02 + A12*A12 + A22 *A22;

		double AF = A2_00 + A2_11 + A2_22; 
		double AF2 = A2_00*A2_00 + A2_01*A2_01 * 2 + A2_02*A2_02 * 2 + A2_11*A2_11 + A2_12*A2_12 * 2 + A2_22*A2_22;
		double AF_I = (AF*AF - AF2)*0.5; 
		double det_A = A00 * A11 * A22 + A01 * A12 * A20 + A02 * A10 * A21 - A02 * A11 * A20 - A01 * A10 * A22 - A00 * A12 * A21;
		double i_det_A = 1.0 / det_A;

		
		double mips_e = (AF*AF_I* i_det_A* i_det_A - 1.0)*0.125;

		if (mips_e < 1 - 1e-6 || det_A <= 0) return std::numeric_limits<double>::infinity();

		if ((mips_e) > high_d) return std::numeric_limits<double>::infinity();
		//double k = f->get(mips_e);
		//e[counter] = k;
		//counter++;
		//all_e += fmath::expd(k);
		double k = std::pow(mips_e, energy_power);
		all_e += std::exp(k);
	}
	/*fmath::expd_v(e, counter);
	for (int i = 0; i < counter; i++)
	{
		all_e += e[i];
	}*/
	return all_e;
}

void BCD_Volume_Sphere_Optimization::compute_distortion()
{
	flip_count = 0; Eigen::Vector3d a; double cd_count = 0.0;
	max_cd = 0.0; min_cd = 1e30; avg_cd = 0.0;
	max_iso = 0.0; min_iso = 1e30; avg_iso = 0.0;
	max_vol = 0.0; min_vol = 1e30; avg_vol = 0.0;
	std::vector<double> all_iso_d; std::vector<double> all_con_d; std::vector<double> all_vol_d;
	for (MyMesh::FaceIter f_it = mesh_->faces_begin(); f_it != mesh_->faces_end(); ++f_it)
	{
		MyMesh::FaceVertexIter fv_it = mesh_->fv_iter(f_it);
		OpenMesh::Vec3d& p0 = mesh_->point(fv_it);
		++fv_it; OpenMesh::Vec3d& p1 = mesh_->point(fv_it);
		++fv_it; OpenMesh::Vec3d& p2 = mesh_->point(fv_it);
		Eigen::Matrix3d P;
		P << p0[0], p1[0], p2[0], p0[1], p1[1], p2[1], p0[2], p1[2], p2[2];
		Eigen::Matrix3d A = P*SI;

		if (A.determinant() < 0)
		{
			++flip_count;
			printf("Flipped %d : %f\n", f_it->idx(), A.determinant());
		}
		else
		{
			Eigen::JacobiSVD<Eigen::Matrix3d> svd(A);
			a = svd.singularValues();
			double cd = a(0) / a(2);
			if (cd > max_cd) { max_cd = cd; }
			if (cd < min_cd) min_cd = cd;
			avg_cd += cd; cd_count += 1.0;
			all_con_d.push_back(cd);

			double iso_d = a(0) > 1.0 / a(2) ? a(0) : 1.0 / a(2);
			if (iso_d > max_iso){ max_iso = iso_d; }
			if (iso_d < min_iso) min_iso = iso_d;
			avg_iso += iso_d;
			all_iso_d.push_back(iso_d);

			double dJ = a(0)*a(1)*a(2);

			double vol_d = dJ > 1.0 / dJ ? dJ : 1.0 / dJ;
			if (vol_d > max_vol){ max_vol = vol_d; }
			if (vol_d < min_vol) min_vol = vol_d;
			avg_vol += vol_d;
			all_vol_d.push_back(vol_d);
		}
	}
	avg_cd /= cd_count; avg_iso /= cd_count; avg_vol /= cd_count;
	double std_id = 0.0; double std_cd = 0.0; double std_vd = 0.0;
	for (int i = 0; i < all_iso_d.size(); ++i)
	{
		if (all_iso_d[i] > 0)
		{
			std_cd += (avg_cd - all_con_d[i])*(avg_cd - all_con_d[i]);
			std_id += (avg_iso - all_iso_d[i])*(avg_iso - all_iso_d[i]);
			std_vd += (avg_vol - all_vol_d[i])*(avg_vol - all_vol_d[i]);
		}
	}
	std_id = std::sqrt(std_id / (cd_count - 1)); std_cd = std::sqrt(std_cd / (cd_count - 1)); std_vd = std::sqrt(std_vd / (cd_count - 1));
	printf("---------------------------------------------------------\n");
	printf("Flip Count : %d\n", flip_count);
	printf("Isometric Distortion: %f/%f/%f/%f\n", max_iso, min_iso, avg_iso, std_id);
	printf("Conformal Distortion: %f/%f/%f/%f\n", max_cd, min_cd, avg_cd, std_cd);
	printf("Volume Distortion: %f/%f/%f/%f\n", max_vol, min_vol, avg_vol, std_vd);
}

double BCD_Volume_Sphere_Optimization::max_iso_distortion()
{
	flip_count = 0;
	Eigen::Vector3d a;
	double max_iso = 0.0;
	std::vector<double> all_iso_d;
	high_d = 0;
	for (MyMesh::FaceIter f_it = mesh_->faces_begin(); f_it != mesh_->faces_end(); ++f_it)
	{
		MyMesh::FaceVertexIter fv_it = mesh_->fv_iter(f_it);
		OpenMesh::Vec3d& p0 = mesh_->point(fv_it);
		++fv_it; OpenMesh::Vec3d& p1 = mesh_->point(fv_it);
		++fv_it; OpenMesh::Vec3d& p2 = mesh_->point(fv_it);
		Eigen::Matrix3d P;
		P << p0[0], p1[0], p2[0], p0[1], p1[1], p2[1], p0[2], p1[2], p2[2];
		Eigen::Matrix3d A = P*SI;

		if (A.determinant() < 0)
		{
			flip_count++;
			printf("Flipped %d : %f\n", f_it->idx(), A.determinant());
		}
		else
		{
			Eigen::JacobiSVD<Eigen::Matrix3d> svd(A);
			a = svd.singularValues();
			double iso_d = a(0) > 1.0 / a(2) ? a(0) : 1.0 / a(2);
			if (iso_d > max_iso){ max_iso = iso_d; }
			all_iso_d.push_back(iso_d);

			double temp = 0.125*(a(0) / a(2) + a(2) / a(0))*(a(0) / a(1) + a(1) / a(0))*(a(1) / a(2) + a(2) / a(1));
			if (temp > high_d)
			{
				high_d = temp;
			}
		}
		
	}
	energy_power = fmath::log(50.0) / fmath::log(high_d);
	f = new fmath::PowGenerator(energy_power);
	//printf("G Max iso d: %f   energy_power: %f\n", max_iso,energy_power);
	is_current_max_iso = true;
	return max_iso;
}

double BCD_Volume_Sphere_Optimization::max_iso_local_distortion(MyMesh::VertexHandle &v,double r)
{
	radius = r;
	unsigned nf = mesh_->n_faces();
	double A = 4 * M_PI*radius*radius / nf;
	double a = std::sqrt(4 * A / std::sqrt(3.0));

	//desired tetrahedron
	double x0 = 0; double y0 = 0; double z0 = radius;
	double z1 = radius - a*a / radius*0.5; double x1 = std::sqrt(radius*radius - z1*z1); double y1 = 0;
	double z2 = z1;
	double x2 = (-(radius - z2)*(radius - z2) + x1*x1) / x1*0.5;
	double y2 = std::sqrt(radius*radius - x2*x2 - z2*z2);
	Eigen::Matrix3d S;
	S(0, 0) = x0; S(1, 0) = y0; S(2, 0) = z0;
	S(0, 1) = x1; S(1, 1) = y1; S(2, 1) = z1;
	S(0, 2) = x2; S(1, 2) = y2; S(2, 2) = z2;
	SI = S.inverse();
	Eigen::Vector3d a0;
	double max_iso = 0.0;
	std::vector<double> local_iso_d;
	for (auto vf = mesh_->vf_begin(v); vf != mesh_->vf_end(v); ++vf)
	{
		MyMesh::FaceVertexIter fv_it = mesh_->fv_iter(vf);
		OpenMesh::Vec3d& p0 = mesh_->point(fv_it);
		++fv_it; OpenMesh::Vec3d& p1 = mesh_->point(fv_it);
		++fv_it; OpenMesh::Vec3d& p2 = mesh_->point(fv_it);
		Eigen::Matrix3d P;
		P << p0[0], p1[0], p2[0], p0[1], p1[1], p2[1], p0[2], p1[2], p2[2];
		Eigen::Matrix3d A = P*SI;

		if (A.determinant() < 0)
		{
			printf("Flipped %d : %f\n", vf->idx(), A.determinant());
		}
		else
		{
			Eigen::JacobiSVD<Eigen::Matrix3d> svd(A);
			a0 = svd.singularValues();
			double iso_d = a0(0) > 1.0 / a0(2) ? a0(0) : 1.0 / a0(2);
			if (iso_d > max_iso){ max_iso = iso_d; }
			local_iso_d.push_back(iso_d);
		}
	}
	//printf("L Max iso d: %f\n", max_iso);
	return max_iso;
}

bool BCD_Volume_Sphere_Optimization::checklap(MyMesh* mesh_, double threh)
{
	int nf = mesh_->n_faces();
	int counter = 0;
	for (auto f_it = mesh_->faces_begin(); f_it != mesh_->faces_end(); ++f_it)
	{
		vector<MyMesh::Point> v;
		for (auto fv = mesh_->fv_begin(f_it); fv != mesh_->fv_end(f_it); ++fv)
		{
			v.push_back(mesh_->point(fv));
		}
		double vol = (v[1] % v[2]) | v[0];
		if (vol < threh)
		{
			return true;
		}
		counter++;
	}
	return false;
}