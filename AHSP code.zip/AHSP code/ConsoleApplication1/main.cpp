#include "HierarchicalSphereParametrization.h"

void GetFileExtension(const string & fileName, string & fileExtension);
void read_mesh_obj(const char* filename,MyMesh &m);

int main(int argc, char *argv[])
{
	if (argc != 4)
	{
	   cout << "Recommended parameters: ./HierarSpherePara input.obj 1/0 20 " << endl;
	   return -1;
	}

	const string  fileName(argv[1]);

	bool          is_QEM = atoi(argv[2]);

	size_t        iter_num = atoi(argv[3]);

	ofstream SaveFile("result_record.txt", ios::app);
	string str_1 = ".txt";
	string fn = fileName + str_1;
	FILE *out = fopen(fn.c_str(), "wt+");
	if (out == NULL)
	{
		return 1;
	}

	cout << "* Load mesh " << endl;
	MyMesh mesh;
	string fileExtension;
	GetFileExtension(fileName, fileExtension);
	OpenMesh::IO::Options opt_read = 0x0000;
	if ((fileExtension == ".OFF") || (fileExtension == ".OBJ"))
	{
		if (!OpenMesh::IO::read_mesh(mesh, fileName, opt_read))
		{
			cout << "load mesh faild!" << endl;
			return -1;
		}
		fprintf(out, "Loading is ok.\n");
		fprintf(out, "#ver:   %d", mesh.n_vertices());
		fprintf(out, "\n");
	}
	else
	{
		cout << "Format not supported!" << endl;
		return -1;
	}
	read_mesh_obj(fileName.c_str(),mesh);

	char s = fileName[0];
	int i = 0;
	while (s != '.')
	{
		i++;
		s = fileName[i];
	}
	string fi_na;
	for (int j = 0; j < i; j++)
	{
		fi_na.push_back(fileName[j]);
	}

	fprintf(out, "*Simplification is start:\n");
	cout << "* Simplification "<< endl;
	long start_t = clock();

	MyMesh mesh_copy = mesh;
	OpenMesh::Smoother::JacobiLaplaceSmootherT<MyMesh> smoother(mesh);
	smoother.initialize(smoother.Tangential, smoother.C1);   //Smooth direction Continuity

	// Execute 3 smooth steps
	smoother.smooth(20);
	smoother.initialize(smoother.Tangential_and_Normal, smoother.C1);
	smoother.smooth(1);

	HierarchicalSphereParametrization *hsp = new HierarchicalSphereParametrization(mesh);
	int genu = hsp->n_vertices - hsp->n_edges + hsp->n_faces - 2;
	if (genu)
	{
		cout <<"the genu of the mesh is not 0 !" << endl;
		fprintf(out, "the genu of the mesh is not 0 !");
		SaveFile << fi_na << "    " << "the genu of the mesh is not 0 !\n";
		return -1;
	}

	vector<vector<int>> copy_index_collapse_v_to_v;
	copy_index_collapse_v_to_v.clear();
	if (is_QEM)
	{
		hsp->QEM_Simplify(2000, 1e-4);
		hsp->LaplacianSmooth(hsp->origin_mesh, 3);
	}
	fprintf(out, "After QEM simplify: %d\n", hsp->origin_mesh.n_vertices());
	copy_index_collapse_v_to_v = hsp->do_Simplify();
	long end_t = clock();
	long diff = end_t - start_t;
	double t = (double)(diff) / CLOCKS_PER_SEC;
	cout << "Simplify Time: " << t << endl;
	fprintf(out, "After Simplify :   %d     Simplify time  %fs\n", hsp->origin_mesh.n_vertices(), t);
	fprintf(out, "\n");
	fprintf(out, "*Subdivision is start:\n");
	cout <<"* Subdivision " << endl;
	start_t = clock();
	hsp->Subdivision(iter_num, copy_index_collapse_v_to_v);
	mesh = hsp->origin_mesh;
	end_t = clock();
	diff = end_t - start_t;
	t = (double)(diff) / CLOCKS_PER_SEC;
	if (hsp->origin_mesh.n_vertices() == hsp->copy_origin_mesh1.n_vertices())
	{
		SaveFile << fi_na << "    " << "Subdivision success!\n";
		fprintf(out, "Subdivision success!\n");
		fprintf(out, "Subdivision Time:  %fs\n",t);
		fprintf(out, "\n");
		fprintf(out, "Isometric Distortion: %f/%f/%f\n", hsp->bcd_v_optimization->max_iso, hsp->bcd_v_optimization->min_iso, hsp->bcd_v_optimization->avg_iso);
		fprintf(out, "Conformal Distortion: %f/%f/%f\n", hsp->bcd_v_optimization->max_cd, hsp->bcd_v_optimization->min_cd, hsp->bcd_v_optimization->avg_cd);
		fprintf(out, "Volume Distortion: %f/%f/%f\n", hsp->bcd_v_optimization->max_vol, hsp->bcd_v_optimization->min_vol, hsp->bcd_v_optimization->avg_vol);
		fprintf(out, "\n");

		hsp->bcd_optimization = new BCD_Sphere_Optimization(&mesh, &mesh_copy, hsp->radius);
		hsp->bcd_optimization->triangle_distortion(&mesh, &mesh_copy);
		hsp->bcd_optimization->prepare_parameterization();
		hsp->bcd_optimization->do_parallel_EXP_parameterizing(1.0, 0.5, 50);
		hsp->bcd_optimization->do_parallel_EXP_parameterizing(1.0, 0.5, 50);
		hsp->bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
		hsp->bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
		hsp->bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
		hsp->bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
		hsp->bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
		hsp->bcd_optimization->do_parallel_EXP_parameterizing(1.0, 0.5, 50);
		hsp->bcd_optimization->do_parallel_EXP_parameterizing(1.0, 0.5, 50);
		hsp->bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
		hsp->bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
		hsp->bcd_optimization->do_parallel_EXP_parameterizing(2.0, 0.5, 50);
		hsp->bcd_optimization->triangle_distortion(&mesh, &mesh_copy);
		fprintf(out, "Isometric Distortion: %f/%f/%f/%f\n", hsp->bcd_optimization->max_iso, hsp->bcd_optimization->min_iso, hsp->bcd_optimization->avg_iso,hsp->bcd_optimization->std_iso_);
		fprintf(out, "Conformal Distortion: %f/%f/%f\n", hsp->bcd_optimization->max_con, hsp->bcd_optimization->min_con, hsp->bcd_optimization->avg_con);
		fprintf(out, "area Distortion: %f/%f/%f\n", hsp->bcd_optimization->max_area, hsp->bcd_optimization->min_area, hsp->bcd_optimization->avg_area);
		fprintf(out, "\n");
	}
	else
	{
		SaveFile << fi_na << "    " << "Subdivision failed!\n";
		fprintf(out, "Subdivision failed !\n");
	}

	end_t = clock();
	diff = end_t - start_t;
	t = (double)(diff) / CLOCKS_PER_SEC;
	cout << "all Time: " << t << endl;
	fprintf(out, "all Time:  %fs\n", t);

	hsp->bcd_optimization->PrintObj(fileName + "_op", &mesh);
	bool is_overlap = hsp->bcd_optimization->checklap(&mesh, 1e-12);
	if (is_overlap)
	{
		cout << "the result have overlap" << endl;
		fprintf(out, "the result have overlap\n");
	}
	else
	{
		cout << "the result do not have overlap" << endl;
		fprintf(out, "the result do not have overlap\n");
	}
	fclose(out);
	SaveFile.close();
	return 0;
}

void GetFileExtension(const string & fileName, string & fileExtension)
{
	size_t lastDotPosition = fileName.find_last_of(".");
	if (lastDotPosition == string::npos)
	{
		fileExtension = "";
	}
	else
	{
		fileExtension = fileName.substr(lastDotPosition, fileName.size());
		transform(fileExtension.begin(), fileExtension.end(), fileExtension.begin(), ::toupper);
	}
}

void read_mesh_obj(const char* filename, MyMesh &m)
{
	//simple obj file reading
	FILE* f_obj = fopen(filename, "r");
	if (NULL == f_obj){ return; }
	char line_buf[1024];
	char p1[128]; char p2[128]; char p3[128]; char temp[128];
	int v_count = 0;
	while (!feof(f_obj))
	{
		if (fgets(line_buf, 1024, f_obj) == NULL) { break; }
		if (line_buf[0] == 'v' && line_buf[1] == ' ')
		{
			sscanf(line_buf, "%s %s %s %s", temp, p1, p2, p3);
			int v_id = v_count; MyMesh::Point p(atof(p1), atof(p2), atof(p3));
			m.set_point(m.vertex_handle(v_id), p);
			++v_count;
		}
	}

	fclose(f_obj);
}