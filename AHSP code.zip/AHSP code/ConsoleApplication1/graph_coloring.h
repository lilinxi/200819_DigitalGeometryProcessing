#ifndef GRAPH_COLORING_H
#define GRAPH_COLORING_H

#  define BOOST_NO_CXX11_VARIADIC_TEMPLATES

#include <iostream>
#include <string>
#include <fstream>
#include "time.h"
#include "Parametrization.h"

#include <boost/graph/adjacency_list.hpp>
#include <boost/property_map/shared_array_property_map.hpp> //this should be included from smallest_last_ordering.hpp
#include <boost/graph/smallest_last_ordering.hpp>
#include <boost/graph/sequential_vertex_coloring.hpp>

using namespace boost;

/*
N: The number of the vertices
graph_color_edge: the edge collection
v_same_color: the vertices with same color are stored in one vector
*/
void graph_coloring(int N, std::vector<OpenMesh::Vec2i>& graph_color_edge, std::vector< std::vector<int> >& v_same_color);

#endif
