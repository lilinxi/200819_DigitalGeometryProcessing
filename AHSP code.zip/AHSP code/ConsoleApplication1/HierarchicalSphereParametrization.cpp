#include "HierarchicalSphereParametrization.h"

HierarchicalSphereParametrization::HierarchicalSphereParametrization(void)
{
}

HierarchicalSphereParametrization::HierarchicalSphereParametrization(MyMesh &mesh)
{
	origin_mesh = mesh;
	copy_origin_mesh = mesh;
	copy_origin_mesh1 = mesh;
	n_vertices = origin_mesh.n_vertices();
	cout<<"vertices: "<<n_vertices<<endl;
	n_edges = origin_mesh.n_edges();
	cout<<"edges   : "<<n_edges<<endl;
	n_faces = origin_mesh.n_faces();
	cout<<"faces   : "<<n_faces<<endl;
	current_num_v = n_vertices;
	current_num_e = n_edges;
	current_num_f  = n_faces;
	origin_mesh.request_vertex_status();
	copy_origin_mesh.request_vertex_status();
	origin_mesh.request_edge_status();
	copy_origin_mesh.request_edge_status();
	origin_mesh.request_face_status();
	copy_origin_mesh.request_face_status();
	origin_mesh.request_halfedge_status();
	copy_origin_mesh.request_halfedge_status();
	origin_mesh.add_property(ecost);
	copy_origin_mesh.add_property(ecost);
	origin_mesh.add_property(vindex);
	copy_origin_mesh.add_property(vindex);
	calc_vindex(origin_mesh);
	calc_vindex(copy_origin_mesh);
	radius = ComputeSphereRadius(origin_mesh);
	first_sub = true;
	is_in_sphere = false;
	maxmum = -1e20;
	origin_mesh.add_property(QuaMat_f);
	origin_mesh.add_property(QuaMat_v);
	origin_mesh.add_property(QuaMat_e);
	origin_mesh.add_property(area_f);
	origin_mesh.add_property(new_point);
	bcd_v_optimization = new BCD_Volume_Sphere_Optimization();
	bcd_v_optimization->SetThreshhold(1e-8, 1e-8);

	origin_mesh.add_property(is_cal_e);
	origin_mesh.add_property(is_cal_he);
	for (auto e_it = origin_mesh.edges_begin(); e_it != origin_mesh.edges_end(); ++e_it)
	{
		origin_mesh.property(is_cal_e, e_it) = false;
		MyMesh::HalfedgeHandle he_it = origin_mesh.halfedge_handle(e_it, 0);
		origin_mesh.property(is_cal_he, he_it) = false;
		he_it = origin_mesh.halfedge_handle(e_it, 1);
		origin_mesh.property(is_cal_he, he_it) = false;
	}
}

HierarchicalSphereParametrization::~HierarchicalSphereParametrization(void)
{
}

vector<vector<int>> HierarchicalSphereParametrization::do_Simplify()
{
	origin_mesh.release_vertex_normals();
	int counter = 0; 
	Initial_Halfedge_Cost(origin_mesh);
	//index_collapse_v_to_v.clear();
	while(Choose_Collapased_edge(origin_mesh))
	{
		counter++;
		/*if (counter >1000)
		{
			origin_mesh.garbage_collection(true);
			break;
		}*/
		if (current_num_v == 4)
		{
			origin_mesh.garbage_collection(true);
			break;
		}
	}
	n_edges = n_faces = 0;
	for(auto it = origin_mesh.edges_begin(); it != origin_mesh.edges_end(); ++it)
	{
		n_edges++;
	}
	current_num_e = n_edges;
	for (auto it = origin_mesh.faces_begin(); it != origin_mesh.faces_end(); ++it)
	{
		n_faces++;
	}
	current_num_f = n_faces;
	cout<<"n_vertices: "<<current_num_v<<"  n_edges:  "<<current_num_e<<"  n_faces:  "<<current_num_f<<endl;
	cout<<"Simplify is over!  the iter number is:  "<<counter<<endl;
	first_sub = true;
	return index_collapse_v_to_v;
}

void HierarchicalSphereParametrization::LaplacianSmooth(MyMesh &m,int iter_num_)
{
	MyMesh::VIter     v_it, v_end(m.vertices_end());
	MyMesh::CVVIter   vv_it;
	MyMesh::Point     u, n;
	m.request_vertex_normals();
	//m.update_vertex_normals();
	for (int iter = 0; iter < iter_num_; iter++)
	{
		MyMesh::Point             centroid(0.0, 0.0, 0.0);
		/*std::vector<MyMesh::Normal> normals;
		for (v_it=m.vertices_begin(); v_it!=v_end; ++v_it)
		{
			MyMesh::Normal n = m.normal(v_it);
			normals.push_back(n);
		}*/
		int k = 0;
		for (v_it=m.vertices_begin(); v_it!=v_end; ++v_it)
		{ 
			if (!m.is_boundary(v_it))
			{
				int i = 0;
				centroid[0] = 0.0; centroid[1] = 0.0; centroid[2] = 0.0; 
				for (vv_it = m.vv_iter(v_it); vv_it; ++vv_it)
				{
					centroid += m.point(vv_it);
					i++;
				}
				centroid =  ((float)1.0/i)*centroid;
				centroid -= m.point(v_it);
				centroid *= (float)0.5;

				//centroid = normals[k]%(centroid%normals[k]);
				centroid = m.point(v_it) + centroid;
				m.set_point(v_it,centroid);
			}
			k++;
		}
	}
	m.update_normals();	
}

void HierarchicalSphereParametrization::calc_vindex(MyMesh& m)
{
	int i = 0;
	for (auto it = m.vertices_begin(); it != m.vertices_end(); ++it)
	{
		m.property(vindex,it) = i;
		i++;
	}
}

void HierarchicalSphereParametrization::calc_origin_position(MyMesh& m)
{
	for (auto it = m.vertices_begin(); it != m.vertices_end(); ++it)
	{
		m.property(origin_position,it) = m.point(it);
		o_p.push_back(m.point(it));
	}
}

bool HierarchicalSphereParametrization::Restore_Last_mesh(MyMesh &m,vector<int> &reco_info)
{
	MyMesh::VertexHandle v_l,v_r,v_n;
	MyMesh::Point p(0,0,0);
	MyMesh::VertexHandle it = m.vertex_handle(idx_to_idx_corresponding[reco_info[1]]);
	v_l = m.vertex_handle(idx_to_idx_corresponding[reco_info[2]]);
	v_r = m.vertex_handle(idx_to_idx_corresponding[reco_info[3]]);
	m.vertex_split(p,it,v_l,v_r);
	bool is_add_ok = Add_One_Point(m,m.vertex_handle(m.n_vertices()-1),it,10);
	bool is_add_ok_after_op = false;
	if (!is_add_ok)
	{
		int counter = 0;
		while (!is_add_ok_after_op)
		{
			is_add_ok_after_op = OptimizeOneRing(m, m.vertex_handle(m.n_vertices() - 1), it, 10);
			counter++;

			if (counter > 5)
			{
				break;
			}
		}
	}
	if ((!is_add_ok_after_op)&&(!is_add_ok))
	{
		cout<<"can not add vertex anymore ! current vertices:  "<<current_num_v<<endl;

		for (auto he = m.voh_iter(m.vertex_handle(m.n_vertices()-1));he;++he)
		{
			MyMesh::VertexHandle v = m.to_vertex_handle(he);
			if (v == it)
			{
				m.collapse(he);
				m.garbage_collection(true);
				break;
			}
		}
		//return false;
		bcd_v_optimization = new BCD_Volume_Sphere_Optimization();
		bcd_v_optimization->SetMesh(&m);
		bcd_v_optimization->compute_distortion();
		/*if (bcd_v_optimization->flip_count)
		{
			return false;
		}*/
		bcd_v_optimization->optimize_sphere_volume(0.1, 50);
		/*if (bcd_v_optimization->flip_count)
		{
			return false;
		}*/
		bcd_v_optimization->optimize_sphere_volume(0.1, 50);
		/*if (bcd_v_optimization->flip_count)
		{
			return false;
		}*/
		bcd_v_optimization->optimize_sphere_volume(0.1, 50);
		/*if (bcd_v_optimization->flip_count)
		{
			return false;
		}*/
		bcd_v_optimization->compute_distortion();

		m.vertex_split(p,it,v_l,v_r);
		bool is_add_ok = Add_One_Point(m,m.vertex_handle(m.n_vertices()-1),it,10);
		if (is_add_ok)
		{
			m.property(vindex,m.vertex_handle(m.n_vertices()-1)) = reco_info[0];
			return true;
		}
		for (auto he = m.voh_iter(m.vertex_handle(m.n_vertices() - 1)); he; ++he)
		{
			MyMesh::VertexHandle v = m.to_vertex_handle(he);
			if (v == it)
			{
				origin_mesh.collapse(he);
				m.garbage_collection(true);
				break;
			}
		}
		return false;
	}
	else
	{
		m.property(vindex,m.vertex_handle(m.n_vertices()-1)) = reco_info[0];
		return true;
	}
}

bool HierarchicalSphereParametrization::Add_One_Point(MyMesh &m,MyMesh::VertexHandle v_f,MyMesh::VertexHandle v_t,int c)
{
	vector<double> energy_dis_; energy_dis_.reserve(100);
	vector<MyMesh::Point> s_p; s_p.reserve(100);
	vector<MyMesh::Point> n_p_cross; n_p_cross.reserve(16);
	vector<MyMesh::Point> np1; np1.reserve(16);
	vector<MyMesh::Point> np2; np2.reserve(16);
	double vol_ = 0.0;
	nei_ps1.clear(); nei_ps1.reserve(16);
	for (auto he_it = m.voh_iter(v_f); he_it; ++he_it)
	{
		MyMesh::VertexHandle v1 = m.to_vertex_handle(he_it);
		MyMesh::Point p1 = m.point(v1);
		np1.push_back(p1);
		MyMesh::VertexHandle v2 = m.to_vertex_handle(m.next_halfedge_handle(he_it));
		MyMesh::Point p2 = m.point(v2);
		np2.push_back(p2);
		MyMesh::Point cross_p1_p2 = p1%p2;
		n_p_cross.push_back(cross_p1_p2);
		MyMesh::Point p0 = m.point(v_t);
		vol_ += p0|cross_p1_p2;
		nei_ps1.push_back(v1.idx());
	}
	vol_ /= m.valence(v_f);

	for (auto he_it = m.voh_iter(v_f); he_it; ++he_it)
	{
		  MyMesh::VertexHandle v1 = m.to_vertex_handle(he_it);
		  MyMesh::Point p1 = m.point(v1);
		  MyMesh::VertexHandle v2 = m.to_vertex_handle(m.next_halfedge_handle(he_it));
		  MyMesh::Point p2 = m.point(v2);
		  if ((v1 != v_t)&&(v2 != v_t))
		  {
			  MyMesh::Point p0 = m.point(v_t);
			  MyMesh::Point mid_p;
			  for (int i = 0; i < c ; i++)
			  {
				  for (int j = 0; j< (c-i); j++)
				  {
					  mid_p = ((double)i/c)*p1 + ((double)j/c)*p2 + ((double)(c - i - j)/c)*p0;
					  mid_p = mid_p/mid_p.norm();
					  bool sig = local_check_negative_area(mid_p,n_p_cross);
					  if (sig)
					  {
						  energy_dis_.push_back(local_isotropy_energy(mid_p,np1,np2,vol_));
						  s_p.push_back(mid_p);
					  }
				  }
			  }
		  }
	}
	if (!energy_dis_.size())
	{
//		nei_ps1 = np1;
//		nei_ps2 = np2;
		return false;
	}
	else
	{
//		ComputeBihedralAngles(m,v_f);
		int idx = min_element(energy_dis_.begin(), energy_dis_.end()) - energy_dis_.begin();
		m.set_point(v_f,s_p[idx]);
		return true;
	}
}

double HierarchicalSphereParametrization::local_isotropy_energy(MyMesh::Point &p,vector<MyMesh::Point> &np1,vector<MyMesh::Point> &np2,double vol_)
{
	double dis_nenrgy = 0.0; double aspect_ratio,vol_dis;
	for (int i = 0; i < np1.size(); i++)
	{
		double a = (np1[i] - p).norm();
		double b = (np2[i] - p).norm();
		double c = (np1[i] - np2[i]).norm();
		aspect_ratio = (a*b*c)/(a+b-c)/(a-b+c)/(-a +b+c);
		double v = p|(np1[i]%np2[i]);
		vol_dis = v/vol_ + vol_/v;
		dis_nenrgy += (aspect_ratio*vol_dis);
	}
	return dis_nenrgy;
}

bool HierarchicalSphereParametrization::local_check_negative_area(MyMesh::Point &p, vector<MyMesh::Point> &n_p)
{
	for (int i = 0 ;i < n_p.size(); i++)
	{
		if ((p|n_p[i]) < 1e-12)
		{
			return false;
		}
	}
	return true;
}

void HierarchicalSphereParametrization::QEM_Simplify(int tar_num_v, double err_threshhold)
{
	Initial_Edge_QEM_cost(origin_mesh);
	index_collapse_v_to_v.clear(); index_collapse_v_to_v.reserve(n_vertices);
	int counter = 0;
	while (Choose_Collapased_edge_qem(origin_mesh,err_threshhold))
	{
		counter++;
		/*if (counter>100)
		{
			origin_mesh.garbage_collection(true);
			break;
		}*/
		if (current_num_v < (tar_num_v+1))
		{
		   origin_mesh.garbage_collection(true);
		   break;
		}
	}
	n_edges = n_faces = 0;
	for (auto it = origin_mesh.edges_begin(); it != origin_mesh.edges_end(); ++it)
	{
		n_edges++;
	}
	current_num_e = n_edges;
	for (auto it = origin_mesh.faces_begin(); it != origin_mesh.faces_end(); ++it)
	{
		n_faces++;
	}
	current_num_f = n_faces;
	cout << "n_vertices: " << current_num_v << "  n_edges:  " << current_num_e << "  n_faces:  " << current_num_f << endl;
	cout << "Simplify is over!  the iter number is:  " << counter << endl;
}

bool HierarchicalSphereParametrization::Choose_Collapased_edge_qem(MyMesh &m, double err_threshhold)
{
	//int edge_len = 0;
	EdgeQEM currentEdge;
	bool done = false;
	int valence = 0;

	do 
	{
		done = false;
		if (qpq.size() == 0)
		{
			done = true;
			m.garbage_collection(true);
			return false;
		}
		else
		{
			currentEdge = qpq.top();
			qpq.pop();
			valence = m.valence(m.from_vertex_handle(m.halfedge_handle(currentEdge.idx, 0)));
			valence += m.valence(m.to_vertex_handle(m.halfedge_handle(currentEdge.idx, 0)));
		}
	} while ((m.status(m.edge_handle(m.halfedge_handle(currentEdge.idx, 0))).deleted()) || (m.property(QuaMat_e, currentEdge.idx) != currentEdge.qem) || (valence > 12));
	if (currentEdge.qem < err_threshhold)
	{
		MyMesh::HalfedgeHandle idx = m.halfedge_handle(currentEdge.idx,0);
		vector<int> re_in(4);
		re_in[0] = m.property(vindex, m.from_vertex_handle(idx));
		re_in[1] = m.property(vindex, m.to_vertex_handle(idx));
		re_in[2] = m.property(vindex, m.to_vertex_handle(m.next_halfedge_handle(idx)));
		re_in[3] = m.property(vindex, m.to_vertex_handle(m.next_halfedge_handle(m.opposite_halfedge_handle(idx))));
		index_collapse_v_to_v.push_back(re_in);
		OpenMesh::Vec3d& p = m.property(new_point, currentEdge.idx);
		m.set_point(m.to_vertex_handle(idx), p);
		if (p.norm() >2.0)
		{
			cout <<p << endl;
		}
		int update_p = m.to_vertex_handle(idx).idx();
		m.collapse(idx);
		Update_Edge_QEM_cost(m, update_p);
		current_num_v--;
		return true;
	}
	else
	{
		m.garbage_collection(true);
		cout << "can not collapsed anymore !   "<<"Current minimize qem is : "<<currentEdge.qem<< endl;
		return false;
	}
}

bool HierarchicalSphereParametrization::Choose_Collapased_edge(MyMesh &m)
{
	EdgeInfo currentEdge;
	bool done = false;
	do
	{
		done = false;
		if (epq.size() == 0)
		{
			done = true;
			break;
		}
		else
		{
			currentEdge = epq.top();
			epq.pop();
			//cout << m.status(m.edge_handle(currentEdge.idx)).deleted() << endl;
		}
	}
	while ((m.status(m.edge_handle(currentEdge.idx)).deleted()) || (m.property(ecost,currentEdge.idx) != currentEdge.ecost));
	
	if (currentEdge.ecost > maxmum)
	{
		MyMesh::HalfedgeHandle idx = currentEdge.idx;
		vector<int> update_v;  update_v.reserve(16);
		for (auto vv_it = m.vv_begin(m.from_vertex_handle(idx)); vv_it != m.vv_end(m.from_vertex_handle(idx)); ++vv_it)
		{
			int idx_vv_it = vv_it.handle().idx();
			update_v.push_back(idx_vv_it);
		}
		vector<int> re_in(4);
		re_in[0] = m.property(vindex,m.from_vertex_handle(idx));
		re_in[1] = m.property(vindex,m.to_vertex_handle(idx));
		re_in[2] = m.property(vindex,m.to_vertex_handle(m.next_halfedge_handle(idx)));
		re_in[3] = m.property(vindex,m.to_vertex_handle(m.next_halfedge_handle(m.opposite_halfedge_handle(idx))));
		index_collapse_v_to_v.push_back(re_in);
		m.collapse(idx);
		
//		m.garbage_collection(true);
//		MyMesh::VertexHandle v_it = m.vertex_handle(idx_v_t);
		for (int i = 0; i < update_v.size(); i++)
		{
			Update_Halfedge_Cost(m,update_v[i]);
		}
		for (int i = 0; i < update_v.size(); i++)
		{
			MyMesh::VertexHandle& v_it = m.vertex_handle(update_v[i]);
			for (auto e_it = m.voh_iter(v_it); e_it; ++e_it)
			{
				m.property(is_cal_he,e_it) = false;
			}
			for (auto e_it = m.vih_iter(v_it); e_it; ++e_it)
			{
				m.property(is_cal_he, e_it) = false;
			}
		}
		current_num_v--;
		return true;
	}
	else
	{
		m.garbage_collection(true);
		cout<<"can not collapsed anymore !"<<endl;
		return false;
	}
}

void HierarchicalSphereParametrization::Initial_Halfedge_Cost(MyMesh &m)
{
	vector<EdgeInfo> initial_e_cost(m.n_halfedges());
	EdgeInfo e;

	for (auto v_it = m.vertices_begin(); v_it != m.vertices_end(); ++v_it)
	{
		for (auto e_it = m.voh_iter(v_it); e_it ; ++e_it)
		{
			MyMesh::VertexHandle v_f = m.from_vertex_handle(e_it);
			MyMesh::VertexHandle v_t = m.to_vertex_handle(e_it);
			MyMesh::FaceHandle f1 = m.face_handle(e_it),  f2 = m.face_handle(m.opposite_halfedge_handle(e_it));
			vector<vector<MyMesh::Point>> nighbors_edge; nighbors_edge.reserve(20);
			double gauss_c = 0 , area_ = 0;
			for (auto he_it = m.voh_iter(v_f); he_it; ++he_it)
			{
				MyMesh::HalfedgeHandle h0 = m.next_halfedge_handle(he_it);
				MyMesh::HalfedgeHandle h1 = m.prev_halfedge_handle(he_it);
				MyMesh::HalfedgeHandle h2 = he_it;
				MyMesh::Point p1 = m.point(m.to_vertex_handle(h2));
				MyMesh::Point p2 = m.point(m.to_vertex_handle(h0));
				MyMesh::Point p0 = m.point(m.to_vertex_handle(h1));
				double t = ((p1 -p0)|(p2 - p0))/((p1 - p0).norm()*(p2 - p0).norm());
				double theta = acos(t);
				gauss_c += theta;
				t = ((p1 -p0)%(p2 - p0)).norm()/2.0;
				area_ += t;
				MyMesh::FaceHandle f = m.face_handle(he_it);
				if ((f != f1)&&(f != f2))
				{
					vector<MyMesh::Point> mid_e(2);
					mid_e[0] = p1;
					mid_e[1] = p2;
					nighbors_edge.push_back(mid_e);
				}
			}

			if (!m.is_collapse_ok(e_it))
			{
				m.property(ecost,e_it) = maxmum;
				e.ecost = maxmum; e.idx = e_it.handle();
				initial_e_cost[e_it.handle().idx()] = e;
			}
			else
			{
				for ( auto fv_it = m.vf_begin(v_t); fv_it != m.vf_end(v_t); ++fv_it)
				{
					if ((fv_it.handle() != f1)&&(fv_it.handle() != f2))
					{
						vector<MyMesh::Point> mid_e; mid_e.reserve(16);
						for (auto f_v = m.fv_begin(fv_it); f_v != m.fv_end(fv_it); ++f_v)
						{
							if (f_v.handle() != v_t)
							{
								MyMesh::Point p = m.point(f_v);
								mid_e.push_back(p);
							}
						}
						nighbors_edge.push_back(mid_e);
					}
				}
				double aspect_ratio = 0;
				for (int i = 0; i < nighbors_edge.size(); i++)
				{
					MyMesh::Point p = m.point(v_t);
					double a = (nighbors_edge[i][0] - p).norm();
					double b = (nighbors_edge[i][1] - p).norm();
					double c = (nighbors_edge[i][1] - nighbors_edge[i][0]).norm();
					double a_r = (a*b*c)/(a+b-c)/(a-b+c)/(-a +b+c);
					if (fabs(a_r)>100.0)
					{
						a_r = 100.0;
					}
					aspect_ratio += a_r;
				}
				int devi_valence = nighbors_edge.size() -6;
				aspect_ratio  *= std::exp((double)(devi_valence*devi_valence));
//				double c = aspect_ratio/(1.0 + fabs(2.0*3.14159 - gauss_c)/(area_/3.0));
				double c = (2.0*3.14159 - gauss_c) / (area_ / 3.0) / aspect_ratio;
				m.property(ecost,e_it) = c;
				e.ecost = c; e.idx = e_it.handle();
				initial_e_cost[e_it.handle().idx()] = e;
			}
		}
	}
	priority_queue<EdgeInfo> epq_(initial_e_cost.begin(),initial_e_cost.end());
	epq = epq_;
//	delete &epq_;
}

void HierarchicalSphereParametrization::Initial_Edge_QEM_cost(MyMesh &m)
{
	vector<EdgeQEM> initial_e_qem_cost(m.n_edges());
	EdgeQEM e;
	m.request_face_normals();
	m.update_face_normals();
	for (auto f_it = m.faces_begin(); f_it != m.faces_end(); ++f_it)
	{
		OpenMesh::Vec3d n = m.normal(f_it);
		MyMesh::FaceVertexIter fv_it = m.fv_iter(f_it);
		OpenMesh::Vec3d& p = m.point(fv_it);
		++fv_it; OpenMesh::Vec3d& p1 = m.point(fv_it);
		++fv_it; OpenMesh::Vec3d& p2 = m.point(fv_it);
		double area_ = ((p1 - p) % (p2 - p)).norm();
		m.property(area_f, f_it) = area_;

		double a = n[0]; double b = n[1]; double c = n[2]; double d = -(n | p);
		Eigen::Matrix4d mat;
		mat << a*a, a*b, a*c, a*d,
			b*a, b*b, b*c, b*d,
			c*a, c*b, c*c, c*d,
			d*a, d*b, d*c, d*d;
		m.property(QuaMat_f, f_it) = mat;
//		cout << n << endl;
	}
	m.release_face_normals();

	for (auto v_it = m.vertices_begin(); v_it != m.vertices_end(); ++v_it)
	{
		Eigen::Matrix4d mat = Eigen::Matrix4d::Zero();
		for (auto vf_it = m.vf_begin(v_it); vf_it != m.vf_end(v_it); ++vf_it)
		{
			//mat += m.property(area_f, vf_it)*m.property(QuaMat_f, vf_it);
			mat += m.property(QuaMat_f, vf_it);
		}
		m.property(QuaMat_v, v_it) = mat;
	}

	for (auto e_it = m.edges_begin(); e_it != m.edges_end(); ++e_it)
	{
		MyMesh::HalfedgeHandle he = m.halfedge_handle(e_it,0);
		MyMesh::VertexHandle  v0 = m.to_vertex_handle(he);
		MyMesh::VertexHandle  v1 = m.from_vertex_handle(he);
		Eigen::Matrix4d mat = m.property(QuaMat_v, v0) + m.property(QuaMat_v, v1);
		
		Eigen::Matrix4d mid_m = mat;  mid_m(3, 0) = mid_m(3, 1) = mid_m(3, 2) = 0.0; mid_m(3, 3) = 1.0;
		Eigen::Vector4d b(0.0,0.0,0.0,1.0);
//		Eigen::Vector4d v = mid_m.colPivHouseholderQr().solve(b);
		Eigen::Vector4d v;
		OpenMesh::Vec3d new_p;
		if (fabs(mid_m.determinant()) < 1e-4)
		{
			new_p = (m.point(v0) + m.point(v1))/2;
			if (new_p.norm() > 2.0)
			{
				cout << "mid:  " <<new_p.norm()<< endl;
			}
		}
		else
		{
			v = mid_m.colPivHouseholderQr().solve(b);
			//v = mid_m.lu().solve(b);
			new_p[0] = v(0); new_p[1] = v(1); new_p[2] = v(2);
			if (new_p.norm() > 2.0)
			{
				cout << "qr:  " << new_p.norm() << endl;
			}
		}
		m.property(new_point, e_it) = new_p;
		double err = v.transpose()*mat*v;
		/*if (err < 0)
		{
			int ustc = 1;
		}*/
		err *= (m.valence(v0) * m.valence(v1));
		if (m.is_collapse_ok(he))
		{
			m.property(QuaMat_e, e_it) = err;
			e.qem = err;
			e.idx = e_it.handle();
			initial_e_qem_cost[e_it.handle().idx()] = e;
		}
		else
		{
			m.property(QuaMat_e, e_it) = -maxmum;
			e.qem = -maxmum;
			e.idx = e_it.handle();
			initial_e_qem_cost[e_it.handle().idx()] = e;
		}
		//m.property(edge_l, e_it) = m.calc_edge_length(e_it);
	}
	priority_queue<EdgeQEM> qpq_(initial_e_qem_cost.begin(), initial_e_qem_cost.end());
	qpq = qpq_;
}

void HierarchicalSphereParametrization::Update_Edge_QEM_cost(MyMesh &m, int i)
{
	EdgeQEM e;
	MyMesh::VertexHandle v_it = m.vertex_handle(i);
	Eigen::Matrix4d q_mat = Eigen::Matrix4d::Zero();
	for (auto vf_it = m.vf_begin(v_it); vf_it != m.vf_end(v_it); ++vf_it)
	{
		MyMesh::FaceVertexIter fv_it = m.fv_iter(vf_it);
		OpenMesh::Vec3d& p = m.point(fv_it);
		++fv_it; OpenMesh::Vec3d& p1 = m.point(fv_it);
		++fv_it; OpenMesh::Vec3d& p2 = m.point(fv_it);
		double area_ = ((p1 - p) % (p2 - p)).norm();
		m.property(area_f, vf_it) = area_;

		OpenMesh::Vec3d& n = ((p1 - p) % (p2 - p)).normalize();
		double a = n[0]; double b = n[1]; double c = n[2]; double d = -(n | p);
		Eigen::Matrix4d mat;
		mat << a*a, a*b, a*c, a*d,
			b*a, b*b, b*c, b*d,
			c*a, c*b, c*c, c*d,
			d*a, d*b, d*c, d*d;
		m.property(QuaMat_f, vf_it) = mat;
		q_mat += mat;
	}
	m.property(QuaMat_v, v_it) = q_mat;

	for (auto vv_it = m.vv_begin(v_it); vv_it != m.vv_end(v_it); ++vv_it)
	{
		q_mat = Eigen::Matrix4d::Zero();
		for (auto vvf_it = m.vf_begin(vv_it); vvf_it != m.vf_end(vv_it); ++vvf_it)
		{
			//q_mat += m.property(area_f,vvf_it)*m.property(QuaMat_f, vvf_it);
			q_mat += m.property(QuaMat_f, vvf_it);
		}
		m.property(QuaMat_v, vv_it) = q_mat;
	}

	
	for (auto vv_it = m.vv_begin(v_it); vv_it != m.vv_end(v_it); ++vv_it)
	{
		for (auto e_it = m.ve_begin(vv_it); e_it != m.ve_end(vv_it); ++e_it)
		{
			if (!m.property(is_cal_e,e_it))
			{
				MyMesh::HalfedgeHandle he = m.halfedge_handle(e_it, 0);
				MyMesh::VertexHandle  v0 = m.to_vertex_handle(he);
				MyMesh::VertexHandle  v1 = m.from_vertex_handle(he);
				Eigen::Matrix4d mat = m.property(QuaMat_v, v0) + m.property(QuaMat_v, v1);
				Eigen::Matrix4d mid_m = mat;  mid_m(3, 0) = mid_m(3, 1) = mid_m(3, 2) = 0.0; mid_m(3, 3) = 1.0;
				Eigen::Vector4d b(0.0, 0.0, 0.0, 1.0);
				//Eigen::Vector4d v = mid_m.colPivHouseholderQr().solve(b);
				//OpenMesh::Vec3d new_p(v(0), v(1), v(2));
				Eigen::Vector4d v;
				OpenMesh::Vec3d new_p;
				if (fabs(mid_m.determinant()) < 1e-4)
				{
					//cout << mid_m.determinant()<< endl;
					new_p = (m.point(v0) + m.point(v1)) / 2;
				}
				else
				{
					//v = mid_m.lu().solve(b);
					v = mid_m.colPivHouseholderQr().solve(b);
					new_p[0] = v(0); new_p[1] = v(1); new_p[2] = v(2);
				}
				m.property(new_point, e_it) = new_p;
				double err = v.transpose()*mat*v;
				err *= (m.valence(v0) * m.valence(v1));
				if (m.is_collapse_ok(he) && m.is_collapse_ok(m.opposite_halfedge_handle(he)))
				{

					m.property(QuaMat_e, e_it) = err;
					e.qem = err;
					e.idx = e_it.handle();
					qpq.push(e);
					//cout <<m.from_vertex_handle(he).idx() <<"  "<<m.to_vertex_handle(he).idx()<< endl;
				}
				else
				{
					m.property(QuaMat_e, e_it) = -maxmum;
				}
				//m.property(edge_l, e_it) = m.calc_edge_length(e_it);
				m.property(is_cal_e, e_it) = true;
			}
		}
	}
	for (auto vv_it = m.vv_begin(v_it); vv_it != m.vv_end(v_it); ++vv_it)
	{
		for (auto e_it = m.ve_begin(vv_it); e_it != m.ve_end(vv_it); ++e_it)
		{
			m.property(is_cal_e, e_it) = false;
		}
	}
}

void HierarchicalSphereParametrization::Update_Halfedge_Cost(MyMesh &m,int i)
{
	EdgeInfo e;
	MyMesh::VertexHandle v_it = m.vertex_handle(i);
	for (auto e_it = m.voh_iter(v_it); e_it; ++e_it)
	{
		if (!m.property(is_cal_he,e_it))
		{
			//cout << m.property(is_cal_he, e_it) << endl;
			if (!m.is_collapse_ok(e_it))
			{
				m.property(ecost, e_it) = maxmum;
				//			e.idx = e_it.handle(); e.ecost = maxmum;
				//			epq.push(e);
			}
			else
			{
				MyMesh::VertexHandle v_f = m.from_vertex_handle(e_it);
				MyMesh::VertexHandle v_t = m.to_vertex_handle(e_it);
				MyMesh::FaceHandle f1 = m.face_handle(e_it), f2 = m.face_handle(m.opposite_halfedge_handle(e_it));
				vector<vector<MyMesh::Point>> nighbors_edge; nighbors_edge.reserve(20);
				double gauss_c = 0, area_ = 0;
				for (auto he_it = m.voh_iter(v_f); he_it; ++he_it)
				{
					MyMesh::HalfedgeHandle h0 = m.next_halfedge_handle(he_it);
					MyMesh::HalfedgeHandle h1 = m.prev_halfedge_handle(he_it);
					MyMesh::HalfedgeHandle h2 = he_it;
					MyMesh::Point p1 = m.point(m.to_vertex_handle(h2));
					MyMesh::Point p2 = m.point(m.to_vertex_handle(h0));
					MyMesh::Point p0 = m.point(m.to_vertex_handle(h1));
					double t = ((p1 - p0) | (p2 - p0)) / ((p1 - p0).norm()*(p2 - p0).norm());
					double theta = acos(t);
					if (t < -0.9999)
					{
						theta = 3.14159;
					}
					if (t > 0.9999)
					{
						theta = 0.0;
					}
					gauss_c += theta;
					t = ((p1 - p0) % (p2 - p0)).norm() / 2.0;
					area_ += t;
					MyMesh::FaceHandle f = m.face_handle(he_it);
					if ((f != f1) && (f != f2))
					{
						vector<MyMesh::Point> mid_e(2);
						mid_e[0] = p1;
						mid_e[1] = p2;
						nighbors_edge.push_back(mid_e);
					}
				}

				for (auto fv_it = m.vf_begin(v_t); fv_it != m.vf_end(v_t); ++fv_it)
				{
					if ((fv_it.handle() != f1) && (fv_it.handle() != f2))
					{
						vector<MyMesh::Point> mid_e; mid_e.reserve(16);
						for (auto f_v = m.fv_begin(fv_it); f_v != m.fv_end(fv_it); ++f_v)
						{
							if (f_v.handle() != v_t)
							{
								MyMesh::Point p = m.point(f_v);
								mid_e.push_back(p);
							}
						}
						nighbors_edge.push_back(mid_e);
					}
				}
				double aspect_ratio = 0;
				for (int i = 0; i < nighbors_edge.size(); i++)
				{
					MyMesh::Point p = m.point(v_t);
					double a = (nighbors_edge[i][0] - p).norm();
					double b = (nighbors_edge[i][1] - p).norm();
					double c = (nighbors_edge[i][1] - nighbors_edge[i][0]).norm();
					double a_r = (a*b*c) / (a + b - c) / (a - b + c) / (-a + b + c);
					if (fabs(a_r) > 100.0)
					{
						a_r = 100.0;
					}
					aspect_ratio += a_r;
				}
				//		aspect_ratio *= nighbors_edge.size();
				int devi_valence = nighbors_edge.size() - 6;
				aspect_ratio *= std::exp((double)(devi_valence*devi_valence));
				//		 aspect_ratio  *= std::exp((double)nighbors_edge.size());
				if (area_ < 0.00001)
				{
					area_ = 0.00001;
				}
				//				double c = aspect_ratio/(1.0 + fabs(2.0*3.14159 - gauss_c)/(area_/3.0));
				double c = (2.0*3.14159 - gauss_c) / (area_ / 3.0) / aspect_ratio;
				m.property(ecost, e_it) = c;
				e.ecost = c; e.idx = e_it.handle();
				epq.push(e);
			}
			m.property(is_cal_he, e_it) = true;
		}
	}

	for (auto e_it = m.vih_iter(v_it); e_it; ++e_it)
	{
		if (!m.property(is_cal_he, e_it))
		{
			//cout << m.property(is_cal_he, e_it) << endl;
			if (!m.is_collapse_ok(e_it))
			{
				m.property(ecost, e_it) = maxmum;
			}
			else
			{
				MyMesh::VertexHandle v_f = m.from_vertex_handle(e_it);
				MyMesh::VertexHandle v_t = m.to_vertex_handle(e_it);
				MyMesh::FaceHandle f1 = m.face_handle(e_it), f2 = m.face_handle(m.opposite_halfedge_handle(e_it));
				vector<vector<MyMesh::Point>> nighbors_edge; nighbors_edge.reserve(20);
				double gauss_c = 0, area_ = 0;
				for (auto he_it = m.voh_iter(v_f); he_it; ++he_it)
				{
					MyMesh::HalfedgeHandle h0 = m.next_halfedge_handle(he_it);
					MyMesh::HalfedgeHandle h1 = m.prev_halfedge_handle(he_it);
					MyMesh::HalfedgeHandle h2 = he_it;
					MyMesh::Point p1 = m.point(m.to_vertex_handle(h2));
					MyMesh::Point p2 = m.point(m.to_vertex_handle(h0));
					MyMesh::Point p0 = m.point(m.to_vertex_handle(h1));
					double t = ((p1 - p0) | (p2 - p0)) / ((p1 - p0).norm()*(p2 - p0).norm());
					double theta = acos(t);
					if (t < -0.9999)
					{
						theta = 3.14159;
					}
					if (t > 0.9999)
					{
						theta = 0.0;
					}
					gauss_c += theta;
					t = ((p1 - p0) % (p2 - p0)).norm() / 2.0;
					area_ += t;
					MyMesh::FaceHandle f = m.face_handle(he_it);
					if ((f != f1) && (f != f2))
					{
						vector<MyMesh::Point> mid_e(2);
						mid_e[0] = p1;
						mid_e[1] = p2;
						nighbors_edge.push_back(mid_e);
					}
				}

				for (auto fv_it = m.vf_begin(v_t); fv_it != m.vf_end(v_t); ++fv_it)
				{
					if ((fv_it.handle() != f1) && (fv_it.handle() != f2))
					{
						vector<MyMesh::Point> mid_e; mid_e.reserve(16);
						for (auto f_v = m.fv_begin(fv_it); f_v != m.fv_end(fv_it); ++f_v)
						{
							if (f_v.handle() != v_t)
							{
								MyMesh::Point p = m.point(f_v);
								mid_e.push_back(p);
							}
						}
						nighbors_edge.push_back(mid_e);
					}
				}
				double aspect_ratio = 0;
				for (int i = 0; i < nighbors_edge.size(); i++)
				{
					MyMesh::Point p = m.point(v_t);
					double a = (nighbors_edge[i][0] - p).norm();
					double b = (nighbors_edge[i][1] - p).norm();
					double c = (nighbors_edge[i][1] - nighbors_edge[i][0]).norm();
					double a_r = (a*b*c) / (a + b - c) / (a - b + c) / (-a + b + c);
					if (fabs(a_r) > 100.0)
					{
						a_r = 100.0;
					}
					aspect_ratio += a_r;
				}
				if (area_ < 0.00001)
				{
					area_ = 0.00001;
				}
				int devi_valence = nighbors_edge.size() - 6;
				aspect_ratio *= std::exp((double)(devi_valence*devi_valence));
				//		 aspect_ratio  *= std::exp((double)nighbors_edge.size());
				//				double c = aspect_ratio/(1.0 + fabs(2.0*3.14159 - gauss_c)/(area_/3.0));
				double c = (2.0*3.14159 - gauss_c) / (area_ / 3.0) / aspect_ratio;
				m.property(ecost, e_it) = c;
				e.ecost = c; e.idx = e_it.handle();
				epq.push(e);
			}
			m.property(is_cal_he, e_it) = true;
		}
	}
}

double HierarchicalSphereParametrization::ComputeSphereRadius(MyMesh &m)
{
	double s = 0.0;
	for (auto f_it = m.faces_begin(); f_it != m.faces_end(); ++f_it)
	{
		vector<MyMesh::Point> vs;
		for (auto fv_it = m.fv_begin(f_it); fv_it != m.fv_end(f_it); ++fv_it)
		{
			vs.push_back(m.point(fv_it));
		}
		assert(vs.size() == 3 && "The mesh isn't triangular mesh!");

		s = s + 0.5*((vs[0] - vs[1])%(vs[0] - vs[2])).norm();
	}
	return sqrt(s/(4.0*3.14159));
}

void HierarchicalSphereParametrization::Subdivision(int num_optimization_,vector<vector<int>> &idx_v_to_v)
{
	if ((origin_mesh.n_vertices() != 4)&&(!is_in_sphere))
	{
		cout<<" not a tetrahedron !"<<endl;
	}
	else
	{
		if (origin_mesh.n_vertices() == 4)
		{
			Compute_idx_to_idx_corresponding(origin_mesh);
			is_in_sphere = true;
			MyMesh::Point p0(1.0,0.0,0.0);
			MyMesh::Point p1(0.0,1.0,0.0);
			MyMesh::Point p2(0.0,0.0,1.0);
			MyMesh::Point p3(-1.0/sqrt(3.0),-1.0/sqrt(3.0),-1.0/sqrt(3.0));
			origin_mesh.set_point(origin_mesh.vertex_handle(0),p0);
			origin_mesh.set_point(origin_mesh.vertex_handle(1),p1);
			origin_mesh.set_point(origin_mesh.vertex_handle(2),p2);
			origin_mesh.set_point(origin_mesh.vertex_handle(3),p3);
			vector<MyMesh::Point> vf0;
			vector<int> idx_vf0;
			for (auto v_f = origin_mesh.fv_begin(origin_mesh.face_handle(0)); v_f != origin_mesh.fv_end(origin_mesh.face_handle(0)); ++v_f)
			{
				vf0.push_back(origin_mesh.point(v_f));
				idx_vf0.push_back(v_f.handle().idx());
			}
			if ((idx_vf0[0]!=0)&&(idx_vf0[1]!=0)&&(idx_vf0[2]!=0))
			{
				MyMesh::Point mid_p0 = origin_mesh.point(origin_mesh.vertex_handle(0)) - vf0[0];
				MyMesh::Point mid_p1 = vf0[1] - vf0[0];
				MyMesh::Point mid_p2 = vf0[2] - vf0[1];
				if ((double)((mid_p1%mid_p2)|mid_p0) > 1e-10)
				{
					origin_mesh.set_point(origin_mesh.vertex_handle(0),-p0);
					origin_mesh.set_point(origin_mesh.vertex_handle(1),-p1);
					origin_mesh.set_point(origin_mesh.vertex_handle(2),-p2);
					origin_mesh.set_point(origin_mesh.vertex_handle(3),-p3);
				}
			}
			else if ((idx_vf0[0]!=1)&&(idx_vf0[1]!=1)&&(idx_vf0[2]!=1))
			{
				MyMesh::Point mid_p0 = origin_mesh.point(origin_mesh.vertex_handle(1)) - vf0[0];
				MyMesh::Point mid_p1 = vf0[1] - vf0[0];
				MyMesh::Point mid_p2 = vf0[2] - vf0[1];
				if ((double)((mid_p1%mid_p2)|mid_p0) > 1e-10)
				{
					origin_mesh.set_point(origin_mesh.vertex_handle(0),-p0);
					origin_mesh.set_point(origin_mesh.vertex_handle(1),-p1);
					origin_mesh.set_point(origin_mesh.vertex_handle(2),-p2);
					origin_mesh.set_point(origin_mesh.vertex_handle(3),-p3);
				}
			}
			else if ((idx_vf0[0]!=2)&&(idx_vf0[1]!=2)&&(idx_vf0[2]!=2))
			{
				MyMesh::Point mid_p0 = origin_mesh.point(origin_mesh.vertex_handle(2)) - vf0[0];
				MyMesh::Point mid_p1 = vf0[1] - vf0[0];
				MyMesh::Point mid_p2 = vf0[2] - vf0[1];
				if ((double)((mid_p1%mid_p2)|mid_p0) > 1e-10)
				{
					origin_mesh.set_point(origin_mesh.vertex_handle(0),-p0);
					origin_mesh.set_point(origin_mesh.vertex_handle(1),-p1);
					origin_mesh.set_point(origin_mesh.vertex_handle(2),-p2);
					origin_mesh.set_point(origin_mesh.vertex_handle(3),-p3);
				}
			}
			else if ((idx_vf0[0]!=3)&&(idx_vf0[1]!=3)&&(idx_vf0[2]!=3))
			{
				MyMesh::Point mid_p0 = origin_mesh.point(origin_mesh.vertex_handle(3)) - vf0[0];
				MyMesh::Point mid_p1 = vf0[1] - vf0[0];
				MyMesh::Point mid_p2 = vf0[2] - vf0[1];
				if ((double)((mid_p1%mid_p2)|mid_p0) > 1e-10)
				{
					origin_mesh.set_point(origin_mesh.vertex_handle(0),-p0);
					origin_mesh.set_point(origin_mesh.vertex_handle(1),-p1);
					origin_mesh.set_point(origin_mesh.vertex_handle(2),-p2);
					origin_mesh.set_point(origin_mesh.vertex_handle(3),-p3);
				}
			}
		}
		global_max_energy = 5.0;
		int counter = 0;
		int current_iter = 0;
		int opt_mun = 0; double s = 0.1;
		while(current_num_v < n_vertices)
		{
			if (!idx_v_to_v.size())
			{
				break;
			}
			bool is_restored = Restore_Last_mesh(origin_mesh,idx_v_to_v.back());
			idx_v_to_v.pop_back();
			counter++;
			current_num_v++;
			if (!is_restored)
			{
				cout<<"restore faild !"<<endl;
				break;
			}
			current_iter++;
			if (counter < 10 && counter > 3)
			{
				//bcd_v_optimization = new BCD_Volume_Sphere_Optimization();
				//bcd_v_optimization->SetThreshhold(1e-8, 1e-8);
				bcd_v_optimization->SetMesh(&origin_mesh);
				bcd_v_optimization->optimize_sphere_volume(s, 10);
				//delete  bcd_v_optimization;
				//bcd_v_optimization = NULL;
			}

			//bcd_v_optimization = new BCD_Volume_Sphere_Optimization();
			//bcd_v_optimization->SetThreshhold(1e-8, 1e-8);
			bcd_v_optimization->SetMesh(&origin_mesh);
			MyMesh::VertexHandle v = origin_mesh.vertex_handle(origin_mesh.n_vertices() - 1);
			double max_iso_d = bcd_v_optimization->max_iso_local_distortion(v, 1.0);
			//if ((max_iso_d > std::min((10.0*global_max_energy), 40.0)) || (current_iter > 100))
			if (max_iso_d > 50)
			{
				bcd_v_optimization->optimize_sphere_volume(s, num_optimization_);
				//bcd_v_optimization->optimize_sphere_volume(s, 20);
				global_max_energy = bcd_v_optimization->max_iso_distortion();
				int iter_count = 0;
				if (global_max_energy > 40)
				{
					while (global_max_energy > 40 && iter_count < 3)
					{
						++iter_count;
						bcd_v_optimization->optimize_sphere_volume(s, 20);
						global_max_energy = bcd_v_optimization->max_iso_distortion();
					}
				}
				/*int iter_count = 0;
				if (global_max_energy > 40)
				{
					while (global_max_energy > 40 && iter_count < 3)
					{
						s *= 0.15; ++iter_count;
						bcd_v_optimization->optimize_sphere_volume(s, 50);
						global_max_energy = bcd_v_optimization->max_iso_distortion();
					}
				}
				else if (global_max_energy < 20)
				{
					s = 0.1;
				}*/
				//delete  bcd_v_optimization;
				//bcd_v_optimization = NULL;
				record_max_dis.push_back(global_max_energy);
				recore_add_v_nun.push_back(current_iter);
				current_iter = 0;
				opt_mun++;
			}
			//break;
			if (current_num_v%1000 == 0)
			{
				cout << "current_num_v: "<<current_num_v<< endl;
			}
		}
		cout<<"opt num: "<<opt_mun<<endl;
		if (current_num_v == n_vertices)
		{
			nei_ps1.clear();
			cout<<"subdivision success !"<<endl;
			//bcd_v_optimization = new BCD_Volume_Sphere_Optimization();
			//bcd_v_optimization->SetThreshhold(1e-8, 1e-8);
			bcd_v_optimization->SetMesh(&origin_mesh);
			bcd_v_optimization->optimize_sphere_volume(s, 200);
			bcd_v_optimization->compute_distortion();
			//delete  bcd_v_optimization;
			//bcd_v_optimization = NULL;
			bool is_overlap = bcd_v_optimization->checklap(&origin_mesh, 1e-12);
			if (is_overlap)
			{
				cout << "the result have overlap" << endl;
			}
			else
			{
				cout << "the result do not have overlap" << endl;
			}
		
			for (auto it = origin_mesh.vertices_begin(); it != origin_mesh.vertices_end(); ++it)
			{
				int i = origin_mesh.property(vindex,it);
				MyMesh::Point p = origin_mesh.point(it); 
				copy_origin_mesh.set_point(copy_origin_mesh.vertex_handle(i),p);
			}
			origin_mesh = copy_origin_mesh;

		}
	}
	//delete  bcd_v_optimization;
	//bcd_v_optimization = NULL;
	return;
}

void HierarchicalSphereParametrization::Compute_idx_to_idx_corresponding(MyMesh &m)
{
	idx_to_idx_corresponding.resize(n_vertices);
	int nv = m.n_vertices();
	int c = index_collapse_v_to_v.size();
	for (auto v_it = m.vertices_begin(); v_it != m.vertices_end(); ++v_it)
	{
		idx_to_idx_corresponding[m.property(vindex,v_it)] = v_it.handle().idx();
	}
	for (int i = 0; i < c; i++)
	{
		idx_to_idx_corresponding[index_collapse_v_to_v[c-1-i][0]] = nv + i;
	}
}

MyMesh::VertexHandle HierarchicalSphereParametrization::ComputeBihedralAngles(MyMesh &m,MyMesh::VertexHandle &idx)
{
	MyMesh::VertexHandle v_it;
	double da = -5.0;
	for (auto e_it = m.voh_iter(idx); e_it ; ++e_it)
	{
		double mid = m.calc_dihedral_angle(e_it);
		if (da < mid)
		{
			v_it = m.to_vertex_handle(e_it);
			da = mid;
		}
	}
	return v_it;
}

bool HierarchicalSphereParametrization::OptimizeOneRing(MyMesh &m,MyMesh::VertexHandle &idx,MyMesh::VertexHandle v_t,int c)
{
	MyMesh::VertexHandle v_id = ComputeBihedralAngles(m,idx);
//	vector<vector<MyMesh::Point>> nei_in_sphere;
//	vector<MyMesh::Point> mid(2);
	vector<MyMesh::Point> nei_eh_in_sphere; nei_eh_in_sphere.reserve(16);
	vector<MyMesh::Point> n_p_cross; n_p_cross.reserve(16);
	vector<MyMesh::Point> centroid_of_t; centroid_of_t.reserve(16);
	MyMesh::Point p0 = m.point(v_id);
	for (auto he_it = m.voh_iter(v_id); he_it; ++he_it)
	{
		MyMesh::VertexHandle v1 = m.to_vertex_handle(he_it);
		
		MyMesh::VertexHandle v2 = m.to_vertex_handle(m.next_halfedge_handle(he_it));
		
		if ((v1 != idx)&&(v2 != idx))
		{
			MyMesh::Point p1 = m.point(v1);
			MyMesh::Point p2 = m.point(v2);
			MyMesh::Point c = (p1 + p2 + p0)/3.0;
			c  = c/c.norm();
			centroid_of_t.push_back(c);
			MyMesh::Point cross_p1_p2 = p1%p2;
			n_p_cross.push_back(cross_p1_p2);
			nei_eh_in_sphere.push_back((p0+p1)/(p0+p1).norm());
//			mid[0] = p1;
//			mid[1] = p2;
//			nei_in_sphere.push_back(mid);
		}
	}
	bool is_update = false;
	for (int i = 0; i < centroid_of_t.size(); i++)
	{
		 bool sig = local_check_negative_area(centroid_of_t[i],n_p_cross);
		 if (sig)
		 {
			 is_update = true;
			 m.set_point(v_id,centroid_of_t[i]);
			 bool is_add_ok = Add_One_Point(m,idx,v_t,c);
			 if (is_add_ok)
			 {
				 return true;
			 }
		 }
	}
	if (!is_update)
	{
		for (int i = 0; i< nei_eh_in_sphere.size(); i++)
		{
			bool sig = local_check_negative_area(nei_eh_in_sphere[i],n_p_cross);
			if (sig)
			{
				m.set_point(v_id,nei_eh_in_sphere[i]);
				bool is_add_ok = Add_One_Point(m,idx,v_t,c);
				if (is_add_ok)
				{
					return true;
				}
			}
		}
	}
	return false;
}

void HierarchicalSphereParametrization::PrintInfo(string fileName)
{
	FILE *out;
	string str_1 = ".txt";
	string fn = fileName + str_1;
	if((out = fopen(fn.c_str(),"wt+")) == NULL)
	{
		return;
	}

	fprintf(out,"add_v_nun      max_dis\n");
	
	fprintf(out,"\n");

	for(int i = 0; i< recore_add_v_nun.size(); i++)
	{
		fprintf(out," %d        %e\n",recore_add_v_nun[i],record_max_dis[i]);
	}
	fclose(out);
}

void HierarchicalSphereParametrization::RefineModel(MyMesh &m, double thresh_hold, double r)
{
	double min_ratio = 2;
	double l = 0.0;
	double ra = r*r;
	for (auto e_it = m.edges_begin(); e_it != m.edges_end(); ++e_it)
	{
		l = 0.25*m.calc_edge_sqr_length(e_it);
		l = std::sqrt(ra - l);
		if (min_ratio > l/r)
		{
			min_ratio = l / r;
		}
	}
	
	int iter = 0;
	MyMesh::EIter     e_it, e_end;
	while (min_ratio < thresh_hold)
	{
		//for (auto e_it = m.edges_begin(); e_it != m.edges_end(); ++e_it)
		for (e_it = m.edges_begin(),e_end = m.edges_end(); e_it != e_end; ++e_it)
		{
			l = 0.25*m.calc_edge_sqr_length(e_it);
			l = std::sqrt(ra - l);
			if (l / r < thresh_hold)
			{
				MyMesh::HalfedgeHandle he = m.halfedge_handle(e_it, 0);
				MyMesh::Point p = (m.point(m.to_vertex_handle(he)) + m.point(m.from_vertex_handle(he)))/2.0;
				p = r*p / p.norm();
				int idx_e = e_it.handle().idx();
				int idx_v1 = (m.to_vertex_handle(he)).idx();
				int idx_v2 = (m.to_vertex_handle(m.opposite_halfedge_handle(he))).idx();
				//cout << idx_v1 << " " << idx_v2 << " " << copy_origin_mesh1.to_vertex_handle(copy_origin_mesh1.halfedge_handle(copy_origin_mesh1.edge_handle(idx_e), 0)).idx() << " " << copy_origin_mesh1.to_vertex_handle(copy_origin_mesh1.halfedge_handle(copy_origin_mesh1.edge_handle(idx_e), 1)).idx() << endl;
				MyMesh::Point o_p = 0.5*(copy_origin_mesh1.point(copy_origin_mesh1.vertex_handle(idx_v1)) + copy_origin_mesh1.point(copy_origin_mesh1.vertex_handle(idx_v2)));
				m.split(e_it.handle(), p);
				copy_origin_mesh1.split(copy_origin_mesh1.edge_handle(idx_e), o_p);
			}
		}
		iter++;
		cout << iter << endl;
		bcd_optimization = new BCD_Sphere_Optimization(&m,&copy_origin_mesh1, r);
		bcd_optimization->prepare_parameterization();
		bcd_optimization->do_parallel_EXP_parameterizing(1.0, 0.5, 100);
		delete  bcd_optimization;
		bcd_optimization = NULL;
		
		min_ratio = 2;
		//for (auto e_it = m.edges_begin(); e_it != m.edges_end(); ++e_it)
		for (e_it = m.edges_begin(), e_end = m.edges_end(); e_it != e_end; ++e_it)
		{
			l = 0.25*m.calc_edge_sqr_length(e_it);
			l = std::sqrt(ra - l);
			if (min_ratio > l / r)
			{
				min_ratio = l / r;
			}
		}
	}
}