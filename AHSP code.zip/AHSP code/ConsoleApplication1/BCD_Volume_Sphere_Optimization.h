#ifndef BCD_Volume_Sphere_Optimization_H
#define BCD_Volume_Sphere_Optimization_H

#include "graph_coloring.h"
#include "Eigen/Dense"
#include <omp.h>

class BCD_Volume_Sphere_Optimization
{
public:
	BCD_Volume_Sphere_Optimization();
	~BCD_Volume_Sphere_Optimization();

	void SetMesh(MyMesh* mesh)
	{
		reset_all_State();
		mesh_ = mesh;
	}
	void reset_all_State();
	void prepare_data();
	void optimize_sphere_volume(double ep, int max_iter);
	void compute_distortion();
	double max_iso_distortion();
	double max_iso_local_distortion(MyMesh::VertexHandle &v,double r);
	bool checklap(MyMesh* mesh_, double threh);
	void SetThreshhold(double min_l, double min_v)
	{
		m_l = min_l;
		m_v = min_v;
	}

private:
	MyMesh* mesh_;
	bool prepare_OK;

	double C00, C01, C02, C10, C11, C12, C20, C21, C22; Eigen::Matrix3d SI;
	double energy_power; double high_d; double radius;
	std::vector<std::vector<int>> v_same_color;
	std::vector<std::vector<int>> v_fv_id;
	std::vector<OpenMesh::Vec3d> v_pos;
	std::vector<double> vertex_radius_ratio;
	
	void optimize_sphere_volume_one_V(int v_id, int omp_id);
	bool locally_check_negative_volume(MyMesh::VertexHandle& vh, OpenMesh::Vec3d& np);
	bool locally_check_negative_volume(OpenMesh::Vec3d& np, int size_vfv, std::vector<int>& one_v_fv_id);
	double compute_local_exp_mips_energy(MyMesh::VertexHandle& vh, OpenMesh::Vec3d& np);
	double compute_local_exp_mips_energy(OpenMesh::Vec3d& np, int size_vfv, std::vector<int>& one_v_fv_id);

	double m_l, m_v;
	double local_mips_energy;
	fmath::PowGenerator *f;
	bool is_current_max_iso;

public:
	double max_cd; double min_cd; double avg_cd;
	double max_iso; double min_iso; double avg_iso;
	double max_vol; double min_vol; double avg_vol;
	int flip_count;
};

#endif