#include "Parametrization.h"


Parametrization::Parametrization(void)
{
}


Parametrization::~Parametrization(void)
{
}

MyMesh Parametrization::Parame()
{
	MyMesh para_mesh_;
	return para_mesh_;
}