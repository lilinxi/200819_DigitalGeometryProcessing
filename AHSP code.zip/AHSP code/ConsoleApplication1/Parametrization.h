//#pragma once
#ifndef PARAMETRIZATION_H
#define PARAMETRIZATION_H
//#ifdef _MSC_VER // MP-
# define _USE_MATH_DEFINES
//#endif // MP-
#include <math.h>
#include <algorithm>
#include "Eigen/Sparse"
#include "Eigen/Dense"
#include "Eigen/SVD"
#include "Eigen/StdVector"
//#include <Eigen/Eigen>
#include <vector>
#include <iostream>
#include <fstream>
#include <time.h>
#include "fmath.hpp"
#include "mesh_definition.h"

typedef Eigen::SparseMatrix<float> SpMat;
typedef Eigen::Triplet<double> T;

using namespace std;
using namespace Eigen;

class Parametrization
{
public:
	Parametrization(void);
	virtual ~Parametrization(void);

public:
	virtual MyMesh Parame();
};

#endif