#pragma once
#include "Parametrization.h"
#include "graph_coloring.h"
#include <omp.h>

class BCD_Sphere_Optimization
{
public:
	BCD_Sphere_Optimization(void);
	BCD_Sphere_Optimization(MyMesh *m, MyMesh *m1, double radius_);
	BCD_Sphere_Optimization(MyMesh* m, double radius_);
	BCD_Sphere_Optimization(MyMesh* m, double radius_, OpenMesh::VPropHandleT<MyMesh::Point> &origin_position);
	~BCD_Sphere_Optimization(void);

public:
	void prepare_parameterization();
	void prepare_parameterization(MyMesh* mesh_);
	void origin_prepare_parameterization(MyMesh* mesh_, OpenMesh::VPropHandleT<MyMesh::Point> &origin_position_);
	void do_parameterizing(double energy_power, double angle_area_ratio, int iter);
	void do_EXP_parameterizing(double energy_power, double angle_area_ratio, int iter);
	void do_parallel_EXP_parameterizing(double energy_power, double angle_area_ratio, int iter);
	void do_Refine_EXP_parameterizing(double energy_power, double angle_area_ratio, int iter);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  mips + area
	void MIPS_AREA_Reposition(MyMesh* mesh_, double step_length, double angle_area_ratio);
	void EXP_MIPS_AREA_Reposition(MyMesh* mesh_, double step_length, double energy_power, double angle_area_ratio);
	bool local_check_negative_area_SUV(const int& vv_size, const double& npx, const double& npy, const double& npz,
		const std::vector<double>& p1_p2_cross_x, const std::vector<double>& p1_p2_cross_y, const std::vector<double>& p1_p2_cross_z);
	void EXP_MIPS_AREA_Reposition_one_V(int i, double step_length, double energy_power, double angle_area_ratio,
		std::vector<double>& l0_n_vec,
		std::vector<double>& p1_vec_x, std::vector<double>& p1_vec_y, std::vector<double>& p1_vec_z,
		std::vector<double>& p2_vec_x, std::vector<double>& p2_vec_y, std::vector<double>& p2_vec_z,
		std::vector<double>& p1_p2_cross_x, std::vector<double>& p1_p2_cross_y, std::vector<double>& p1_p2_cross_z);

	void MIPS_AREA_Reposition_one_V(int i, double step_length, double angle_area_ratio,
		std::vector<double>& l0_n_vec,
		std::vector<double>& p1_vec_x, std::vector<double>& p1_vec_y, std::vector<double>& p1_vec_z,
		std::vector<double>& p2_vec_x, std::vector<double>& p2_vec_y, std::vector<double>& p2_vec_z,
		std::vector<double>& p1_p2_cross_x, std::vector<double>& p1_p2_cross_y, std::vector<double>& p1_p2_cross_z);

	bool compute_local_MIPS_AREA_energy(double& new_e, const double& old_e, const int& vv_size,
		const double& npx, const double& npy, const double& npz,
		const double& beta, const double& alpha,
		const std::vector<double>& fh_area_vec, const std::vector<double>& inv_fh_area_vec,
		const std::vector<double>& l0_n_vec,
		const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
		const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
		const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec);
	bool compute_local_EXP_MIPS_AREA_energy(double& new_e, const double& old_e, const int& vv_size, const double& npx, const double& npy, const double& npz,
		const double& beta, const double& alpha,
		const std::vector<double>& fh_area_vec, const std::vector<double>& inv_fh_area_vec,
		const std::vector<double>& l0_n_vec,
		const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
		const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
		const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec);

	void PrintObj(string fileName, MyMesh *m);
	double ComputeAngle(Eigen::Vector3d v1, Eigen::Vector3d v2);
	void save_graph(const char* filename);
	void load_vertex_color(const char* filename);
	void scale_by_isometric();
	void ComputeOriginTrangleArea();
	bool compute_local_ISOMETRIC_energy(double& new_e, const double& old_e, const int& vv_size,
		const double& npx, const double& npy, const double& npz,
		const double& beta, const double& alpha,
		const std::vector<double>& fh_area_vec, const std::vector<double>& inv_fh_area_vec,
		const std::vector<double>& l0_n_vec,
		const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
		const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
		const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec);
	bool compute_local_MIPS_energy(double& new_e, const double& old_e, const int& vv_size,
		const double& npx, const double& npy, const double& npz,
		const double& beta, const double& alpha,
		const std::vector<double>& fh_area_vec, const std::vector<double>& inv_fh_area_vec,
		const std::vector<double>& l0_n_vec,
		const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
		const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
		const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec);  // conformal energy 
	double ComputeNewRadius();
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	bool checklap(MyMesh* mesh_, double threh);
	//	void CalculateFlatten_x();
	//	void CalculateFlatten_u();
	//	void DistortionCompute();
	//	void ComputeColorMap();
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// mips + vol
	void MIPS_VOL_Reposition(MyMesh* mesh_, double step_length, double angle_area_ratio);
	bool compute_local_MIPS_VOL_energy(double& new_e, const double& old_e, const int& vv_size,
		const double& npx, const double& npy, const double& npz,
		const double& beta, const double& alpha,
		const std::vector<double>& fh_vol_vec, const std::vector<double>& inv_fh_vol_vec,
		const std::vector<double>& l0_n_vec,
		const std::vector<double>& p1_vec_x, const std::vector<double>& p1_vec_y, const std::vector<double>& p1_vec_z,
		const std::vector<double>& p2_vec_x, const std::vector<double>& p2_vec_y, const std::vector<double>& p2_vec_z,
		const std::vector<double>& omega1_vec, const std::vector<double>& omega2_vec,
		const std::vector<double>& p1_p2_cross_x, const std::vector<double>& p1_p2_cross_y, const std::vector<double>& p1_p2_cross_z);
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
	bool Judge_local_distortion_v(MyMesh::VertexHandle &v, int threshold);
	void Local_EXP_MIPS_AREA_Reposition_v(MyMesh::VertexHandle &v, double energy_power, double angle_area_ratio);
	vector<Eigen::VectorXf> ComputeTriangleDistortion(MyMesh* mesh_, double angle_area_ratio);
	vector<Eigen::VectorXf> ComputeTriangleDistortion_Refer_Originmesh(MyMesh* mesh_, MyMesh* m1, double angle_area_ratio);
	double ComputeLocalMaxTriangleDistortion_Refer_Originmesh(MyMesh* mesh_, MyMesh* m1, double angle_area_ratio, MyMesh::VertexHandle &v);
	double ComputeMaxTriangleDistortion_Refer_Originmesh(MyMesh* mesh_, MyMesh* m1, double angle_area_ratio);
	double ComputeGlobalMaxTriangleDistortion(MyMesh* mesh_, double angle_area_ratio);
	double ComputeLocalMaxTriangleDistortion(MyMesh* mesh_, double angle_area_ratio, MyMesh::VertexHandle &v);
	vector<Eigen::VectorXf> triangle_distortion(MyMesh * mesh_, MyMesh * m1);

public:
	MyMesh *mesh;
	MyMesh *origin_mesh;
	//	int iter;
private:
	double radius_suv;
	double dr_eps;
	double overlap_eps;
private:
	std::vector<double> new_p_x; std::vector<double> new_p_y; std::vector<double> new_p_z;
	std::vector<std::vector<int>> vertex_v1; std::vector<std::vector<int>> vertex_v2;
	std::vector<std::vector<double>> omega0; std::vector<std::vector<double>> omega1; std::vector<std::vector<double>> omega2;
	std::vector<std::vector<double>> face_area; std::vector<std::vector<double>> inv_face_area;
	std::vector<std::vector<double>> face_vol; std::vector<std::vector<double>> inv_face_vol;
	std::vector<double> vertex_radius_ratio; int max_vv_size;
	int number_of_color;
	std::vector< std::vector<int> > vertex_diff_color;
	int max_vertex_color;
	OpenMesh::VPropHandleT<MyMesh::Point> origin_position_;

	/////////////////////////////////////////////////////////////
	vector<double> p1_nei_x, p1_nei_y, p1_nei_z, p2_nei_x, p2_nei_y, p2_nei_z;
	double cot_angla, fa_area;
	double current_x, current_y, current_z;
	int size_nei;

	/////////////////////////////////////////////////////////////// subdivision of sphere triangle
	fmath::PowGenerator *f;
	double high_d;
	double thresh_hold;
	vector<vector<vector<vector<double>>>> all_sub_triangle;
	vector<vector<vector<double>>> sub_triangles;
	vector<vector<double>> record_start_point;
	vector<int> num_sun_nei;
	double ComputeRefineAmipsEreaEnergy(int &k, double &angle_area_ratio, double &px, double &py, double &pz, vector<int> &vv1, vector<int> &vv2);
	bool JudgeRefineAmipsEreaEnergy(double old_e, int &k, double &angle_area_ratio, double &px, double &py, double &pz, vector<int> &vv1, vector<int> &vv2);
	void FindAllSubTriangles(double t1, double t2, double t3); // p0 = (n,0,0); p1 = (0,n,0); p2 = (0,0,n) 
	double ComputeSubTriangleEnergy(int &n, double &angle_area_ratio, MyMesh::Point &p_0, MyMesh::Point &p_1, MyMesh::Point &p_2);
	void Refine_EXP_MIPS_AREA_Reposition(MyMesh* mesh_, double step_length, double energy_power, double angle_area_ratio);
	void prepare_refine();

public:
	double max_con; double min_con; double avg_con;
	double max_iso; double min_iso; double avg_iso; double std_iso_;
	double max_area; double min_area; double avg_area;
};

